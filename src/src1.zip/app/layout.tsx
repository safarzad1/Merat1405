import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "مرآت جدید",
  description: "نسخه جدید سامانه مرآت",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
