"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useMemo, useRef, useState } from "react";
import styles from "./AppTopbar.module.css";

type AppTopbarProps = {
  fullName?: string;
  postId?: number;
};

type StoredUser = {
  Mahal?: string | number | null;
  DateNow?: string | null;
  FullName?: string | null;
};

type MenuEntry = {
  label: string;
  href?: string;
  icon: "dashboard" | "news" | "research" | "people" | "election" | "users" | "mail";
  children?: Array<{ label: string; href: string }>;
};

function Icon({ name }: { name: MenuEntry["icon"] | "logout" | "chevron" | "menu" | "close" | "user" }) {
  if (name === "dashboard") {
    return <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="3.5" width="6.5" height="6.5" rx="1.5"/><rect x="14" y="3.5" width="6.5" height="6.5" rx="1.5"/><rect x="3.5" y="14" width="6.5" height="6.5" rx="1.5"/><rect x="14" y="14" width="6.5" height="6.5" rx="1.5"/></svg>;
  }
  if (name === "news") {
    return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 4h11v16H5z"/><path d="M16 8h3v10a2 2 0 0 1-2 2M8 8h5M8 12h5M8 16h3"/></svg>;
  }
  if (name === "research") {
    return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7.5h6l1.5 2H20v9.5H4z"/><path d="M4 7.5V5h6l1.5 2.5M9 14h6M12 11v6"/></svg>;
  }
  if (name === "people") {
    return <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="9" cy="8" r="3"/><path d="M3.5 19v-1a5.5 5.5 0 0 1 11 0v1M15.5 6a3 3 0 0 1 0 5.5M16.5 14a4.5 4.5 0 0 1 4 4.5V19"/></svg>;
  }
  if (name === "election") {
    return <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="9" width="16" height="11" rx="2"/><path d="m8 9 2-5h4l2 5M9 14h6M12 12v4"/></svg>;
  }
  if (name === "users") {
    return <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="3.5"/><path d="M5 20a7 7 0 0 1 14 0"/><path d="M18 5.5h3M19.5 4v3"/></svg>;
  }
  if (name === "mail") {
    return <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m4 7 8 6 8-6"/></svg>;
  }
  if (name === "logout") {
    return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10 5H5v14h5M14 8l4 4-4 4M18 12H9"/></svg>;
  }
  if (name === "chevron") {
    return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m7 10 5 5 5-5"/></svg>;
  }
  if (name === "menu") {
    return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"/></svg>;
  }
  if (name === "close") {
    return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18"/></svg>;
  }
  return <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="3.5"/><path d="M5.5 20a6.5 6.5 0 0 1 13 0"/></svg>;
}

function pathActive(pathname: string, href?: string) {
  if (!href) return false;
  if (href === "/Dashboard") return pathname === href;
  return pathname === href || pathname.startsWith(`${href}/`);
}

export default function AppTopbar({ fullName, postId = 0 }: AppTopbarProps) {
  const pathname = usePathname();
  const router = useRouter();
  const headerRef = useRef<HTMLElement>(null);
  const [openMenu, setOpenMenu] = useState<string | null>(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [loggingOut, setLoggingOut] = useState(false);
  const [storedUser, setStoredUser] = useState<StoredUser>({});

  useEffect(() => {
    try {
      const raw = localStorage.getItem("merat-user");
      if (raw) setStoredUser(JSON.parse(raw) as StoredUser);
    } catch {
      setStoredUser({});
    }
  }, []);

  useEffect(() => {
    setOpenMenu(null);
    setMobileOpen(false);
  }, [pathname]);

  useEffect(() => {
    function closeMenus(event: MouseEvent) {
      if (headerRef.current && !headerRef.current.contains(event.target as Node)) {
        setOpenMenu(null);
      }
    }
    document.addEventListener("mousedown", closeMenus);
    return () => document.removeEventListener("mousedown", closeMenus);
  }, []);

  const mahalLength = String(storedUser.Mahal ?? "").length || 99;

  const menuItems = useMemo<MenuEntry[]>(() => {
    const base: MenuEntry[] = [
      { label: "داشبورد", href: "/Dashboard", icon: "dashboard" },
    ];

    if (postId === 54) {
      return [
        ...base,
        { label: "مدیریت تحقیقات", href: "/TahghighatManage", icon: "research" },
        {
          label: "ارتباطات",
          icon: "mail",
          children: [
            { label: "صندوق پستی", href: "/Mail" },
            { label: "پیام‌رسان", href: "/ChatRoom" },
          ],
        },
      ];
    }

    if (postId === 55) {
      return [
        ...base,
        {
          label: "داوطلبان انتخابات",
          icon: "election",
          children: [
            { label: "فهرست ثبت‌نام قطعی", href: "/Davtalab/Davtalaban" },
            { label: "فهرست پیش‌ثبت‌نام", href: "/Davtalab/CardDavtalab" },
          ],
        },
        {
          label: "ارتباطات",
          icon: "mail",
          children: [
            { label: "صندوق پستی", href: "/Mail" },
            { label: "پیام‌رسان", href: "/ChatRoom" },
          ],
        },
      ];
    }

    if (mahalLength === 1) {
      base.push({ label: "مدیریت اخبار", href: "/AkhbarManage", icon: "news" });
    }

    base.push({ label: "مدیریت تحقیقات", href: "/TahghighatManage", icon: "research" });

    if (postId !== 56) {
      base.push({ label: "همکاران", href: "/Persons/Hamkari", icon: "people" });
    }

    base.push({
      label: "مجلس دوازدهم",
      icon: "election",
      children: [
        { label: "فهرست ثبت‌نام قطعی", href: "/Davtalab/Davtalaban" },
        { label: "فهرست پیش‌ثبت‌نام", href: "/Davtalab/CardDavtalab" },
      ],
    });

    if (mahalLength <= 3) {
      base.push({
        label: "کاربران",
        icon: "users",
        children: [{ label: "مدیریت کاربران", href: "/Users/FehrestUsers/Ostan" }],
      });
    }

    base.push({
      label: "ارتباطات",
      icon: "mail",
      children: [
        { label: "صندوق پستی", href: "/Mail" },
        { label: "پیام‌رسان", href: "/ChatRoom" },
      ],
    });

    return base;
  }, [mahalLength, postId]);

  async function logout() {
    if (loggingOut) return;
    setLoggingOut(true);
    try {
      await fetch("/Api/Auth/Logout", { method: "POST", cache: "no-store" });
    } finally {
      try { localStorage.removeItem("merat-user"); } catch {}
      router.replace("/Login");
      router.refresh();
    }
  }

  const displayName = storedUser.FullName || fullName || "کاربر سامانه";

  return (
    <header className={styles.header} ref={headerRef} dir="rtl">
      <div className={styles.topRow}>
        <div className={styles.brandSide}>
          <button
            type="button"
            className={styles.mobileMenuButton}
            onClick={() => setMobileOpen((value) => !value)}
            aria-label={mobileOpen ? "بستن منو" : "باز کردن منو"}
          >
            <Icon name={mobileOpen ? "close" : "menu"} />
          </button>

          <Link href="/Dashboard" className={styles.brand}>
            <span className={styles.brandMark}>م</span>
            <span className={styles.brandText}>
              <strong>مرآت</strong>
              <small>سامانه جامع مدیریت و تحقیقات</small>
            </span>
          </Link>
        </div>

        <div className={styles.headerActions}>
          {storedUser.DateNow ? (
            <div className={styles.dateBox}>
              <span>تاریخ روز</span>
              <b>{storedUser.DateNow}</b>
            </div>
          ) : null}

          <Link href="/Mail" className={styles.iconButton} aria-label="صندوق پستی" title="صندوق پستی">
            <Icon name="mail" />
          </Link>

          <div className={styles.userBox}>
            <span className={styles.userAvatar}><Icon name="user" /></span>
            <span className={styles.userInfo}>
              <small>کاربر سامانه</small>
              <strong>{displayName}</strong>
            </span>
          </div>

          <button type="button" className={styles.logoutButton} onClick={logout} disabled={loggingOut}>
            <span className={styles.logoutIcon}><Icon name="logout" /></span>
            <span>{loggingOut ? "در حال خروج..." : "خروج"}</span>
          </button>
        </div>
      </div>

      <nav className={`${styles.menuBar} ${mobileOpen ? styles.menuBarOpen : ""}`} aria-label="منوی اصلی">
        <div className={styles.menuInner}>
          {menuItems.map((item) => {
            const childActive = item.children?.some((child) => pathActive(pathname, child.href)) ?? false;
            const active = pathActive(pathname, item.href) || childActive;

            if (!item.children) {
              return (
                <Link
                  key={item.label}
                  href={item.href || "/Dashboard"}
                  className={`${styles.menuItem} ${active ? styles.menuItemActive : ""}`}
                  aria-current={active ? "page" : undefined}
                >
                  <span className={styles.menuIcon}><Icon name={item.icon} /></span>
                  <span>{item.label}</span>
                </Link>
              );
            }

            const opened = openMenu === item.label;
            return (
              <div className={styles.menuGroup} key={item.label}>
                <button
                  type="button"
                  className={`${styles.menuItem} ${active ? styles.menuItemActive : ""}`}
                  onClick={() => setOpenMenu((value) => value === item.label ? null : item.label)}
                  aria-expanded={opened}
                >
                  <span className={styles.menuIcon}><Icon name={item.icon} /></span>
                  <span>{item.label}</span>
                  <span className={`${styles.chevron} ${opened ? styles.chevronOpen : ""}`}><Icon name="chevron" /></span>
                </button>

                {opened ? (
                  <div className={styles.dropdown}>
                    {item.children.map((child) => {
                      const subActive = pathActive(pathname, child.href);
                      return (
                        <Link
                          key={child.href}
                          href={child.href}
                          className={`${styles.dropdownItem} ${subActive ? styles.dropdownItemActive : ""}`}
                        >
                          <span className={styles.dropdownDot} />
                          <span>{child.label}</span>
                        </Link>
                      );
                    })}
                  </div>
                ) : null}
              </div>
            );
          })}
        </div>
      </nav>
    </header>
  );
}
