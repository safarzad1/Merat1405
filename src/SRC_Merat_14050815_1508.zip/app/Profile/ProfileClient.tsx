"use client";

import { useCallback, useEffect, useRef, useState, type ChangeEvent, type PointerEvent as ReactPointerEvent } from "react";
import styles from "./Profile.module.css";

type Profile = {
  userId:string; fullName:string; nationalCode:string; mobile:string;
  position:string; location:string; hasSignature:boolean; signatureUpdatedAtUtc:string|null;
};

const W=960, H=320;
const noCache:RequestInit={credentials:"same-origin",cache:"no-store"};

async function responseMessage(res:Response, fallback:string) {
  try {const body=await res.json() as {message?:string}; return body.message || fallback;}
  catch {return fallback;}
}

export default function ProfileClient() {
  const [profile,setProfile]=useState<Profile|null>(null);
  const [loading,setLoading]=useState(true);
  const [error,setError]=useState("");
  const [notice,setNotice]=useState("");
  const [saving,setSaving]=useState(false);
  const [hasDraft,setHasDraft]=useState(false);
  const [storedImage,setStoredImage]=useState<string|null>(null);
  const canvasRef=useRef<HTMLCanvasElement|null>(null);
  const pointerRef=useRef<number|null>(null);
  const imageUrlRef=useRef<string|null>(null);
  const uploaderRef=useRef<HTMLInputElement|null>(null);

  const resetCanvas=useCallback(() => {
    const canvas=canvasRef.current;
    if (!canvas) return;
    const ctx=canvas.getContext("2d");
    if (!ctx) return;
    ctx.fillStyle="#fff";
    ctx.fillRect(0,0,canvas.width,canvas.height);
    ctx.lineCap="round";
    ctx.lineJoin="round";
    ctx.lineWidth=3;
    ctx.strokeStyle="#17233f";
    pointerRef.current=null;
    setHasDraft(false);
  },[]);

  const loadSignature=useCallback(async () => {
    const res=await fetch("/Api/Users/MySignature",noCache);
    if (!res.ok) {
      if (imageUrlRef.current) URL.revokeObjectURL(imageUrlRef.current);
      imageUrlRef.current=null;
      setStoredImage(null);
      if (res.status !== 404) throw new Error(await responseMessage(res,"دریافت تصویر امضا ممکن نشد."));
      return;
    }
    const url=URL.createObjectURL(await res.blob());
    if (imageUrlRef.current) URL.revokeObjectURL(imageUrlRef.current);
    imageUrlRef.current=url;
    setStoredImage(url);
  },[]);

  const loadProfile=useCallback(async () => {
    const res=await fetch("/Api/Users/MyProfile",noCache);
    if (!res.ok) throw new Error(await responseMessage(res,"دریافت اطلاعات پروفایل ممکن نشد."));
    const body=await res.json() as {ok?:boolean;profile?:Profile};
    if (!body.ok || !body.profile) throw new Error("اطلاعات حساب معتبر نیست.");
    setProfile(body.profile);
    await loadSignature();
  },[loadSignature]);

  useEffect(() => {
    let live=true;
    setLoading(true);
    loadProfile().catch((e:unknown)=>{if(live)setError(e instanceof Error?e.message:"خطای دریافت اطلاعات");})
      .finally(()=>{if(live)setLoading(false);});
    return ()=>{live=false;if(imageUrlRef.current)URL.revokeObjectURL(imageUrlRef.current);imageUrlRef.current=null;};
  },[loadProfile]);

  useEffect(() => {
    if (profile) resetCanvas();
  },[profile?.userId,resetCanvas]);

  const locationInCanvas=(ev:ReactPointerEvent<HTMLCanvasElement>)=>{
    const canvas=ev.currentTarget;
    const rect=canvas.getBoundingClientRect();
    return {x:(ev.clientX-rect.left)*canvas.width/rect.width,y:(ev.clientY-rect.top)*canvas.height/rect.height};
  };
  const startStroke=(event:ReactPointerEvent<HTMLCanvasElement>)=>{
    if(saving || (event.pointerType==="mouse"&&event.button!==0))return;
    event.preventDefault();
    const canvas=event.currentTarget;
    const ctx=canvas.getContext("2d");
    if(!ctx)return;
    const p=locationInCanvas(event);
    canvas.setPointerCapture(event.pointerId);
    pointerRef.current=event.pointerId;
    ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(p.x+0.2,p.y+0.2);ctx.stroke();
    setHasDraft(true);setError("");setNotice("");
  };
  const moveStroke=(event:ReactPointerEvent<HTMLCanvasElement>)=>{
    if(pointerRef.current!==event.pointerId)return;
    event.preventDefault();
    const ctx=event.currentTarget.getContext("2d");
    if(!ctx)return;
    const p=locationInCanvas(event);
    ctx.lineTo(p.x,p.y);ctx.stroke();
  };
  const finishStroke=(event:ReactPointerEvent<HTMLCanvasElement>)=>{
    if(pointerRef.current!==event.pointerId)return;
    pointerRef.current=null;
    event.currentTarget.getContext("2d")?.closePath();
    if(event.currentTarget.hasPointerCapture(event.pointerId))event.currentTarget.releasePointerCapture(event.pointerId);
  };

  const importFile=async (event:ChangeEvent<HTMLInputElement>)=>{
    const file=event.target.files?.[0];
    event.target.value="";
    if(!file)return;
    if(!["image/png","image/jpeg","image/webp"].includes(file.type) || file.size>3*1024*1024){
      setError("تصویر PNG، JPG یا WEBP با حجم حداکثر ۳ مگابایت انتخاب کنید.");return;
    }
    try {
      const bitmap=await createImageBitmap(file);
      try {
        if (bitmap.width > 5000 || bitmap.height > 5000) throw new Error("ابعاد تصویر انتخاب‌شده بیش از حد مجاز است.");
        const canvas=canvasRef.current;
        const ctx=canvas?.getContext("2d");
        if(!canvas||!ctx)throw new Error("بوم امضا آماده نیست.");
        ctx.fillStyle="#fff";ctx.fillRect(0,0,W,H);
        const scale=Math.min((W-44)/bitmap.width,(H-35)/bitmap.height,1);
        const w=bitmap.width*scale,h=bitmap.height*scale;
        ctx.drawImage(bitmap,(W-w)/2,(H-h)/2,w,h);
        ctx.strokeStyle="#17233f";ctx.lineWidth=3;ctx.lineCap="round";ctx.lineJoin="round";
        setHasDraft(true);setError("");setNotice("");
      } finally {bitmap.close();}
    } catch {setError("خواندن تصویر انتخاب‌شده امکان‌پذیر نیست.");}
  };

  const save=async()=>{
    const canvas=canvasRef.current;
    if(!canvas||!hasDraft||saving)return;
    setSaving(true);setError("");setNotice("");
    try {
      const blob=await new Promise<Blob>((resolve,reject)=>canvas.toBlob(value=>value?resolve(value):reject(new Error("تولید تصویر امضا ناموفق بود.")),"image/png"));
      if(blob.size>524288)throw new Error("تصویر امضا بیش از ۵۱۲ کیلوبایت است؛ تصویر ساده‌تری ثبت کنید.");
      const form=new FormData();
      form.append("signature",new File([blob],"signature.png",{type:"image/png"}));
      const res=await fetch("/Api/Users/MySignature",{method:"POST",body:form,credentials:"same-origin",cache:"no-store"});
      if(!res.ok)throw new Error(await responseMessage(res,"ثبت امضا ممکن نشد."));
      await loadProfile();
      resetCanvas();
      setNotice("امضای شما با موفقیت در پروفایل ثبت شد.");
    } catch(e) {setError(e instanceof Error?e.message:"خطای ثبت امضا");}
    finally {setSaving(false);}
  };

  const fields:[string,string][] = profile?[
    ["نام و نام خانوادگی",profile.fullName], ["شناسه کاربری",profile.userId],
    ["کد ملی",profile.nationalCode], ["شماره همراه",profile.mobile],
    ["عنوان پست",profile.position], ["محل خدمت",profile.location],
  ]:[];

  return <div className={styles.wrapper} dir="rtl">
    <header className={styles.heading}>
      <div className={styles.profileHeroText}>
        <span className={styles.eyebrow}>حساب کاربری مرآت</span>
        <h1>پروفایل من</h1>
        <p>مشخصات هویتی و سازمانی از اطلاعات ثبت‌شده در سامانه خوانده می‌شوند و فقط‌خواندنی هستند.</p>
      </div>
      <div className={styles.heroMark} aria-hidden="true">{profile?.fullName?.trim()?.charAt(0) || "م"}</div>
    </header>
    {loading&&<p role="status" className={styles.message}>در حال دریافت اطلاعات پروفایل…</p>}
    {error&&<p role="alert" className={styles.error}>{error}</p>}
    {notice&&<p role="status" className={styles.success}>{notice}</p>}
    {profile&&<>
      <section className={styles.panel} aria-label="مشخصات کاربر">
        <div className={styles.sectionTitle}><div className={styles.titleGroup}><span className={styles.titleIcon} aria-hidden="true">◎</span><div><h2>اطلاعات اصلی کاربر</h2><p>مشخصات تأییدشده حساب</p></div></div><span>فقط‌خواندنی</span></div>
        <div className={styles.fields}>
          {fields.map(([title,value])=><div key={title} className={styles.field}>
            <span>{title}</span><strong dir={title==="کد ملی"||title==="شماره همراه"?"ltr":"auto"}>{value||"—"}</strong>
          </div>)}
        </div>
      </section>
      <section className={styles.panel} aria-label="امضای کاربر">
        <div className={styles.sectionTitle}><div className={styles.titleGroup}><span className={styles.titleIcon} aria-hidden="true">✍</span><div><h2>ثبت و نگهداری امضا</h2><p>امضای شخصی این حساب کاربری</p></div></div><span>{profile.hasSignature?"امضای ثبت‌شده":"فاقد امضا"}</span></div>
        <p className={styles.hint}>امضای خود را در کادر پایین با موس یا لمس رسم کنید، یا تصویر امضا را بارگذاری کنید. ثبت جدید، امضای قبلی را جایگزین می‌کند.</p>
        {storedImage&&<div className={styles.stored}>
          <div className={styles.storedHeading}>امضای فعلی شما</div>
          {/* Private blob URL created from the authenticated same-origin endpoint. */}
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={storedImage} alt="تصویر امضای ثبت‌شده کاربر" />
          {profile.signatureUpdatedAtUtc&&<small>آخرین ثبت: {new Date(profile.signatureUpdatedAtUtc).toLocaleString("fa-IR")}</small>}
        </div>}
        <div className={styles.signatureEditor}>
          <label htmlFor="merat-user-signature-canvas">ثبت امضای جدید</label>
          <canvas ref={canvasRef} id="merat-user-signature-canvas" width={W} height={H}
            aria-label="بوم رسم امضا با موس یا لمس"
            className={styles.canvas} onPointerDown={startStroke} onPointerMove={moveStroke}
            onPointerUp={finishStroke} onPointerCancel={finishStroke} onLostPointerCapture={()=>{pointerRef.current=null;}} />
          <input ref={uploaderRef} type="file" className={styles.hiddenInput} accept="image/png,image/jpeg,image/webp"
            onChange={event=>{void importFile(event);}} aria-label="انتخاب تصویر امضا" />
          <div className={styles.actions}>
            <button type="button" className={styles.secondary} disabled={saving} onClick={()=>uploaderRef.current?.click()}>بارگذاری تصویر امضا</button>
            <button type="button" className={styles.secondary} disabled={saving||!hasDraft} onClick={resetCanvas}>پاک‌کردن کادر</button>
            <button type="button" className={styles.primary} disabled={saving||!hasDraft} onClick={()=>void save()}>{saving?"در حال ثبت…":"ذخیره امضا"}</button>
          </div>
        </div>
      </section>
    </>}
  </div>;
}
