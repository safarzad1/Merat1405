import PanelPage from "@/component/PanelPage";
import AnalyticsClient from "./AnalyticsClient";
export const dynamic = "force-dynamic";
export default function NewsAnalyticsPage() {
 return <PanelPage title="داشبورد آماری اخبار"><AnalyticsClient /></PanelPage>;
}
