import { NextRequest, NextResponse } from "next/server";
import sql from "mssql";

import { getConnection } from "@/lib/db";
import { requireResearchIdentity, researchAccessResponse, researchMutationResponse, assertResearchCaseScope } from "@/lib/researchSecurity";

export async function POST(req: NextRequest) {
    const token = req.cookies.get("token")?.value;
    if (!token) {
        return NextResponse.json(
            { status: 401, error: "Unauthorized: No token" },
            { status: 401 }
        );
    }

    const body = await req.json();
    const { erjaId, fileName, fileExtend, fileSize, userid } = body;

    try {
        const actor = await requireResearchIdentity(token, userid);
        await assertResearchCaseScope(actor, erjaId);
    } catch (error) {
        return researchAccessResponse(error);
    }

    try {
        const pool = await getConnection();
        const result = await pool
            .request()
            .input("IDErja", sql.BigInt, erjaId)
            .input("FileName", sql.NVarChar(200), fileName)
            .input("FileExtend", sql.NVarChar(200), fileExtend)
            .input("FileSize", sql.NVarChar, fileSize)
            .input("UserId", sql.Int, userid)
            .execute("Tahghighat.SP_Insert_JambandiOstan_Peyvast");

        return researchMutationResponse(result);

    } catch (err) {
        return researchAccessResponse(err);
    }
}
