import PanelPage from "@/component/PanelPage";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { verifyToken } from "@/lib/auth";
import { getConnection } from "@/lib/db";
import DashboardCharts, { type DashboardData, type SeriesItem } from "./DashboardCharts";

export const dynamic = "force-dynamic";

const grouped = (table: string, dateColumn: string, filter: string, granularity: "day" | "month") => {
  const dateExpr = `LTRIM(RTRIM(${dateColumn}))`;
  const key = granularity === "month" ? `LEFT(${dateExpr},7)` : `LEFT(${dateExpr},10)`;
  const length = granularity === "month" ? 7 : 10;
  return `SELECT TOP (18) ${key} AS label, COUNT_BIG(*) AS amount FROM ${table}
    WHERE ${filter} AND LEN(${dateExpr}) >= ${length} AND SUBSTRING(${dateExpr},5,1) = '/'
    GROUP BY ${key} ORDER BY label DESC`;
};

function toItems(rows: { label: unknown; amount: unknown }[]): SeriesItem[] {
  return rows.map(r => ({ label: String(r.label ?? ""), value: Number(r.amount ?? 0) })).reverse();
}

async function loadData(): Promise<DashboardData> {
  const pool = await getConnection();
  const queries = [
    grouped("[Akhbar].[Khabar]", "CreateDateTime", "IsDelete = 0", "day"),
    grouped("[Akhbar].[Khabar]", "CreateDateTime", "IsDelete = 0", "month"),
    grouped("[Tahghighat].[Erja]", "CreateDateTime", "ISNULL(IsDelete,0) = 0", "day"),
    grouped("[Tahghighat].[Erja]", "CreateDateTime", "ISNULL(IsDelete,0) = 0", "month"),
    `SELECT TOP (15) ISNULL(c.Name, N'نامشخص') AS label, COUNT_BIG(*) AS amount
     FROM [Akhbar].[Khabar] k
     LEFT JOIN [dbo].[Citys] c ON c.CityId = TRY_CONVERT(BIGINT,LEFT(CONVERT(VARCHAR(20), k.CreateMahal),3))
     WHERE k.IsDelete = 0 GROUP BY c.Name ORDER BY amount DESC`,
    `SELECT TOP (15) ISNULL(c.Name,N'نامشخص') AS label, COUNT_BIG(*) AS amount
     FROM [Tahghighat].[Erja] e
     LEFT JOIN [dbo].[Citys] c ON c.CityId = TRY_CONVERT(BIGINT,LEFT(CONVERT(VARCHAR(20), e.MahalSender),3))
     WHERE ISNULL(e.IsDelete,0) = 0 GROUP BY c.Name ORDER BY amount DESC`,
    `SELECT COUNT_BIG(*) AS amount FROM [Akhbar].[Khabar] WHERE IsDelete = 0`,
    `SELECT COUNT_BIG(*) AS amount FROM [Tahghighat].[Erja] WHERE ISNULL(IsDelete,0) = 0`,
    `SELECT COUNT_BIG(*) AS amount FROM [Tahghighat].[Erja_Tahghigh] WHERE IsDelete = 0`,
    `SELECT COUNT_BIG(*) AS amount FROM [Tahghighat].[Erja_Tahghigh] WHERE IsDelete = 0 AND IsDone = 1`,
  ];
  const results = await Promise.all(queries.map(q => pool.request().query(q)));
  return {
    news: { daily: toItems(results[0].recordset), monthly: toItems(results[1].recordset), provinces: toItems(results[4].recordset) },
    research: { daily: toItems(results[2].recordset), monthly: toItems(results[3].recordset), provinces: toItems(results[5].recordset) },
    totals: { news: Number(results[6].recordset[0]?.amount ?? 0), referrals: Number(results[7].recordset[0]?.amount ?? 0), assigned: Number(results[8].recordset[0]?.amount ?? 0), done: Number(results[9].recordset[0]?.amount ?? 0) }
  };
}

export default async function DashboardPage() {
  const cookieStore = await cookies();
  const token = cookieStore.get("token")?.value;
  if (!token) redirect("/Login");
  try { verifyToken(token); } catch { redirect("/Login"); }
  try {
    const data = await loadData();
    return <PanelPage title="داشبورد"><DashboardCharts data={data} /></PanelPage>;
  } catch (error) {
    console.error("Merat dashboard statistics failed:", error);
    return <PanelPage title="داشبورد"><div dir="rtl" style={{padding:24}}><h2>داشبورد آماری</h2><p>دریافت آمار از پایگاه داده انجام نشد. اتصال و ساختار جداول MeratDB را بررسی کنید.</p></div></PanelPage>;
  }
}
