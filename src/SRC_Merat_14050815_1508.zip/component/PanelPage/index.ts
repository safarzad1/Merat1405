export { default } from "./PanelPage";
