import type { CSSProperties } from "react";

export type DropdownPosition = {
  top: number;
  left: number;
  width: number;
  maxHeight: number;
};

export function getDropdownPosition(
  rootRef: { current: HTMLElement | null },
  preferredWidth?: number,
  preferredMaxHeight?: number,
  verticalGap = 5,
): DropdownPosition {
  const root = rootRef.current;
  if (!root || typeof window === "undefined") {
    return { top: 0, left: 0, width: 280, maxHeight: 280 };
  }

  const rect = root.getBoundingClientRect();
  const viewportWidth = window.innerWidth;
  const viewportHeight = window.innerHeight;
  const horizontalMargin = 10;
  const requestedWidth = Math.max(
    rect.width,
    Math.min(preferredWidth ?? rect.width, viewportWidth - 20),
  );
  const width = Math.min(requestedWidth, viewportWidth - horizontalMargin * 2);
  const left = Math.min(
    Math.max(horizontalMargin, rect.right - width),
    viewportWidth - width - horizontalMargin,
  );
  const spaceBelow = Math.max(0, viewportHeight - rect.bottom - verticalGap - 8);
  const spaceAbove = Math.max(0, rect.top - verticalGap - 8);
  const openAbove = spaceBelow < Math.min(180, preferredMaxHeight ?? 300) && spaceAbove > spaceBelow;
  const availableHeight = openAbove ? spaceAbove : spaceBelow;
  // The popup is portaled and floating; never force the old 120px minimum
  // if the viewport has less room (it would extend under a modal footer).
  const maxHeight = Math.max(24, Math.min(300, preferredMaxHeight ?? 300, availableHeight));
  const top = openAbove
    ? Math.max(8, rect.top - maxHeight - verticalGap)
    : Math.min(viewportHeight - maxHeight - 8, rect.bottom + verticalGap);

  return { top, left, width, maxHeight };
}

export function createDropdownMenuStyle(
  position: DropdownPosition,
  zIndex: number,
): CSSProperties {
  return {
    top: position.top,
    left: position.left,
    width: position.width,
    maxHeight: position.maxHeight,
    zIndex,
  };
}

/** Normalize Persian and Arabic variants before matching dropdown options. */
export function normalizeDropdownSearch(value: string): string {
  return String(value ?? "")
    .replace(/[يى]/g, "ی")
    .replace(/ك/g, "ک")
    .replace(/[۰-۹]/g, (digit) => String(digit.charCodeAt(0) - 1776))
    .replace(/[٠-٩]/g, (digit) => String(digit.charCodeAt(0) - 1632))
    .replace(/[\u064B-\u065F\u0670\u200C\u200D]/g, "")
    .trim()
    .toLocaleLowerCase();
}
