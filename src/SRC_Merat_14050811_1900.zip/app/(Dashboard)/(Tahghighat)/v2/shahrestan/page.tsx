"use client";
import {useEffect,useState} from "react";
import { WorkflowHero, StateChip, EmptyMessage, AppNotice, SectionTitle, workflowStyles as u } from "@/app/(Dashboard)/(Tahghighat)/v2/components/MeratWorkflowUI";

import {meratV2Request,type V2Row} from "@/app/lib/meratV2/client";
import CountySummaryEditor from "@/app/(Dashboard)/(Tahghighat)/v2/components/CountySummaryEditor";
import ProvinceInvestigatorWorksheetEditor from "@/app/(Dashboard)/(Tahghighat)/v2/components/ProvinceInvestigatorWorksheetEditor";
import SearchableDropdown from "@/component/Dropdown/SearchableDropdown";
import InputPersianDate from "@/component/Objects/InputPersianDatePicker";
const number=(x:unknown)=>Number(x||0),text=(x:unknown)=>x==null?"—":String(x);
export default function CountyRepresentativePage(){
 const [inbox,setInbox]=useState<V2Row[]>([]),[candidates,setCandidates]=useState<V2Row[]>([]),[assignments,setAssignments]=useState<V2Row[]>([]);
 const [ref,setRef]=useState<number|null>(null),[selected,setSelected]=useState<number|null>(null),[investigator,setInvestigator]=useState(""),[instruction,setInstruction]=useState(""),[dueDate,setDueDate]=useState(""),[reason,setReason]=useState("");
 const [summaryReady,setSummaryReady]=useState(false);
 const [finishId,setFinishId]=useState<number|null>(null);
 const [finishSummary,setFinishSummary]=useState("");
 const [busy,setBusy]=useState(false),[error,setError]=useState(""),[notice,setNotice]=useState("");
 async function reload(){setInbox(await meratV2Request("/Api/TahghighV2/CountyInbox?page=1&pageSize=100"));}
 async function detail(id:number){const [a,b]=await Promise.all([
  meratV2Request(`/Api/TahghighV2/CountyCandidates?countyReferralId=${id}`),
  meratV2Request(`/Api/TahghighV2/CountyAssignments?countyReferralId=${id}`)]);setCandidates(a);setAssignments(b);setSelected(cur=>cur || (b.length===1 ? number(b[0].AssignmentId) : null));setFinishId(null);}
 useEffect(()=>{
   const requested = Number(new URLSearchParams(window.location.search).get("referralId"));
   if(Number.isSafeInteger(requested) && requested>0) setRef(requested);
   void reload().catch(e=>setError(String(e)));
 },[]);
 useEffect(()=>{setCandidates([]);setAssignments([]);setSelected(null);if(ref!==null)void detail(ref).catch(e=>setError(String(e)));},[ref]);
 const row=inbox.find(x=>number(x.CountyReferralId)===ref),working=row?.StateCode==="CHILD_WORKING";
 const open=assignments.some(x=>["PENDING","IN_PROGRESS"].includes(text(x.StatusCode)));
 async function act(url:string,body:Record<string,unknown>,msg:string){setBusy(true);setError("");setNotice("");try{
  await meratV2Request(url,body);setNotice(msg);await reload();if(ref!==null)await detail(ref);setSelected(null);
 }catch(e){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false);}}
 return <main dir="rtl" className={u.workspace}>
 <WorkflowHero eyebrow="تحقیقات مرآت · فاز ۲C" title="کارتابل نماینده شهرستان"
 description="ارجاع به چند محقق تأییدشده، پایش کاربرگ‌ها و ارسال پاسخ نهایی پس از تعیین‌تکلیف همه مأموریت‌ها."
 stats={[{label:"ارجاعات شهرستان",value:inbox.length},{label:"محققان دارای مأموریت",value:assignments.length},{label:"تحقیقات باز",value:assignments.filter(x=>["PENDING","IN_PROGRESS"].includes(String(x.StatusCode))).length}]}/>
 <SectionTitle kicker="صندوق شهرستان" title="ارجاعات دریافتی" description="پرونده موردنظر را از فهرست انتخاب کنید."/>
 {error&&<AppNotice kind="error">{error}</AppNotice>}{notice&&<AppNotice kind="success">{notice}</AppNotice>}
 <button type="button" onClick={()=>void reload().catch(e=>setError(String(e)))}>بازخوانی</button>
 <ul>{inbox.map(x=><li key={text(x.CountyReferralId)}><button type="button" onClick={()=>{setSummaryReady(false);setRef(number(x.CountyReferralId));}}>ارجاع {text(x.CountyReferralId)} — پرونده {text(x.ShomarehParvandeh)} — {text(x.StateCode)}</button></li>)}</ul>{inbox.length===0&&<EmptyMessage title="ارجاعی در کارتابل وجود ندارد"/>}
 {ref!==null&&row&&<section className={u.selectionPanel}>
 <SectionTitle kicker="پرونده انتخابی" title={`ارجاع شهرستان ${ref}`}/><p>{text(row.Description)}</p>
 <label>توضیح اقدام/علت لغو<textarea rows={3} maxLength={6000} value={reason} style={{display:"block",width:"100%"}} onChange={e=>setReason(e.target.value)}/></label>
 {row.StateCode==="CHILD_INBOX"&&<button type="button" disabled={busy||!reason.trim()} onClick={()=>void act("/Api/TahghighV2/CountyAction",{countyReferralId:ref,actionCode:"COUNTY_START",description:reason.trim()},"بررسی شروع شد.")}>شروع بررسی شهرستان</button>}
 {working&&<section><SectionTitle kicker="توزیع مأموریت" title="ارجاع به محقق جدید"/><div style={{maxWidth: 410}}><label>محقق</label><SearchableDropdown<string>
  value={investigator || null} onChange={setInvestigator}
  options={candidates.map(x=>({value:String(x.PersonId),label:String(x.FullName || `محقق ${text(x.PersonId)}`),
    description: x.CountyName ? String(x.CountyName) : undefined,
    searchText: `${text(x.FullName)} ${text(x.PersonId)}`, disabled: x.IsAssignable===false || x.IsAssignable===0}))}
  placeholder="انتخاب محقق" searchPlaceholder="جست‌وجوی نام محقق..." compact menuMaxHeight={240}
  ariaLabel="انتخاب محقق شهرستان"/></div>
 <div style={{maxWidth: 210}}><label>مهلت انجام (شمسی)</label><InputPersianDate value={dueDate || null} onChange={v=>setDueDate(v || "")} allowPastDates={false}/></div>
 <label>شرح مأموریت<textarea rows={3} value={instruction} maxLength={6000} style={{display:"block",width:"100%"}} onChange={e=>setInstruction(e.target.value)}/></label>
 <button type="button" className={u.primary} disabled={busy||!investigator||!instruction.trim()} onClick={()=>void act("/Api/TahghighV2/CountyAssignInvestigator",{countyReferralId:ref,personId:Number(investigator),instruction:instruction.trim(),dueDatePersian:dueDate||null},"انتساب محقق ثبت شد.")}>ثبت انتساب</button>
 </section>}
 <SectionTitle kicker="پیگیری" title="محققان و نتایج"/><div className={u.tableScroll}><table style={{width:"100%",textAlign:"right"}}><thead><tr><th>انتساب</th><th>وضعیت</th><th>جمع‌بندی</th><th>عملیات</th></tr></thead><tbody>{assignments.map(x=><tr key={text(x.AssignmentId)}><td>{text(x.AssignmentId)}</td><td><StateChip value={x.StatusCode}/></td><td>{text(x.Summary)}</td><td>
 <button type="button" onClick={()=>setSelected(number(x.AssignmentId))}>کاربرگ‌ها و جمع‌بندی محقق</button>
 {working&&text(x.StatusCode)==="IN_PROGRESS"&&<button type="button" disabled={busy} onClick={()=>{setFinishId(number(x.AssignmentId));setFinishSummary(String(x.Summary||""));}}>تکمیل تحقیق</button>}
 {working&&["PENDING","IN_PROGRESS"].includes(text(x.StatusCode))&&<button type="button" disabled={busy||!reason.trim()} onClick={()=>void act("/Api/TahghighV2/CountyCancelAssignment",{assignmentId:number(x.AssignmentId),reason:reason.trim()},"انتساب لغو شد.")}>لغو مستند</button>}
 </td></tr>)}</tbody></table></div>
 {selected!==null&&assignments.some(x=>number(x.AssignmentId)===selected)&&<section>
   <ProvinceInvestigatorWorksheetEditor key={selected} scope="COUNTY" assignmentId={selected}
    investigatorName={String(assignments.find(x=>number(x.AssignmentId)===selected)?.FullName || "محقق شهرستان")}
    assignmentStatus={String(assignments.find(x=>number(x.AssignmentId)===selected)?.StatusCode || "")}
    canManage={working} onSaved={async()=>{if(ref!==null)await detail(ref);}} />
 </section>}
 {finishId!==null&&<section className={u.selectionPanel} role="group" aria-label="تکمیل تحقیق محقق">
  <h4>تکمیل تحقیق — محقق {finishId}</h4>
  <p>ابتدا کاربرگ و فرم رسمی جمع‌بندی محقق را ثبت کنید، سپس تحقیق را تکمیل کنید.</p>
  <label>متن جمع‌بندی ذخیره‌شده<textarea rows={3} maxLength={12000} value={finishSummary} readOnly style={{display:"block",width:"100%"}}/></label>
  <button type="button" disabled={busy||finishSummary.trim().length<50} onClick={()=>void act("/Api/TahghighV2/CountyOfficerCompleteAssignment",{assignmentId:finishId,summary:finishSummary.trim()},"تحقیق تکمیل شد.")}>تأیید تکمیل تحقیق</button>
  <button type="button" disabled={busy} onClick={()=>setFinishId(null)}>انصراف</button>
 </section>}
 <CountySummaryEditor key={ref} referralId={ref} working={working} onReadyChange={setSummaryReady}/>
 {working&&<button type="button" className={u.primary} disabled={busy||open||!summaryReady||!reason.trim()} onClick={()=>void act("/Api/TahghighV2/CountyAction",{countyReferralId:ref,actionCode:"COUNTY_REPLY",description:reason.trim()},"پاسخ شهرستان به حوزه ارسال شد.")}>ارسال پاسخ شهرستان به حوزه</button>}
 {open&&<AppNotice kind="info">تا پایان یا لغو مستند همه تحقیقات، پاسخ شهرستان مسدود است.</AppNotice>}
 </section>}</main>;
}
