"use client";
/* The original province's Tajmi form, ported from
 * ParvandehOstan/[KeyData]/page.tsx (questions/radioItems and the two official sheets).
 * Only the persistence adapter is V2; applicant data and access are server-scoped. */
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import domtoimage from "@/lib/domToImageCompat";
import { meratV2Request, type V2Row } from "@/app/lib/meratV2/client";
import SummaryAttachmentsPanel from "./SummaryAttachmentsPanel";
import s from "./ProvinceLegacySummaryForm.module.css";

// Original seven option groups and eight questions, unchanged in substance.
const radioItems = [
  ["معتقد و ملتزم", "غیرعامل و در تقابل", "کاهل و دارای رفتار و مواضع دوگانه", "بی تفاوت", "نامشخص"],
  ["عامل و ملتزم", "غیرعامل و در تقابل", "کاهل و دارای رفتار و مواضع دوگانه", "بی تفاوت", "نامشخص"],
  ["مدافع و همسو با نظام", "مخالف و در تقابل", "رفتار و مواضع دوگانه", "بی تفاوت", "نامشخص"],
  ["عامل و ملتزم", "غیرعامل و در تقابل", "کاهل و دارای رفتار و مواضع دوگانه", "بی تفاوت", "نامشخص"],
  ["معتقد و ملتزم", "غیر عامل و در تقابل", "رفتار و مواضع دوگانه", "بی تفاوت", "نامشخص"],
  ["عامل و ملتزم به مسائل شرعی و قانونی", "غیر عامل و در تقابل با مسائل شرعی و قانونی", "رفتار و مواضع دوگانه", "بی تفاوت", "نامشخص"],
  ["عامل و ملتزم", "غیرعامل و در تقابل", "رفتار و مواضع دوگانه", "بی تفاوت", "نامشخص"],
];
const questions = [
  "۱. اعتقاد و التزام عملی داوطلب به مسائل دینی، اعتقادی و عبادی:",
  "۲. وضعیت داوطلب در حوزه مسائل اخلاقی، رفتاری و شخصیتی:",
  "۳. التزام عملی داوطلب به نظام مقدس جمهوری اسلامی ایران و مواضع و عملکرد وی در حوزه مسائل سیاسی و امنیتی:",
  "۴. ابراز وفاداری و مواضع و عملکرد داوطلب نسبت به اصل ولایت مطلقه فقیه و میزان پایبندی وی به دستورات، سیاست‌ها و منویات مقام معظم رهبری:",
  "۵. ابراز وفاداری و میزان پایبندی داوطلب به قوانین و مقررات کشور (قانون اساسی و قوانین عادی):",
  "۶. وضعیت داوطلب در حوزه مسائل اقتصادی و مالی:",
  "۷. وضعیت خانواده، بستگان درجه یک / سببی و نسبی، دوستان و معاشرین داوطلب:",
  "۸. ویژگی‌ها، موفقیت‌ها یا خدمات برجسته داوطلب که در مقایسه با افراد مشابه واجد ارزش بوده و می‌تواند منجر به خدمت به جامعه شود:",
];
const blanks = () => Array<string>(8).fill("");
const choicesBlank = () => Array<number>(7).fill(-1);
const text = (value: unknown): string => value == null || String(value).trim() === "" ? "—" : String(value);
const num = (value: unknown): number => Number(value ?? 0) || 0;
const date = () => new Intl.DateTimeFormat("fa-IR-u-ca-persian", {
  timeZone: "Asia/Tehran", year: "numeric", month: "2-digit", day: "2-digit",
}).format(new Date()).replace(/[\u200e\u200f]/g, "");

type Continuation = {label: string; text: string};
function cutText(source: string, length: number): [string, string] {
  if (source.length <= length) return [source, ""];
  const idx = source.lastIndexOf(" ", length);
  const cut = idx > length * 0.7 ? idx : length;
  return [source.slice(0, cut), source.slice(cut).trimStart()];
}
/** The first sheet keeps the original questions; overflow is paginated instead of clipped. */
function pageParts(answers: string[], finalText: string, firstPageBudget = 620) {
  let available = firstPageBudget;
  const firstAnswers: string[] = [];
  const overflow: Continuation[] = [];
  for (let i=0; i<8; i++) {
    const full = answers[i] || "";
    const [first, rest] = cutText(full, Math.max(0, available));
    firstAnswers.push(first);
    available = Math.max(0, available - first.length);
    if (rest) overflow.push({label:`ادامه توضیحات سؤال ${i+1}`,text:rest});
  }
  const [firstSummary, remainingSummary] = cutText(finalText, Math.max(0, available));
  if (remainingSummary) overflow.push({label:"ادامه جمع‌بندی تحقیقات",text:remainingSummary});
  const pages: Continuation[][] = [];
  let page: Continuation[] = [], used = 0;
  for(const item of overflow) {
    let remaining = item.text;
    while(remaining) {
      const room = Math.max(1, 2100-used);
      const [part, tail] = cutText(remaining, room);
      page.push({label:item.label,text:part});
      used += part.length;
      remaining = tail;
      if(used>=2050 || remaining) { pages.push(page);page=[];used=0; }
    }
  }
  if(page.length) pages.push(page);
  return {firstAnswers,firstSummary,pages};
}

function PrintSheets({idPrefix, identity, assignments, children, selected, answers, summary}: {
 idPrefix:string; identity:V2Row|null; assignments:V2Row[]; children:V2Row[];
 selected:number[]; answers:string[]; summary:string; firstPageBudget:number;
}) {
  const parts=useMemo(()=>pageParts(answers,summary,firstPageBudget),[answers,summary,firstPageBudget]);
  const worksheetCount=assignments.reduce((n,row)=>n+num(row.WorksheetCount),0);
  const dateNow=date();
  return <div className={s.sheetStack} dir="rtl">
    <article className={s.sheet} id={`${idPrefix}-0`}>
      <header className={s.header}>
        <div className={s.logo}><img src="/logo/KarbargOstan/mohr.jpg" alt="مهر فرم استان" /></div>
        <div className={s.logoMain}><img src="/logo/KarbargOstan/toplogo.png" alt="عنوان رسمی کاربرگ جمع‌بندی استان"/></div>
        <div className={s.headerMeta}>شماره سریال: .................<p>استان: {text(identity?.NameOstan)}</p><p>حوزه انتخابیه: {text(identity?.NameHozeh)}</p></div>
      </header>
      <section className={s.panel}>
        <strong className={s.sideHeading}>مشخصات داوطلب</strong>
        <div className={s.fields}>
          <span>نام: <b>{text(identity?.FirstName)}</b></span>
          <span>نام خانوادگی: <b>{text(identity?.LastName)}</b></span>
          <span>نام پدر: <b>{text(identity?.NamePedar)}</b></span>
          <span>نام مشهور/مستعار: <b>{text(identity?.NameMostar)}</b></span>
          <span>سال تولد: <b>{text(identity?.SalTavalod)}</b></span>
          <span>شماره ملی: <b dir="ltr">{text(identity?.CodeMelli)}</b></span>
          <span>دین و مذهب: <b>{text(identity?.DinMazhab_NameFarsi)}</b></span>
          <span>شغل: <b>{text(identity?.Shoghl)}</b></span>
          <span>تحصیلات: <b>{text(identity?.Tahsilat)}</b></span>
          <span>سابقه داوطلبی: <b>{text(identity?.Sabeghe)}</b></span>
        </div>
      </section>
      <section className={s.panel}>
        <strong className={s.sideHeading}>مشخصات تحقیقات</strong>
        <div className={s.fields}>
          <span>تعداد کل کاربرگ‌های تحقیق: <b>{worksheetCount.toLocaleString("fa-IR")}</b></span>
          <span>محققان: <b>{assignments.length.toLocaleString("fa-IR")}</b></span>
          <span>ارجاع‌های ثبت‌شده: <b>{children.length.toLocaleString("fa-IR")}</b></span>
          <span>تحقیقات تکمیل‌شده: <b>{assignments.filter(x=>x.StatusCode==="DONE").length.toLocaleString("fa-IR")}</b></span>
        </div>
      </section>
      <section className={s.questions}>
        {questions.map((question, i)=><div className={s.question} key={i}>
          <strong>{question}</strong>
          {i<7 && <div className={s.optionRow}>{radioItems[i].map((option,j)=><span key={j} className={s.option}>
            {option}<span className={`${s.circle} ${selected[i]===j?s.checked:""}`} />
          </span>)}</div>}
          <div className={s.answerLabel}>توضیح با ذکر مصادیق:</div>
          <p className={s.answerText}>{parts.firstAnswers[i] || " "}</p>
        </div>)}
        <div className={s.question}><strong>جمع‌بندی تحقیقات صورت‌گرفته بر اساس مهم‌ترین موارد درج‌شده در کاربرگ‌های تحقیق:</strong>
          <p className={s.answerText}>{parts.firstSummary || " "}</p></div>
      </section>
      <footer className={s.footer}>کارشناس واحد اسناد و بررسی دفتر استان: ................... <span>تاریخ: {dateNow}</span><span>امضا: ..................</span></footer>
    </article>
    {parts.pages.map((entries,i)=><article className={s.sheet} id={`${idPrefix}-${i+1}`} key={i}>
      <header className={s.continuationHeader}><strong>ادامه کاربرگ جمع‌بندی تحقیقات استان</strong><span>صفحه {(i+2).toLocaleString("fa-IR")}</span></header>
      <div className={s.continuationContent}>{entries.map((entry,j)=><section key={j}>
        <strong>{entry.label}</strong><p className={s.answerText}>{entry.text}</p></section>)}</div>
      <footer className={s.footer}>کارشناس واحد اسناد و بررسی دفتر استان <span>تاریخ: {dateNow}</span><span>امضا: ..................</span></footer>
    </article>)}
  </div>;
}

async function imageFile(node: HTMLElement, referralId: number, page: number): Promise<File> {
  const scale=1.3;
  const width=node.scrollWidth, height=node.scrollHeight;
  const pngData=await domtoimage.toPng(node,{ width:width*scale,height:height*scale, bgcolor:"#fff",
    style:{transform:`scale(${scale})`,transformOrigin:"top left",width:`${width}px`,height:`${height}px`}});
  const png=await (await fetch(pngData)).blob();
  if(png.size<=3*1024*1024) return new File([png],`JambandiOstan_${referralId}_${page}.png`,{type:"image/png"});
  const bitmap=await createImageBitmap(png);
  try {
    const canvas=document.createElement("canvas");canvas.width=bitmap.width;canvas.height=bitmap.height;
    canvas.getContext("2d")?.drawImage(bitmap,0,0);
    for(const quality of [0.9,0.78,0.64]) {
      const jpg=await new Promise<Blob|null>(resolve=>canvas.toBlob(resolve,"image/jpeg",quality));
      if(jpg && jpg.size<=3*1024*1024) return new File([jpg],`JambandiOstan_${referralId}_${page}.jpg`,{type:"image/jpeg"});
    }
    throw new Error("حجم تصویر برگه بیشتر از حد مجاز است.");
  } finally {bitmap.close();}
}

export default function ProvinceLegacySummaryForm({referralId, identity, assignments, children, canEdit, summaryId, attachmentReadOnly, onSaved}: {
 referralId:number;identity:V2Row|null;assignments:V2Row[];children:V2Row[];canEdit:boolean;
 summaryId:number|null;attachmentReadOnly:boolean;onSaved:(finalized:boolean)=>Promise<void>;
}) {
  const [selected,setSelected]=useState(choicesBlank);
  const [answers,setAnswers]=useState(blanks);
  const [summary,setSummary]=useState("");
  const [loading,setLoading]=useState(true);
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState("");
  const [notice,setNotice]=useState("");
  const [savedForm,setSavedForm]=useState(false);
  const [finalized,setFinalized]=useState(false);
  const [currentSummaryId,setCurrentSummaryId]=useState<number|null>(summaryId);
  const printRef=useRef<HTMLDivElement>(null);
  const [firstPageBudget,setFirstPageBudget]=useState(620);
  useEffect(()=>{let active=true;setLoading(true);setError("");
    void meratV2Request(`/Api/TahghighV2/ProvinceLegacySummary?referralId=${referralId}`)
      .then(rows=>{
        if(!active)return;
        const item=rows[0];
        if(item?.FormDataJson) {
          const data=JSON.parse(String(item.FormDataJson)) as {selected?:number[];answers?:string[];summary?:string};
          if(Array.isArray(data.selected)&&data.selected.length===7)setSelected(data.selected);
          if(Array.isArray(data.answers)&&data.answers.length===8)setAnswers(data.answers);
          setSummary(String(data.summary??item?.SummaryText??""));setSavedForm(true);setFinalized(Boolean(item?.IsFormFinalized));setFirstPageBudget(620);
        } else {
          setSummary(String(item?.SummaryText??""));setSelected(choicesBlank());setAnswers(blanks());setSavedForm(false);setFinalized(false);setFirstPageBudget(620);
        }
        const id=Number(item?.SummaryId??0);
        if(id>0)setCurrentSummaryId(id);
      })
      .catch(e=>{if(active)setError(e instanceof Error?e.message:"دریافت فرم جمع‌بندی انجام نشد.");})
      .finally(()=>{if(active)setLoading(false);});
    return()=>{active=false;};
  },[referralId]);
  const validate=useCallback(()=>{
    for(let i=0;i<7;i++) if(!Number.isInteger(selected[i])||selected[i]<0||selected[i]>=radioItems[i].length)
      return `گزینه سؤال ${i+1} را انتخاب کنید.`;
    for(let i=0;i<8;i++) if(!answers[i]?.trim())return `توضیح سؤال ${i+1} را وارد کنید.`;
    if(!summary.trim())return "متن جمع‌بندی نهایی را وارد کنید.";
    return "";
  },[selected,answers,summary]);
  // Measure the actual original-size print sheet, rather than using character
  // count alone to decide when text no longer fits on the first page.
  useEffect(()=>{
    if(loading)return;
    const first=printRef.current?.querySelector<HTMLElement>("article");
    if(!first)return;
    const raf=requestAnimationFrame(()=>{
      const height=first.getBoundingClientRect().height;
      if(height>1767 && firstPageBudget>0) {
        const decrease=Math.max(50,Math.ceil((height-1761)*0.75));
        setFirstPageBudget(current=>Math.max(0,current-decrease));
      }
    });
    return()=>cancelAnimationFrame(raf);
  },[answers,summary,selected,firstPageBudget,loading]);
  const pages=useMemo(()=>pageParts(answers,summary,firstPageBudget).pages.length+1,[answers,summary,firstPageBudget]);
  const save=async(withImages:boolean)=>{
    if(!canEdit||busy)return;
    const message=validate();if(message){setError(message);return;}
    setBusy(true);setError("");setNotice("");
    try{
      await meratV2Request("/Api/TahghighV2/ProvinceLegacySummary",{
        referralId,selected,answers,summaryText:summary.trim(),
      });
      setSavedForm(true);setFinalized(false);
      await onSaved(false);
      if(!withImages){setNotice("فرم و پاسخ‌ها ذخیره شدند؛ تصویری تولید یا پیوست نشد.");return;}
      const [record]=await meratV2Request(`/Api/TahghighV2/ProvinceSummaryAttachmentTarget?referralId=${referralId}`);
      const targetId=Number(record?.SummaryId??0);
      if(!Number.isSafeInteger(targetId)||targetId<=0||!Boolean(record?.CanWrite))
        throw new Error("اطلاعات فرم ذخیره شد، اما اجازه ثبت تصویر جمع‌بندی در دسترس نیست.");
      setCurrentSummaryId(targetId);
      const uploadedIds:string[]=[];
      const root=printRef.current;
      if(!root)throw new Error("صفحات چاپ فرم پیدا نشدند.");
      const nodes=Array.from(root.querySelectorAll<HTMLElement>("article"));
      for(let i=0;i<nodes.length;i++){
        const file=await imageFile(nodes[i],referralId,i+1);
        const body=new FormData();body.append("targetEntity","PROVINCE_SUMMARY");body.append("targetRecordId",String(targetId));body.append("file",file);
        const res=await fetch("/Api/TahghighV2/DocumentAttachments",{method:"POST",body,credentials:"same-origin"});
        const payload=await res.json() as {ok?:boolean;message?:string;attachmentId?:string};
        if(!res.ok||!payload.ok||!payload.attachmentId)throw new Error(payload.message||"بارگذاری تصویر فرم موفق نبود.");
        uploadedIds.push(payload.attachmentId);
      }
      await meratV2Request("/Api/TahghighV2/ProvinceLegacySummaryFinalize",{referralId,attachmentIds:uploadedIds});
      setFinalized(true);
      await onSaved(true);
      setNotice(`فرم نهایی شد و ${nodes.length.toLocaleString("fa-IR")} صفحه تصویری به پیوست‌های جمع‌بندی اضافه شد.`);
    }catch(e){setError(e instanceof Error?e.message:"خطا در ذخیره فرم جمع‌بندی.");}
    finally{setBusy(false);}
  };
  return <div dir="rtl" className={s.root}>
    <div className={s.toolbar}>
      <strong>کاربرگ رسمی جمع‌بندی تحقیقات استان</strong>
      <span>فرم نسخه قدیمی • ۸ سؤال، ۷ گروه گزینه‌ای، پاسخ‌های تشریحی</span>
      <span>{pages.toLocaleString("fa-IR")} صفحه</span>
    </div>
    {loading?<p>در حال دریافت اطلاعات فرم…</p>:<>
      {error&&<p role="alert" className={s.error}>{error}</p>}
      {notice&&<p role="status" className={s.success}>{notice}</p>}
      {!canEdit&&<p className={s.info}>تا زمان دریافت تمام پاسخ ارجاعات، فرم فقط قابل مشاهده است.</p>}
      <div className={s.editor}>
        {questions.map((q,i)=><section className={s.editQuestion} key={i}>
          <strong>{q}</strong>
          {i<7&&<div className={s.editOptions} role="radiogroup" aria-label={`گزینه سؤال ${i+1}`}>
            {radioItems[i].map((option,j)=><label key={j}><input type="radio" name={`province-option-${referralId}-${i}`} checked={selected[i]===j} disabled={!canEdit||busy}
              onChange={()=>{setSelected(p=>p.map((v,k)=>i===k?j:v));setFirstPageBudget(620);}}/>{option}</label>)}
          </div>}
          <label className={s.editLabel} htmlFor={`province-answer-${referralId}-${i}`}>توضیح با ذکر مصادیق:</label>
          <textarea id={`province-answer-${referralId}-${i}`} rows={2} maxLength={6000} disabled={!canEdit||busy}
            value={answers[i]} onChange={e=>{setAnswers(p=>p.map((v,k)=>k===i?e.target.value:v));setFirstPageBudget(620);}}/>
        </section>)}
        <section className={s.editQuestion}><label className={s.editLabel} htmlFor={`province-conclusion-${referralId}`}>
          جمع‌بندی تحقیقات صورت‌گرفته براساس مهم‌ترین موارد درج‌شده در کاربرگ‌های تحقیق:</label>
          <textarea id={`province-conclusion-${referralId}`} rows={5} maxLength={12000} disabled={!canEdit||busy}
            value={summary} onChange={e=>{setSummary(e.target.value);setFirstPageBudget(620);}}/>
        </section>
      </div>
      <div className={s.actions}>
        <button type="button" disabled={!canEdit||busy} onClick={()=>void save(false)}>{busy?"در حال ذخیره…":"ذخیره فرم بدون تولید تصویر"}</button>
        <button type="button" className={s.primary} disabled={!canEdit||busy} onClick={()=>void save(true)}>{busy?"در حال ثبت…":"ثبت فرم و تولید تصاویر رسمی"}</button>
        {savedForm&&<span className={s.saved}>{finalized?"فرم نهایی و تصویری ثبت شده است":"پاسخ‌ها ذخیره شده‌اند؛ هنوز نهایی نشده است"}</span>}
      </div>
      <h3 className={s.previewTitle}>پیش‌نمایش فرم رسمی چاپی</h3>
      <PrintSheets idPrefix={`province-preview-${referralId}`} identity={identity} assignments={assignments} children={children}
        selected={selected} answers={answers} summary={summary} firstPageBudget={firstPageBudget}/>
      {currentSummaryId!==null&&<div className={s.attachmentBlock}>
        <SummaryAttachmentsPanel level="PROVINCE" summaryRecordId={currentSummaryId} readOnly={!canEdit||busy||attachmentReadOnly}/>
      </div>}
      <div ref={printRef} className={s.printStaging} aria-hidden="true">
        <PrintSheets idPrefix={`province-print-${referralId}`} identity={identity} assignments={assignments} children={children}
          selected={selected} answers={answers} summary={summary} firstPageBudget={firstPageBudget}/>
      </div>
    </>}
  </div>;
}
