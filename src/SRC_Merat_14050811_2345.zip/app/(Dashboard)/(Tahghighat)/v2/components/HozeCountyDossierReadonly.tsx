"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { meratV2Request, type V2Row } from "@/app/lib/meratV2/client";
import s from "../hoze/HozeCase.module.css";

type Assigned = { AssignmentId: number; FullName: string; StatusCode: string; Summary: string | null; WorksheetCount: number; DueDatePersian?: string | null; Instruction?: string | null };
type Worksheet = { WorksheetId: number; AssignmentId: number; ReportText: string; Description?: string | null; NahveAshnai?: string | null; AzSal?: number; TaSal?: number; NameSazman?: string | null; NameShahr?: string | null; PeyvastCount?: number | null };
type Doc = { AttachmentId: string; TargetEntity: string; TargetRecordId: number; AttachmentKind?: string | null; SummaryLevel?: string | null; OriginalFileName: string; MimeType: string; FileSizeBytes: number; AttachmentDescription?: string | null };
const parseRows = <T,>(input: unknown): T[] => {
  try { const arr: unknown = JSON.parse(typeof input === "string" ? input : "[]"); return Array.isArray(arr) ? arr as T[] : []; }
  catch { return []; }
};
const fa = (v: number) => v.toLocaleString("fa-IR");
const isImg = (mime: string) => /^image\/(png|jpeg|webp)$/.test(mime);

/** Fullscreen read-only evidence: wheel/pinch zoom, finger or mouse drag. */
function CountyFileZoom({ src, name, onClose }: { src: string; name: string; onClose: () => void }) {
  const [scale, setScale] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const pointers = useRef(new Map<number, { x: number; y: number }>());
  const lastDistance = useRef<number | null>(null);
  const clamp = (n: number) => Math.max(1, Math.min(6, n));
  const setZoom = (next: number) => { setScale(clamp(next)); if (next <= 1) setOffset({ x: 0, y: 0 }); };
  useEffect(() => {
    const esc = (e: KeyboardEvent) => { if (e.key === "Escape") { e.stopImmediatePropagation(); onClose(); } };
    document.addEventListener("keydown", esc, true);
    return () => document.removeEventListener("keydown", esc, true);
  }, [onClose]);
  const distance = () => {
    const ps = [...pointers.current.values()];
    return ps.length >= 2 ? Math.hypot(ps[0].x-ps[1].x, ps[0].y-ps[1].y) : null;
  };
  return <div className={s.countyImageOverlay} role="dialog" aria-modal="true" aria-label={`بزرگنمایی ${name}`}>
    <div className={s.countyImageToolbar}>
      <strong>{name}</strong>
      <button type="button" onClick={() => setZoom(scale / 1.25)} aria-label="کوچک‌نمایی">−</button>
      <span>{Math.round(scale * 100).toLocaleString("fa-IR")}٪</span>
      <button type="button" onClick={() => setZoom(scale * 1.25)} aria-label="بزرگنمایی">+</button>
      <button type="button" onClick={() => setZoom(1)}>اندازه اصلی</button>
      <button type="button" onClick={onClose} aria-label="بستن تصویر">×</button>
    </div>
    <div className={s.countyImageStage}
      onWheel={e => { e.preventDefault(); setZoom(scale * (e.deltaY < 0 ? 1.12 : 1 / 1.12)); }}
      onPointerDown={e => {
        e.currentTarget.setPointerCapture(e.pointerId);
        pointers.current.set(e.pointerId, { x:e.clientX,y:e.clientY });
        lastDistance.current = distance();
      }}
      onPointerMove={e => {
        const prev = pointers.current.get(e.pointerId);
        if (!prev) return;
        pointers.current.set(e.pointerId,{ x:e.clientX,y:e.clientY });
        const dist = distance();
        if (dist !== null && lastDistance.current !== null && lastDistance.current > 1) {
          const ratio = dist / lastDistance.current;
          setScale(v => clamp(v * ratio));
        } else if (pointers.current.size === 1 && scale > 1) {
          setOffset(v => ({ x:v.x+e.clientX-prev.x, y:v.y+e.clientY-prev.y }));
        }
        lastDistance.current = dist;
      }}
      onPointerUp={e => { pointers.current.delete(e.pointerId); lastDistance.current=distance(); }}
      onPointerCancel={e => { pointers.current.delete(e.pointerId); lastDistance.current=distance(); }}>
      <img src={src} alt={name} draggable={false} style={{transform:`translate(${offset.x}px, ${offset.y}px) scale(${scale})`}} />
    </div>
    <div className={s.countyImageHint}>اسکرول موس برای بزرگنمایی · لمس دو انگشتی برای زوم · نگه‌داشتن و کشیدن برای جابه‌جایی</div>
  </div>;
}

export default function HozeCountyDossierReadonly({ hozeReferralId, countyReferralId, onClose }: {
  hozeReferralId: number; countyReferralId: number; onClose: () => void;
}) {
  const [result, setResult] = useState<V2Row | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [expanded, setExpanded] = useState<number | null>(null);
  const [zoomDoc, setZoomDoc] = useState<Doc | null>(null);

  useEffect(() => {
    let alive = true;
    const load = async () => {
      setLoading(true); setError(""); setResult(null);
      try {
        const [row] = await meratV2Request(`/Api/TahghighV2/HozeCountyDossier?hozeReferralId=${hozeReferralId}&countyReferralId=${countyReferralId}`);
        if (!row) throw new Error("اطلاعات شهرستان در این ارجاع یافت نشد.");
        if (alive) setResult(row);
      } catch (e) { if (alive) setError(e instanceof Error ? e.message : "دریافت گزارش شهرستان انجام نشد."); }
      finally { if (alive) setLoading(false); }
    };
    void load();
    return () => { alive = false; };
  }, [hozeReferralId, countyReferralId]);

  useEffect(() => {
    const onEsc = (event: KeyboardEvent) => { if (event.key === "Escape" && !zoomDoc) onClose(); };
    document.addEventListener("keydown", onEsc);
    return () => document.removeEventListener("keydown", onEsc);
  }, [onClose, zoomDoc]);

  const assignments = useMemo(() => parseRows<Assigned>(result?.AssignmentsJson), [result]);
  const worksheets = useMemo(() => parseRows<Worksheet>(result?.WorksheetsJson), [result]);
  const documents = useMemo(() => parseRows<Doc>(result?.DocumentsJson), [result]);
  const fileUrl = (doc: Doc) => `/Api/TahghighV2/HozeCountyDossierFile?hozeReferralId=${hozeReferralId}&countyReferralId=${countyReferralId}&attachmentId=${encodeURIComponent(doc.AttachmentId)}`;

  const renderFiles = (items: Doc[]) => items.length ? (
    <div className={s.countyFiles}>{items.map(doc => isImg(doc.MimeType) ? (
      <button type="button" key={doc.AttachmentId} className={s.countyFile}
        onClick={() => setZoomDoc(doc)} title="بزرگنمایی سند (فقط خواندنی)">
        <img src={fileUrl(doc)} alt={doc.OriginalFileName || "تصویر سند"} loading="lazy" />
        <span>{doc.OriginalFileName || "تصویر سند"}</span>
        {doc.AttachmentDescription && <small>{doc.AttachmentDescription}</small>}
      </button>
    ) : <a key={doc.AttachmentId} href={fileUrl(doc)} target="_blank" rel="noopener noreferrer"
      className={s.countyFile} title="نمایش پیوست فقط خواندنی">
      <span>{doc.OriginalFileName || "سند پیوست"}</span><small>مشاهده سند</small>
    </a>)}</div>
  ) : <p className={s.hint}>پیوستی ثبت نشده است.</p>;

  return <><div className={s.modalOverlay} role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}>
    <section className={`${s.modal} ${s.countyReadonlyModal}`} role="dialog" aria-modal="true" aria-labelledby="county-dossier-title" dir="rtl">
      <header className={s.modalHeader}>
        <div>
          <strong id="county-dossier-title">گزارش دریافتی شهرستان {String(result?.CountyName ?? "")}</strong>
          <p className={s.replyHeaderHint}>تعداد محققان، کاربرگ‌های تحقیق، اسناد و جمع‌بندی‌های شهرستان — فقط خواندنی</p>
        </div>
        <button type="button" className={s.modalClose} aria-label="بستن گزارش شهرستان" onClick={onClose}>×</button>
      </header>
      <div className={`${s.modalBody} ${s.countyReadonlyBody}`}>
        {loading && <p className={s.hint}>در حال دریافت پرونده و پیوست‌های شهرستان…</p>}
        {error && <div className={s.error} role="alert">{error}</div>}
        {result && <>
          <div className={s.countyReadonlyStats}>
            <span>کل محققان: <b>{fa(assignments.length)}</b></span>
            <span>تحقیقات تکمیل‌شده: <b>{fa(assignments.filter(a => a.StatusCode === "DONE").length)}</b></span>
            <span>کاربرگ‌ها: <b>{fa(worksheets.length)}</b></span>
            <span>پیوست‌ها: <b>{fa(documents.length)}</b></span>
          </div>
          <section className={s.countyReadonlySection}>
            <strong>متن نهایی ارسالی شهرستان به حوزه</strong>
            <div className={s.countyReadonlyText}>{String(result.CountyReplyText || "هنوز متن نهایی از شهرستان ثبت نشده است.")}</div>
          </section>
          <section className={s.countyReadonlySection}>
            <strong>محققان شهرستان و سوابق هر محقق ({fa(assignments.length)})</strong>
            {!assignments.length && <p className={s.hint}>محققی برای این شهرستان ثبت نشده است.</p>}
            {assignments.map((a, i) => {
              const ownWorksheets = worksheets.filter(w => Number(w.AssignmentId) === Number(a.AssignmentId));
              const ownDocs = documents.filter(d => d.TargetEntity === "RESEARCH_ASSIGNMENT" && Number(d.TargetRecordId) === Number(a.AssignmentId));
              const open = expanded === Number(a.AssignmentId);
              return <article key={a.AssignmentId} className={s.countyReadonlyInvestigator}>
                <button type="button" className={s.countyReadonlyInvestigatorHeader} aria-expanded={open} onClick={() => setExpanded(open ? null : Number(a.AssignmentId))}>
                  <span><b>{fa(i + 1)}. {a.FullName}</b> — محقق شهرستان {String(result.CountyName ?? "")}</span>
                  <span>{a.StatusCode === "DONE" ? "تکمیل‌شده" : a.StatusCode === "CANCELLED" ? "بازپس‌گرفته‌شده" : "در جریان"} · {fa(ownWorksheets.length)} کاربرگ {open ? "▴" : "▾"}</span>
                </button>
                {open && <div className={s.countyReadonlyInvestigatorBody}>
                  {a.Instruction && <div className={s.countyReadonlySubtext}><b>شرح مأموریت:</b> {a.Instruction}</div>}
                  <strong>جمع‌بندی اصلی محقق</strong>
                  <div className={s.countyReadonlyText}>{a.Summary?.trim() || "متن جمع‌بندی ثبت نشده است."}</div>
                  <strong>تصاویر و اسناد جمع‌بندی محقق</strong>
                  {renderFiles(ownDocs)}
                  <strong>کاربرگ‌های تحقیق ({fa(ownWorksheets.length)})</strong>
                  {ownWorksheets.map((w, wi) => <div key={w.WorksheetId} className={s.countyReadonlyWorksheet}>
                    <div className={s.countyReadonlyWorksheetHead}><b>کاربرگ {fa(wi + 1)}</b><span>شماره {fa(w.WorksheetId)}</span></div>
                    {w.ReportText && <div className={s.countyReadonlyText}>{w.ReportText}</div>}
                    {w.Description && w.Description !== w.ReportText && <div className={s.countyReadonlyText}>{w.Description}</div>}
                    {!w.ReportText && !w.Description && <p className={s.hint}>توضیحات کاربرگ ثبت نشده است.</p>}
                    {w.NahveAshnai && <p className={s.countyReadonlySubtext}>نحوه آشنایی: {w.NahveAshnai}{w.AzSal != null && w.TaSal != null ? ` · از ${fa(w.AzSal)} تا ${fa(w.TaSal)}` : ""}</p>}
                    {(w.NameSazman || w.NameShahr) && <p className={s.countyReadonlySubtext}>{[w.NameSazman, w.NameShahr].filter(Boolean).join(" · ")}</p>}
                    <strong>اسناد و پیوست‌های کاربرگ</strong>
                    {renderFiles(documents.filter(d => d.TargetEntity === "RESEARCH_WORKSHEET" && Number(d.TargetRecordId) === Number(w.WorksheetId)))}
                  </div>)}
                </div>}
              </article>;
            })}
          </section>
        </>}
      </div>
      <div className={s.modalActions}><button type="button" className={s.outlineButton} onClick={onClose}>بستن</button></div>
    </section>
  </div>
  {zoomDoc && <CountyFileZoom src={fileUrl(zoomDoc)} name={zoomDoc.OriginalFileName || "سند تحقیق"} onClose={() => setZoomDoc(null)}/>}
  </>;
}
