-- Only run this SQL file on the Merat database after backing it up.
-- Targeted patch: investigator summary saves for HOZE / SHAHR.
-- The application must be deployed with the updated API error handler.
IF SCHEMA_ID(N'TahghighatV2') IS NULL
  THROW 55980,N'اسکیمای تحقیقات نسخه دوم نصب نشده است.',1;
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_SaveHozeInvestigatorSummary
 @AssignmentId bigint,@SummaryText nvarchar(max),@UserId bigint
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 SET @SummaryText=LTRIM(RTRIM(ISNULL(@SummaryText,N'')));
 IF @AssignmentId IS NULL OR @AssignmentId<=0 OR @UserId IS NULL OR @UserId<=0
   OR LEN(@SummaryText)<50 OR LEN(@SummaryText)>12000
   THROW 55003,N'متن جمع‌بندی باید بین ۵۰ تا ۱۲۰۰۰ نویسه باشد.',1;
 DECLARE @Mahal int,@Post int,@Hoze bigint,@Root bigint,@Status varchar(20),@Lock int;
 SELECT @Mahal=u.Mahal,@Post=u.PostId FROM dbo.Users u WHERE u.UserId=@UserId AND u.IsActive=1;
 IF @Post NOT IN(60,61)
   OR NOT EXISTS(SELECT 1 FROM dbo.Citys c WHERE c.CityId=@Mahal AND c.IsHoze=1 AND c.IsActive=1)
   OR NOT EXISTS(SELECT 1 FROM TahghighatV2.PostActionPermission ap WHERE ap.PostId=@Post
     AND ap.ActionCode='HOZE_OFFICER_SAVE_WORKSHEET' AND ap.IsAllowed=1)
   THROW 55004,N'مجوز ثبت جمع‌بندی محقق حوزه وجود ندارد.',1;
 SELECT @Hoze=r.ReferralId,@Root=r.ParentReferralId
 FROM TahghighatV2.ResearchAssignment a
 JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId AND r.ReceiverLevel='HOZE'
 WHERE a.AssignmentId=@AssignmentId AND r.ToMahal=@Mahal AND r.IsDeleted=0;
 IF @Root IS NULL THROW 55005,N'انتساب محقق مربوط به این حوزه نیست.',1;
 BEGIN TRY
  BEGIN TRANSACTION;
  DECLARE @Resource nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(20),@Root);
  EXEC @Lock=sys.sp_getapplock @Resource=@Resource,@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
  IF @Lock<0 THROW 55006,N'پرونده در حال پردازش است.',1;
  SELECT @Status=a.StatusCode FROM TahghighatV2.ResearchAssignment a WITH(UPDLOCK,HOLDLOCK)
  JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId
  JOIN TahghighatV2.Referral parent ON parent.ReferralId=r.ParentReferralId
  WHERE a.AssignmentId=@AssignmentId AND r.ReferralId=@Hoze AND r.ReceiverLevel='HOZE'
   AND r.ToMahal=@Mahal AND r.IsDeleted=0 AND r.IsClosed=0 AND r.StateCode='CHILD_WORKING'
   AND parent.ReferralId=@Root AND parent.IsDeleted=0 AND parent.IsClosed=0 AND parent.StateCode='PENDING_CHILD_RESULTS';
  IF @Status IS NULL OR @Status<>'IN_PROGRESS'
     THROW 55007,N'انتساب در وضعیت قابل ثبت جمع‌بندی نیست.',1;
  IF NOT EXISTS(SELECT 1 FROM TahghighatV2.ResearchWorksheet w WITH(HOLDLOCK) WHERE w.AssignmentId=@AssignmentId)
     THROW 55008,N'ابتدا دست‌کم یک کاربرگ ثبت کنید.',1;
  UPDATE TahghighatV2.ResearchAssignment SET Summary=@SummaryText WHERE AssignmentId=@AssignmentId AND StatusCode='IN_PROGRESS';
  IF @@ROWCOUNT<>1 THROW 55009,N'وضعیت انتساب تغییر کرده است.',1;
  INSERT TahghighatV2.ResearchAssignmentEvent(AssignmentId,ActionCode,BeforeStatus,AfterStatus,Description,ActorUserId)
   VALUES(@AssignmentId,'HOZE_SAVE_SUMMARY','IN_PROGRESS','IN_PROGRESS',N'ثبت و ویرایش فرم رسمی جمع‌بندی محقق',@UserId);
  COMMIT;
  SELECT CONVERT(bit,1) IsSuccess,@AssignmentId AssignmentId;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK; THROW; END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE TahghighatV2.SP_SaveCountyInvestigatorSummary
 @AssignmentId bigint,@SummaryText nvarchar(max),@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 SET @SummaryText=LTRIM(RTRIM(ISNULL(@SummaryText,N'')));
 IF ISNULL(@AssignmentId,0)<=0 OR LEN(@SummaryText)<50 OR LEN(@SummaryText)>12000
 THROW 55122,N'جمع‌بندی محقق باید بین ۵۰ تا ۱۲۰۰۰ نویسه باشد.',1;
 DECLARE @County int,@Post int,@CountyRef bigint,@Hoze bigint,@Root bigint,@Status varchar(20),@Lock int;
 SELECT @County=Mahal,@Post=PostId FROM dbo.Users WHERE UserId=@UserId AND IsActive=1;
 SELECT @CountyRef=r.ReferralId,@Hoze=h.ReferralId,@Root=h.ParentReferralId
 FROM TahghighatV2.ResearchAssignment a JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId AND r.ReceiverLevel='SHAHR'
 JOIN TahghighatV2.Referral h ON h.ReferralId=r.ParentReferralId AND h.ReceiverLevel='HOZE'
 JOIN TahghighatV2.CountyRepresentative cr ON cr.AuthUserId=@UserId AND cr.CountyCityId=r.ToMahal
 AND cr.HozeCityId=h.ToMahal AND cr.IsActive=1
 WHERE a.AssignmentId=@AssignmentId AND r.ToMahal=@County AND r.IsDeleted=0;
 IF @Post<>70 OR @Root IS NULL THROW 55123,N'مجوز جمع‌بندی محقق این شهرستان وجود ندارد.',1;
 BEGIN TRY BEGIN TRANSACTION;
 DECLARE @LockName nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(20),@Root);
 EXEC @Lock=sys.sp_getapplock @Resource=@LockName,@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @Lock<0 THROW 55124,N'پرونده در حال پردازش است.',1;
 SELECT @Status=a.StatusCode FROM TahghighatV2.ResearchAssignment a WITH(UPDLOCK,HOLDLOCK)
 JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId
 JOIN TahghighatV2.Referral h ON h.ReferralId=r.ParentReferralId
 JOIN TahghighatV2.Referral root ON root.ReferralId=h.ParentReferralId
 WHERE a.AssignmentId=@AssignmentId AND r.ReferralId=@CountyRef AND r.StateCode='CHILD_WORKING'
 AND r.IsClosed=0 AND r.IsDeleted=0 AND h.StateCode='CHILD_WORKING' AND h.IsClosed=0 AND h.IsDeleted=0
 AND root.ReferralId=@Root AND root.StateCode='PENDING_CHILD_RESULTS' AND root.IsClosed=0 AND root.IsDeleted=0;
 IF @Status<>'IN_PROGRESS' OR @Status IS NULL THROW 55125,N'محقق در وضعیت قابل جمع‌بندی نیست.',1;
 IF NOT EXISTS(SELECT 1 FROM TahghighatV2.ResearchWorksheet WHERE AssignmentId=@AssignmentId)
 THROW 55126,N'ابتدا کاربرگ تحقیق ثبت کنید.',1;
 UPDATE TahghighatV2.ResearchAssignment SET Summary=@SummaryText WHERE AssignmentId=@AssignmentId;
 INSERT TahghighatV2.ResearchAssignmentEvent(AssignmentId,ActionCode,BeforeStatus,AfterStatus,Description,ActorUserId)
 VALUES(@AssignmentId,'COUNTY_SAVE_SUMMARY','IN_PROGRESS','IN_PROGRESS',N'ثبت فرم جمع‌بندی محقق شهرستان',@UserId);
 COMMIT;SELECT CONVERT(bit,1) IsSuccess;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK;THROW;END CATCH;
END;
GO
