/* Merat V2 - investigator summary first-image upload fix.
   Run in the MERAT application database; MeratFilesDB must be available.
   Keeps ordinary assignment documents intact and supports zero preexisting summary images.
   Back up the database before deployment. */
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_ReplaceInvestigatorSummaryImage
    @AssignmentId bigint,
    @Scope varchar(10),                -- OSTAN | HOZE | COUNTY
    @UserId bigint,
    @ExpectedAttachmentIds nvarchar(1000),
    @OriginalFileName nvarchar(255),
    @MimeType nvarchar(100),
    @FileData varbinary(max)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    IF @AssignmentId IS NULL OR @AssignmentId<=0 OR @UserId IS NULL OR @UserId<=0
       OR @Scope NOT IN ('OSTAN','HOZE','COUNTY') OR @Scope IS NULL
        THROW 56701,N'شناسه انتساب، کاربر یا محدوده معتبر نیست.',1;
    IF @ExpectedAttachmentIds IS NULL OR LEN(@ExpectedAttachmentIds)>1000
        THROW 56702,N'فهرست اسناد پیشین معتبر نیست.',1;
    IF @OriginalFileName IS NULL OR @OriginalFileName NOT LIKE N'JambandiMohaghegh[_]%.%'
       OR LEN(@OriginalFileName)>255 OR CHARINDEX(N'/',@OriginalFileName)>0
       OR CHARINDEX(N'\',@OriginalFileName)>0
       OR DATALENGTH(@FileData) NOT BETWEEN 1 AND 3145728
       OR NOT ((@MimeType=N'image/png' AND SUBSTRING(@FileData,1,8)=0x89504E470D0A1A0A)
             OR (@MimeType=N'image/jpeg' AND SUBSTRING(@FileData,1,3)=0xFFD8FF))
        THROW 56703,N'تصویر جدید جمع‌بندی معتبر نیست.',1;

    DECLARE @Expected TABLE (AttachmentId uniqueidentifier PRIMARY KEY);
    IF LEN(@ExpectedAttachmentIds)>0
    BEGIN
        IF EXISTS(SELECT 1 FROM STRING_SPLIT(@ExpectedAttachmentIds,N',')
                  WHERE TRY_CONVERT(uniqueidentifier,value) IS NULL OR LTRIM(RTRIM(value))=N'')
            THROW 56704,N'فهرست شناسه پیوست‌ها نامعتبر است.',1;
        IF (SELECT COUNT(*) FROM STRING_SPLIT(@ExpectedAttachmentIds,N','))>20
            THROW 56704,N'تعداد اسناد پیشین نامعتبر است.',1;
        BEGIN TRY
            INSERT @Expected(AttachmentId)
            SELECT CONVERT(uniqueidentifier,value) FROM STRING_SPLIT(@ExpectedAttachmentIds,N',');
        END TRY BEGIN CATCH
            THROW 56704,N'شناسه تکراری یا نامعتبر در فهرست پیوست‌ها وجود دارد.',1;
        END CATCH;
    END;

    DECLARE @CaseId bigint,@Number bigint,@PersonId bigint,@ReferralId bigint,
            @RootId bigint,@CanWrite bit,@InvestigatorKey bigint,@InvestigatorPersonId bigint,
            @InvestigatorLegacyCode bigint,@Lock int,@FileId uniqueidentifier=NEWID();
    DECLARE @Access TABLE (
      CaseId bigint,ShomarehParvandeh bigint,PersonId bigint NULL,
      ReferralId bigint,AssignmentId bigint NULL,RootReferralId bigint,
      CanRead bit,CanWrite bit
    );

    BEGIN TRY
      BEGIN TRANSACTION;
      -- The same access checks used for normal attachment uploads apply here.
      -- A client-provided role or level never grants permissions by itself.
      IF @Scope='OSTAN'
      BEGIN
        SELECT TOP(1) @CaseId=sc.CaseId,@Number=sc.ShomarehParvandeh,
          @PersonId=sc.CasePersonId,@ReferralId=sc.ReferralId,
          @RootId=sc.RootReferralId,@InvestigatorKey=sc.InvestigatorKey,
          @InvestigatorPersonId=sc.InvestigatorPersonId,
          @InvestigatorLegacyCode=sc.InvestigatorLegacyCode
        FROM TahghighatV2.fn_ProvinceInvestigatorDocumentScope
          ('RESEARCH_ASSIGNMENT',@AssignmentId,@UserId) sc
        JOIN TahghighatV2.Referral r ON r.ReferralId=sc.ReferralId
        WHERE sc.CanWrite=1 AND sc.AssignmentId=@AssignmentId AND r.ReceiverLevel='OSTAN';
      END
      ELSE
      BEGIN
        INSERT @Access
        EXEC TahghighatV2.SP_UnifiedAttachmentTargetAccess
             'RESEARCH_ASSIGNMENT',@AssignmentId,@UserId;
        SELECT TOP(1) @CaseId=sc.CaseId,@Number=sc.ShomarehParvandeh,
          @PersonId=sc.PersonId,@ReferralId=sc.ReferralId,@RootId=sc.RootReferralId
        FROM @Access sc
        JOIN TahghighatV2.Referral r ON r.ReferralId=sc.ReferralId
        WHERE sc.AssignmentId=@AssignmentId AND sc.CanWrite=1
          AND r.ReceiverLevel=CASE WHEN @Scope='HOZE' THEN 'HOZE' ELSE 'SHAHR' END;
      END;
      IF @CaseId IS NULL OR @RootId IS NULL OR @ReferralId IS NULL
        THROW 56705,N'مجوز جایگزینی تصویر جمع‌بندی در این انتساب وجود ندارد.',1;
      IF NOT EXISTS (SELECT 1 FROM TahghighatV2.InvestigatorSummary
                     WHERE AssignmentId=@AssignmentId)
        THROW 56706,N'ابتدا متن جمع‌بندی محقق را ثبت کنید.',1;

      DECLARE @Resource nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(25),@RootId);
      EXEC @Lock=sys.sp_getapplock @Resource=@Resource,
          @LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
      IF @Lock<0 THROW 56707,N'پرونده همزمان در حال پردازش است.',1;

      -- Re-check permission after serializing the whole referral tree.
      SET @CanWrite=0;
      IF @Scope='OSTAN'
      BEGIN
        IF EXISTS(SELECT 1 FROM TahghighatV2.fn_ProvinceInvestigatorDocumentScope
                   ('RESEARCH_ASSIGNMENT',@AssignmentId,@UserId) sc
                  WHERE sc.CanWrite=1 AND sc.CaseId=@CaseId AND sc.ReferralId=@ReferralId
                    AND sc.AssignmentId=@AssignmentId)
            SET @CanWrite=1;
      END
      ELSE
      BEGIN
        DELETE FROM @Access;
        INSERT @Access EXEC TahghighatV2.SP_UnifiedAttachmentTargetAccess
            'RESEARCH_ASSIGNMENT',@AssignmentId,@UserId;
        IF EXISTS(SELECT 1 FROM @Access
                  WHERE CanWrite=1 AND CaseId=@CaseId AND ReferralId=@ReferralId
                    AND AssignmentId=@AssignmentId) SET @CanWrite=1;
      END;
      IF @CanWrite<>1 THROW 56708,N'دسترسی ویرایش پیوست دیگر معتبر نیست.',1;

      DECLARE @FileResource nvarchar(255)=N'MRV2:FILE:RESEARCH_ASSIGNMENT:'+CONVERT(nvarchar(25),@AssignmentId);
      EXEC @Lock=sys.sp_getapplock @Resource=@FileResource,
          @LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
      IF @Lock<0 THROW 56709,N'اسناد همزمان در حال تغییر هستند.',1;

      -- Confirm that the user approved exactly the current document set.
      DECLARE @ExistingCount int;
      SELECT @ExistingCount=COUNT(*)
      FROM MeratFilesDB.dbo.TahghighatDocument WITH(UPDLOCK,HOLDLOCK)
      WHERE TargetEntity='RESEARCH_ASSIGNMENT' AND TargetRecordId=@AssignmentId AND IsDeleted=0 AND AttachmentKind='SUMMARY' AND SummaryLevel='INVESTIGATOR';
      IF @ExistingCount<>(SELECT COUNT(*) FROM @Expected)
         OR EXISTS(
           SELECT 1 FROM MeratFilesDB.dbo.TahghighatDocument d
           WHERE d.TargetEntity='RESEARCH_ASSIGNMENT' AND d.TargetRecordId=@AssignmentId
             AND d.IsDeleted=0 AND d.AttachmentKind='SUMMARY' AND d.SummaryLevel='INVESTIGATOR'
             AND NOT EXISTS(SELECT 1 FROM @Expected e WHERE e.AttachmentId=d.AttachmentId)
         )
        THROW 56710,N'فهرست تصاویر جمع‌بندی تغییر کرده است؛ صفحه را تازه‌سازی کرده و مجدد تأیید کنید.',1;

      UPDATE MeratFilesDB.dbo.TahghighatDocument
       SET IsDeleted=1,DeletedByUserId=@UserId,DeletedAtUtc=SYSUTCDATETIME(),
           DeleteReason=N'جایگزینی تصویر جمع‌بندی محقق با تأیید کاربر'
       WHERE TargetEntity='RESEARCH_ASSIGNMENT' AND TargetRecordId=@AssignmentId AND IsDeleted=0 AND AttachmentKind='SUMMARY' AND SummaryLevel='INVESTIGATOR';

      INSERT MeratFilesDB.dbo.TahghighatDocument
       (AttachmentId,CaseId,ShomarehParvandeh,PersonId,ReferralId,AssignmentId,
        AttachmentKind,SummaryLevel,TargetEntity,TargetRecordId,OriginalFileName,
        MimeType,FileSizeBytes,Sha256,FileData,CreatedByUserId,
        InvestigatorKey,InvestigatorPersonId,InvestigatorLegacyCode,AttachmentDescription)
      VALUES
       (@FileId,@CaseId,@Number,@PersonId,@ReferralId,@AssignmentId,
        'SUMMARY','INVESTIGATOR','RESEARCH_ASSIGNMENT',@AssignmentId,
        @OriginalFileName,@MimeType,DATALENGTH(@FileData),
        CONVERT(binary(32),HASHBYTES('SHA2_256',@FileData)),@FileData,@UserId,
        @InvestigatorKey,@InvestigatorPersonId,@InvestigatorLegacyCode,
        N'تصویر تولیدشده از فرم جمع‌بندی محقق');

      COMMIT TRANSACTION;
      SELECT CONVERT(bit,1) AS IsSuccess,@FileId AS AttachmentId,
             @ExistingCount AS ReplacedCount;
    END TRY
    BEGIN CATCH
      IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
      THROW;
    END CATCH;
END;
GO
