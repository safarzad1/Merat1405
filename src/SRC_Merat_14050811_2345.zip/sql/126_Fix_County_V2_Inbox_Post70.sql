﻿SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [TahghighatV2].[SP_GetCountyInbox]
 @UserId bigint,@Page int=1,@PageSize int=25
AS
BEGIN
 SET NOCOUNT ON;
 IF @UserId IS NULL OR @UserId<=0 OR @Page<1 OR @PageSize NOT BETWEEN 1 AND 100
 THROW 54072,N'ورودی کارتابل شهرستان معتبر نیست.',1;
 SELECT r.ReferralId CountyReferralId,r.ParentReferralId HozeReferralId,
  r.ToMahal CountyCityId,r.StateCode,r.Description,r.CreatedAtUtc,
  cf.CaseId,cf.CodeEntekhabat,cf.CodeHozeh,cf.ShomarehParvandeh,
  COUNT_BIG(*) OVER() TotalCount
 FROM TahghighatV2.Referral r
 JOIN dbo.Users u ON u.UserId=@UserId AND u.IsActive=1 AND u.PostId=70 AND u.Mahal=r.ToMahal
 JOIN TahghighatV2.Referral h ON h.ReferralId=r.ParentReferralId
  AND h.ReceiverLevel='HOZE' AND h.IsDeleted=0
 JOIN dbo.Citys county ON county.CityId=r.ToMahal AND county.CityIdHozeh=h.ToMahal
 JOIN TahghighatV2.CaseFile cf ON cf.CaseId=r.CaseId
 WHERE r.ReceiverLevel='SHAHR' AND r.IsDeleted=0 AND r.IsClosed=0
  AND r.StateCode IN('CHILD_INBOX','CHILD_WORKING')
 ORDER BY r.CreatedAtUtc DESC,r.ReferralId DESC
 OFFSET (CONVERT(bigint,@Page)-1)*@PageSize ROWS FETCH NEXT @PageSize ROWS ONLY;
END;
GO
