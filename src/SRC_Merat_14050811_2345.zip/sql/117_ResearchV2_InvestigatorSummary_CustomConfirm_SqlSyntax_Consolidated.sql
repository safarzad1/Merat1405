/* Merat V2 - consolidated through Phase 104. Run this file as the only required SQL after backing up the database. */
USE [MeratDB];
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
/* Phase 88: scoped HOZE workflow. Existing county and province assignments are not modified. */
IF OBJECT_ID(N'TahghighatV2.Referral',N'U') IS NULL
 OR OBJECT_ID(N'TahghighatV2.ResearchAssignment',N'U') IS NULL
 OR OBJECT_ID(N'TahghighatV2.InvestigatorRegistry',N'U') IS NULL
 OR OBJECT_ID(N'TahghighatV2.CountyInvestigator',N'U') IS NULL
 THROW 54880,N'جداول پایه V2 یافت نشدند؛ ابتدا دیتابیس را کنترل کنید.',1;
GO
/* Register new audit actions before inserting events (FK_MRV2_Event_Action). */
INSERT TahghighatV2.WorkflowAction(ActionCode,TitleFa)
SELECT v.ActionCode,v.TitleFa
FROM (VALUES
 ('HOZE_REFER_COUNTY',N'ارجاع به شهرستان فرعی'),
 ('HOZE_ASSIGN_INVESTIGATOR',N'انتساب محقق توسط حوزه انتخابیه'),
 ('HOZE_CANCEL_ASSIGNMENT',N'بازپسگیری محقق حوزه'),
 ('HOZE_INVESTIGATOR_START',N'شروع تحقیق محقق حوزه'),
 ('HOZE_INVESTIGATOR_DONE',N'تکمیل تحقیق محقق حوزه'),
 ('HOZE_SAVE_WORKSHEET',N'ثبت کاربرگ محقق حوزه')
) v(ActionCode,TitleFa)
WHERE NOT EXISTS(SELECT 1 FROM TahghighatV2.WorkflowAction a WHERE a.ActionCode=v.ActionCode);
GO
/* Permit the default HOZE officer to refer counties only if no explicit policy exists.
   Explicitly denied permissions (IsAllowed=0) are not overwritten. */
IF EXISTS(SELECT 1 FROM TahghighatV2.WorkflowAction WHERE ActionCode='HOZE_REFER_COUNTY')
 AND NOT EXISTS(SELECT 1 FROM TahghighatV2.PostActionPermission WHERE PostId=61 AND ActionCode='HOZE_REFER_COUNTY')
 INSERT TahghighatV2.PostActionPermission(PostId,ActionCode,IsAllowed) VALUES(61,'HOZE_REFER_COUNTY',1);
GO
/* Phase 103: the constituency chair (Post 60) can also initiate COUNTY and
   INVESTIGATOR referrals. The officer (Post 61) retains existing permissions.
   Explicit administrative denials remain authoritative; never overwrite them. */
IF NOT EXISTS (SELECT 1 FROM TahghighatV2.PostActionPermission
               WHERE PostId=60 AND ActionCode='HOZE_REFER_COUNTY')
 INSERT TahghighatV2.PostActionPermission(PostId,ActionCode,IsAllowed)
 VALUES(60,'HOZE_REFER_COUNTY',1);
GO
INSERT TahghighatV2.PostActionPermission(PostId,ActionCode,IsAllowed)
SELECT p.PostId,'HOZE_ASSIGN_INVESTIGATOR',1
FROM (VALUES(60),(61)) p(PostId)
WHERE NOT EXISTS (SELECT 1 FROM TahghighatV2.PostActionPermission ap
 WHERE ap.PostId=p.PostId AND ap.ActionCode='HOZE_ASSIGN_INVESTIGATOR');
GO
/* Phase 92: grant the county-referral deletion action separately from creation. */
IF NOT EXISTS (SELECT 1 FROM TahghighatV2.WorkflowAction WHERE ActionCode='HOZE_DELETE_COUNTY_REFERRAL')
 INSERT TahghighatV2.WorkflowAction(ActionCode,TitleFa)
 VALUES ('HOZE_DELETE_COUNTY_REFERRAL',N'حذف ارجاع شهرستان فرعی قبل از اقدام مقصد');
GO
IF NOT EXISTS (SELECT 1 FROM TahghighatV2.PostActionPermission WHERE PostId=61 AND ActionCode='HOZE_DELETE_COUNTY_REFERRAL')
 INSERT TahghighatV2.PostActionPermission(PostId,ActionCode,IsAllowed)
 VALUES (61,'HOZE_DELETE_COUNTY_REFERRAL',1);
GO
/* Display-only operations must not depend on the permission for *creating* county referrals. */
CREATE OR ALTER PROCEDURE TahghighatV2.SP_GetHozeCountyChoices
 @HozeReferralId bigint,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @Hoze int,@Post int;
 SELECT @Hoze=u.Mahal,@Post=u.PostId FROM dbo.Users u WHERE u.UserId=@UserId AND u.IsActive=1;
 IF ISNULL(@Post,0) NOT IN(60,61) OR NOT EXISTS(
  SELECT 1 FROM TahghighatV2.Referral h JOIN dbo.Citys center ON center.CityId=h.ToMahal
  WHERE h.ReferralId=@HozeReferralId AND h.ReceiverLevel='HOZE' AND h.ToMahal=@Hoze
    AND h.IsDeleted=0 AND center.IsHoze=1 AND center.IsActive=1)
  THROW 54881,N'ارجاع حوزه در محدوده دسترسی شما نیست.',1;
 SELECT c.CityId CountyCityId,c.Name CountyName,c.CityIdHozeh HozeCityId,
  (SELECT COUNT_BIG(*) FROM TahghighatV2.CountyRepresentative cr
    JOIN dbo.Users u ON u.UserId=cr.AuthUserId AND u.IsActive=1 AND u.Mahal=c.CityId
    WHERE cr.CountyCityId=c.CityId AND cr.HozeCityId=@Hoze AND cr.IsActive=1) ActiveRepresentatives
 FROM dbo.Citys c JOIN dbo.Citys center ON center.CityId=@Hoze
 WHERE c.IsHoze=0 AND c.IsActive=1 AND c.CityIdHozeh=@Hoze AND c.PCityId=center.PCityId
  AND NOT EXISTS (
    SELECT 1 FROM TahghighatV2.Referral prev
    WHERE prev.ParentReferralId=@HozeReferralId AND prev.ToMahal=c.CityId
      AND prev.ReceiverLevel='SHAHR' AND prev.IsDeleted=0
  )
 ORDER BY c.Name,c.CityId;
END;
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_GetHozeCountyReferrals
 @HozeReferralId bigint,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @Hoze int,@Post int;
 SELECT @Hoze=u.Mahal,@Post=u.PostId FROM dbo.Users u WHERE u.UserId=@UserId AND u.IsActive=1;
 IF ISNULL(@Post,0) NOT IN(60,61) OR NOT EXISTS(
  SELECT 1 FROM TahghighatV2.Referral h WHERE h.ReferralId=@HozeReferralId
  AND h.ToMahal=@Hoze AND h.ReceiverLevel='HOZE' AND h.IsDeleted=0)
  THROW 54882,N'فهرست ارجاعات شهرستان در محدوده دسترسی شما نیست.',1;
 SELECT r.ReferralId CountyReferralId,r.ToMahal CountyCityId,city.Name CountyName,
  r.StateCode,r.IsClosed,r.Description,r.CreatedAtUtc,r.UpdatedAtUtc,
  s.SummaryText CountySummaryText,
  (SELECT COUNT_BIG(*) FROM TahghighatV2.ResearchAssignment a
    WHERE a.ReferralId=r.ReferralId AND a.StatusCode IN('PENDING','IN_PROGRESS')) OpenAssignments,
  CONVERT(bit,CASE WHEN @Post=61
    AND EXISTS (SELECT 1 FROM TahghighatV2.PostActionPermission ap
      WHERE ap.PostId=@Post AND ap.ActionCode='HOZE_DELETE_COUNTY_REFERRAL' AND ap.IsAllowed=1)
    AND h.StateCode='CHILD_WORKING' AND h.IsClosed=0 AND h.IsDeleted=0
    AND root.StateCode='PENDING_CHILD_RESULTS' AND root.IsClosed=0 AND root.IsDeleted=0
    AND r.ReceiverLevel='SHAHR' AND r.StateCode='CHILD_INBOX' AND r.IsClosed=0
    AND EXISTS (SELECT 1 FROM TahghighatV2.WorkflowEvent e
      WHERE e.ReferralId=r.ReferralId AND e.ActionCode='CHILD_CREATED')
    AND NOT EXISTS (SELECT 1 FROM TahghighatV2.WorkflowEvent e
      WHERE e.ReferralId=r.ReferralId AND e.ActionCode<>'CHILD_CREATED')
    AND NOT EXISTS (SELECT 1 FROM TahghighatV2.Referral descendants WHERE descendants.ParentReferralId=r.ReferralId)
    AND NOT EXISTS (SELECT 1 FROM TahghighatV2.ResearchAssignment a WHERE a.ReferralId=r.ReferralId)
    AND NOT EXISTS (SELECT 1 FROM TahghighatV2.CountySummary cs WHERE cs.ReferralId=r.ReferralId)
    AND NOT EXISTS (SELECT 1 FROM TahghighatV2.NoResearchDecision nr WHERE nr.ReferralId=r.ReferralId)
    THEN 1 ELSE 0 END) CanDelete
 FROM TahghighatV2.Referral r LEFT JOIN dbo.Citys city ON city.CityId=r.ToMahal
 LEFT JOIN TahghighatV2.CountySummary s ON s.ReferralId=r.ReferralId
 LEFT JOIN TahghighatV2.Referral h ON h.ReferralId=r.ParentReferralId
 LEFT JOIN TahghighatV2.Referral root ON root.ReferralId=h.ParentReferralId
 WHERE r.ParentReferralId=@HozeReferralId AND r.ReceiverLevel='SHAHR' AND r.IsDeleted=0
 ORDER BY r.ReferralId DESC;
END;
GO
/* The constituency chair (Post 60) can view completed work and create scoped
   county/investigator referrals; only Post 61 edits consolidation/worksheets. */
CREATE OR ALTER PROCEDURE TahghighatV2.SP_GetHozeConsolidation
 @HozeReferralId bigint,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @Mahal int,@Post int;
 SELECT @Mahal=u.Mahal,@Post=u.PostId FROM dbo.Users u WHERE u.UserId=@UserId AND u.IsActive=1;
 IF ISNULL(@Post,0) NOT IN(60,61) OR NOT EXISTS(
   SELECT 1 FROM TahghighatV2.Referral h
   WHERE h.ReferralId=@HozeReferralId AND h.ToMahal=@Mahal AND h.ReceiverLevel='HOZE' AND h.IsDeleted=0)
  THROW 54910,N'دسترسی به جمع‌بندی حوزه مجاز نیست.',1;
 SELECT h.ReferralId HozeReferralId,h.StateCode HozeState,hs.SummaryId HozeSummaryId,
  hs.SummaryText HozeSummaryText,c.ReferralId CountyReferralId,c.ToMahal CountyCityId,
  city.Name CountyName,c.StateCode CountyState,c.IsClosed CountyIsClosed,
  cs.SummaryId CountySummaryId,cs.SummaryText CountySummaryText,
  (SELECT COUNT_BIG(*) FROM TahghighatV2.ResearchAssignment a WHERE a.ReferralId=c.ReferralId) InvestigatorCount,
  (SELECT COUNT_BIG(*) FROM TahghighatV2.ResearchAssignment a
   WHERE a.ReferralId=c.ReferralId AND a.StatusCode IN('PENDING','IN_PROGRESS')) OpenAssignments
 FROM TahghighatV2.Referral h LEFT JOIN TahghighatV2.HozeSummary hs ON hs.ReferralId=h.ReferralId
 LEFT JOIN TahghighatV2.Referral c ON c.ParentReferralId=h.ReferralId
  AND c.ReceiverLevel='SHAHR' AND c.IsDeleted=0
 LEFT JOIN dbo.Citys city ON city.CityId=c.ToMahal
 LEFT JOIN TahghighatV2.CountySummary cs ON cs.ReferralId=c.ReferralId
 WHERE h.ReferralId=@HozeReferralId AND h.ToMahal=@Mahal AND h.ReceiverLevel='HOZE' AND h.IsDeleted=0
 ORDER BY c.ReferralId;
END;
GO
/* Single source of truth for header buttons and case identity. */
CREATE OR ALTER PROCEDURE TahghighatV2.SP_GetHozeCaseDetail
 @HozeReferralId bigint,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @Mahal int,@Post int;
 SELECT @Mahal=Mahal,@Post=PostId FROM dbo.Users WHERE UserId=@UserId AND IsActive=1;
 IF ISNULL(@Post,0) NOT IN(60,61) THROW 54883,N'سمت کاربر مجاز حوزه نیست.',1;
 SELECT h.ReferralId,h.ParentReferralId,h.StateCode,h.Description,h.CreatedAtUtc,h.IsClosed,
  cf.ShomarehParvandeh,cf.CodeHozeh,cf.CodeEntekhabat,city.Name HozeName,
  applicant.FirstName,applicant.LastName,applicant.NamePedar,
  NULLIF(LEFT(LTRIM(RTRIM(applicant.TarikhTavalod)),4),N'') SalTavalod,
  CONVERT(bit,CASE WHEN @Post=61 AND h.StateCode='CHILD_INBOX' AND h.IsClosed=0
   AND parent.StateCode='PENDING_CHILD_RESULTS' AND parent.IsClosed=0 THEN 1 ELSE 0 END) CanStart,
  CONVERT(bit,CASE WHEN @Post IN(60,61) AND h.StateCode='CHILD_WORKING' AND h.IsClosed=0
   AND h.IsDeleted=0 AND parent.StateCode='PENDING_CHILD_RESULTS' AND parent.IsClosed=0
   AND parent.IsDeleted=0
   AND EXISTS(SELECT 1 FROM TahghighatV2.PostActionPermission perm WHERE perm.PostId=@Post
    AND perm.ActionCode='HOZE_REFER_COUNTY' AND perm.IsAllowed=1)
   THEN 1 ELSE 0 END) CanReferCounty,
  CONVERT(bit,CASE WHEN @Post IN(60,61) AND h.StateCode='CHILD_WORKING' AND h.IsClosed=0
   AND h.IsDeleted=0 AND parent.StateCode='PENDING_CHILD_RESULTS' AND parent.IsClosed=0
   AND parent.IsDeleted=0
   AND EXISTS(SELECT 1 FROM TahghighatV2.PostActionPermission perm WHERE perm.PostId=@Post
    AND perm.ActionCode='HOZE_ASSIGN_INVESTIGATOR' AND perm.IsAllowed=1)
   THEN 1 ELSE 0 END) CanAssignInvestigator,
  /* Separate action grants: chair may document work but cannot submit the case. */
  CONVERT(bit,CASE WHEN @Post IN(60,61) AND h.StateCode='CHILD_WORKING'
   AND h.IsClosed=0 AND h.IsDeleted=0
   AND parent.StateCode='PENDING_CHILD_RESULTS' AND parent.IsClosed=0 AND parent.IsDeleted=0
   AND EXISTS(SELECT 1 FROM TahghighatV2.PostActionPermission pp WHERE pp.PostId=@Post
    AND pp.ActionCode='HOZE_OFFICER_SAVE_WORKSHEET' AND pp.IsAllowed=1)
   THEN 1 ELSE 0 END) CanSaveWorksheet,
  CONVERT(bit,CASE WHEN @Post IN(60,61) AND h.StateCode='CHILD_WORKING'
   AND h.IsClosed=0 AND h.IsDeleted=0
   AND parent.StateCode='PENDING_CHILD_RESULTS' AND parent.IsClosed=0 AND parent.IsDeleted=0
   AND EXISTS(SELECT 1 FROM TahghighatV2.PostActionPermission pp WHERE pp.PostId=@Post
    AND pp.ActionCode='HOZE_OFFICER_COMPLETE_ASSIGNMENT' AND pp.IsAllowed=1)
   THEN 1 ELSE 0 END) CanCompleteInvestigator,
  CONVERT(bit,CASE WHEN @Post IN(60,61) AND h.StateCode='CHILD_WORKING'
   AND h.IsClosed=0 AND h.IsDeleted=0
   AND parent.StateCode='PENDING_CHILD_RESULTS' AND parent.IsClosed=0 AND parent.IsDeleted=0
   AND EXISTS(SELECT 1 FROM TahghighatV2.PostActionPermission pp WHERE pp.PostId=@Post
    AND pp.ActionCode='HOZE_SAVE_SUMMARY' AND pp.IsAllowed=1)
   THEN 1 ELSE 0 END) CanSaveSummary,
  CONVERT(bit,CASE WHEN @Post=61 AND h.StateCode='CHILD_WORKING' AND h.IsClosed=0
   AND parent.StateCode='PENDING_CHILD_RESULTS' AND parent.IsClosed=0 THEN 1 ELSE 0 END) CanWork,
  (SELECT COUNT_BIG(*) FROM TahghighatV2.Referral c
   WHERE c.ParentReferralId=h.ReferralId AND c.IsDeleted=0 AND c.IsClosed=0) OpenCounties,
  (SELECT COUNT_BIG(*) FROM TahghighatV2.ResearchAssignment a
   WHERE a.ReferralId=h.ReferralId AND a.StatusCode IN('PENDING','IN_PROGRESS')) OpenInvestigators,
  hs.SummaryText HozeSummaryText
 FROM TahghighatV2.Referral h JOIN TahghighatV2.Referral parent ON parent.ReferralId=h.ParentReferralId
 JOIN TahghighatV2.CaseFile cf ON cf.CaseId=h.CaseId
 JOIN dbo.Citys city ON city.CityId=h.ToMahal AND city.IsHoze=1 AND city.IsActive=1
 OUTER APPLY(SELECT TOP(1) a.FirstName,a.LastName,a.NamePedar,a.TarikhTavalod
   FROM Davtalab.Ashkhas a WHERE a.ShomarehParvandeh=cf.ShomarehParvandeh
    AND ISNULL(a.IsDelete,0)=0) applicant
 LEFT JOIN TahghighatV2.HozeSummary hs ON hs.ReferralId=h.ReferralId
 WHERE h.ReferralId=@HozeReferralId AND h.ToMahal=@Mahal AND h.ReceiverLevel='HOZE' AND h.IsDeleted=0;
END;
GO
/* Investigator candidates are approved county investigators inside the current HOZE. */
CREATE OR ALTER PROCEDURE TahghighatV2.SP_GetHozeInvestigatorCandidates
 @HozeReferralId bigint,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @Mahal int,@Post int;
 SELECT @Mahal=u.Mahal,@Post=u.PostId FROM dbo.Users u WHERE u.UserId=@UserId AND u.IsActive=1;
 IF ISNULL(@Post,0)<>61 OR NOT EXISTS(SELECT 1 FROM TahghighatV2.Referral r
   WHERE r.ReferralId=@HozeReferralId AND r.ToMahal=@Mahal AND r.ReceiverLevel='HOZE'
   AND r.StateCode='CHILD_WORKING' AND r.IsClosed=0 AND r.IsDeleted=0)
  THROW 54884,N'این پرونده در مرحله انتساب محقق حوزه نیست.',1;
 SELECT DISTINCT ci.InvestigatorKey,ir.AuthUserId,ci.CountyCityId,city.Name CountyName,
  LTRIM(RTRIM(CONCAT(ISNULL(p.FirstName,N''),N' ',ISNULL(p.LastName,N'')))) FullName
 FROM TahghighatV2.CountyInvestigator ci
 JOIN dbo.Citys city ON city.CityId=ci.CountyCityId AND city.IsActive=1
  AND (city.CityIdHozeh=@Mahal OR city.CityId=@Mahal)
 JOIN TahghighatV2.InvestigatorRegistry ir ON ir.InvestigatorKey=ci.InvestigatorKey
  AND ir.IsActive=1 AND ir.AuthUserId IS NOT NULL
 JOIN dbo.Users u ON u.UserId=ir.AuthUserId AND u.IsActive=1 AND u.Mahal=ci.CountyCityId
 LEFT JOIN dbo.Person p ON p.PersonId=ir.PersonId
 WHERE ci.IsActive=1 AND ir.ProvinceCityId=city.PCityId
 ORDER BY FullName,ci.InvestigatorKey;
END;
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_GetHozeAssignments
 @HozeReferralId bigint,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @Mahal int,@Post int;
 SELECT @Mahal=u.Mahal,@Post=u.PostId FROM dbo.Users u WHERE u.UserId=@UserId AND u.IsActive=1;
 IF ISNULL(@Post,0) NOT IN(60,61) OR NOT EXISTS(SELECT 1 FROM TahghighatV2.Referral r
  WHERE r.ReferralId=@HozeReferralId AND r.ToMahal=@Mahal AND r.ReceiverLevel='HOZE' AND r.IsDeleted=0)
  THROW 54885,N'مجوز مشاهده محققان حوزه وجود ندارد.',1;
 SELECT a.AssignmentId,a.InvestigatorId InvestigatorKey,ir.PersonId,a.StatusCode,a.Instruction,a.Summary,
  a.DueDatePersian,a.CreatedAtUtc,a.FinishedAtUtc,
  LTRIM(RTRIM(CONCAT(ISNULL(p.FirstName,N''),N' ',ISNULL(p.LastName,N'')))) FullName,
  (SELECT COUNT_BIG(*) FROM TahghighatV2.ResearchWorksheet w WHERE w.AssignmentId=a.AssignmentId) WorksheetCount
 FROM TahghighatV2.ResearchAssignment a
 JOIN TahghighatV2.InvestigatorRegistry ir ON ir.InvestigatorKey=a.InvestigatorId
 LEFT JOIN dbo.Person p ON p.PersonId=ir.PersonId
 WHERE a.ReferralId=@HozeReferralId ORDER BY a.AssignmentId DESC;
END;
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_HozeAssignInvestigator
 @HozeReferralId bigint,@InvestigatorKey bigint,@Instruction nvarchar(max),
 @DueDatePersian char(10)=NULL,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 IF @HozeReferralId<=0 OR @InvestigatorKey<=0 OR @UserId<=0
  OR NULLIF(LTRIM(RTRIM(@Instruction)),N'') IS NULL OR LEN(@Instruction)>6000
  THROW 54886,N'اطلاعات انتساب کامل نیست.',1;
 DECLARE @Mahal int,@Post int,@Root bigint,@State varchar(40),@Lock int,@NewId bigint;
 SELECT @Mahal=Mahal,@Post=PostId FROM dbo.Users WHERE UserId=@UserId AND IsActive=1;
 IF ISNULL(@Post,0)<>61 OR NOT EXISTS(SELECT 1 FROM dbo.Citys c WHERE c.CityId=@Mahal AND c.IsHoze=1 AND c.IsActive=1)
  THROW 54887,N'کاربر مجاز حوزه انتخابیه نیست.',1;
 IF NOT EXISTS(SELECT 1 FROM TahghighatV2.CountyInvestigator ci
  JOIN dbo.Citys c ON c.CityId=ci.CountyCityId AND c.IsActive=1
   AND c.CityIdHozeh=@Mahal
  JOIN TahghighatV2.InvestigatorRegistry ir ON ir.InvestigatorKey=ci.InvestigatorKey
   AND ir.IsActive=1 AND ir.AuthUserId IS NOT NULL AND ir.ProvinceCityId=c.PCityId
  JOIN dbo.Users u ON u.UserId=ir.AuthUserId AND u.IsActive=1 AND u.Mahal=ci.CountyCityId
  WHERE ci.InvestigatorKey=@InvestigatorKey AND ci.IsActive=1)
  THROW 54888,N'محقق فعال و تأییدشده در حوزه انتخابیه یافت نشد.',1;
 SELECT @Root=r.ParentReferralId FROM TahghighatV2.Referral r WHERE r.ReferralId=@HozeReferralId
  AND r.ToMahal=@Mahal AND r.ReceiverLevel='HOZE' AND r.IsDeleted=0;
 IF @Root IS NULL THROW 54889,N'ارجاع حوزه معتبر نیست.',1;
 BEGIN TRY
 BEGIN TRANSACTION;
 DECLARE @LockName nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(20),@Root);
 EXEC @Lock=sys.sp_getapplock @Resource=@LockName,
  @LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @Lock<0 THROW 54890,N'پرونده در حال پردازش است.',1;
 SELECT @State=r.StateCode FROM TahghighatV2.Referral r WITH(UPDLOCK,HOLDLOCK)
 JOIN TahghighatV2.Referral p ON p.ReferralId=r.ParentReferralId
 WHERE r.ReferralId=@HozeReferralId AND r.ToMahal=@Mahal AND r.IsClosed=0 AND r.IsDeleted=0
 AND p.ReferralId=@Root AND p.StateCode='PENDING_CHILD_RESULTS' AND p.IsClosed=0 AND p.IsDeleted=0;
 IF @State<>'CHILD_WORKING' OR @State IS NULL THROW 54891,N'ارجاع حوزه در مرحله بررسی فعال نیست.',1;
 IF EXISTS(SELECT 1 FROM TahghighatV2.ResearchAssignment a WITH(UPDLOCK,HOLDLOCK)
  WHERE a.ReferralId=@HozeReferralId AND a.InvestigatorId=@InvestigatorKey AND a.StatusCode IN('PENDING','IN_PROGRESS'))
  THROW 54892,N'برای همین محقق انتساب باز وجود دارد.',1;
 INSERT TahghighatV2.ResearchAssignment(ReferralId,InvestigatorId,DueDatePersian,Instruction,StatusCode,CreatedByUserId)
 VALUES(@HozeReferralId,@InvestigatorKey,@DueDatePersian,@Instruction,'PENDING',@UserId);
 SET @NewId=CONVERT(bigint,SCOPE_IDENTITY());
 INSERT TahghighatV2.ResearchAssignmentEvent(AssignmentId,ActionCode,BeforeStatus,AfterStatus,Description,ActorUserId)
 VALUES(@NewId,'HOZE_ASSIGN_INVESTIGATOR',NULL,'PENDING',@Instruction,@UserId);
 INSERT TahghighatV2.WorkflowEvent(ReferralId,ActionCode,PreviousStateCode,NewStateCode,Description,ActorUserId)
 VALUES(@HozeReferralId,'HOZE_ASSIGN_INVESTIGATOR',@State,@State,@Instruction,@UserId);
 COMMIT;
 SELECT CONVERT(bit,1) IsSuccess,@NewId AssignmentId;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK;THROW;END CATCH;
END;
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_HozeCancelAssignment
 @AssignmentId bigint,@Reason nvarchar(max),@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 IF @AssignmentId<=0 OR @UserId<=0 OR NULLIF(LTRIM(RTRIM(@Reason)),N'') IS NULL
 THROW 54893,N'انتساب و علت بازپسگیری الزامی است.',1;
 DECLARE @Root bigint,@Hoze bigint,@State varchar(40),@Status varchar(20),@Lock int;
 SELECT @Hoze=r.ReferralId,@Root=r.ParentReferralId FROM TahghighatV2.ResearchAssignment a
 JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId
 JOIN dbo.Users u ON u.UserId=@UserId AND u.IsActive=1 AND u.PostId IN(60,61) AND u.Mahal=r.ToMahal
 WHERE a.AssignmentId=@AssignmentId AND r.ReceiverLevel='HOZE' AND r.IsDeleted=0;
 IF @Root IS NULL THROW 54894,N'این محقق در حوزه دسترسی شما نیست.',1;
 BEGIN TRY BEGIN TRANSACTION;
 DECLARE @LockName nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(20),@Root);
 EXEC @Lock=sys.sp_getapplock @Resource=@LockName,
 @LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @Lock<0 THROW 54895,N'پرونده در حال پردازش است.',1;
 SELECT @State=r.StateCode,@Status=a.StatusCode FROM TahghighatV2.ResearchAssignment a WITH(UPDLOCK,HOLDLOCK)
 JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId
 JOIN TahghighatV2.Referral p ON p.ReferralId=r.ParentReferralId
 WHERE a.AssignmentId=@AssignmentId AND r.ReferralId=@Hoze AND r.IsClosed=0 AND r.IsDeleted=0
 AND p.StateCode='PENDING_CHILD_RESULTS' AND p.IsClosed=0 AND p.IsDeleted=0;
 IF @State<>'CHILD_WORKING' OR @Status NOT IN('PENDING','IN_PROGRESS')
 THROW 54896,N'بازپسگیری فقط برای انتساب فعال مجاز است.',1;
 UPDATE TahghighatV2.ResearchAssignment SET StatusCode='CANCELLED',FinishedAtUtc=SYSUTCDATETIME() WHERE AssignmentId=@AssignmentId;
 INSERT TahghighatV2.ResearchAssignmentEvent(AssignmentId,ActionCode,BeforeStatus,AfterStatus,Description,ActorUserId)
 VALUES(@AssignmentId,'HOZE_CANCEL_ASSIGNMENT',@Status,'CANCELLED',@Reason,@UserId);
 INSERT TahghighatV2.WorkflowEvent(ReferralId,ActionCode,PreviousStateCode,NewStateCode,Description,ActorUserId)
 VALUES(@Hoze,'HOZE_CANCEL_ASSIGNMENT','CHILD_WORKING','CHILD_WORKING',@Reason,@UserId);
 COMMIT; SELECT CONVERT(bit,1) IsSuccess;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK;THROW;END CATCH;
END;
GO
/* Authenticated investigator-only text worksheet lifecycle; does not reuse old V1 tables. */
CREATE OR ALTER PROCEDURE TahghighatV2.SP_GetHozeInvestigatorInbox
 @UserId bigint,@Page int=1,@PageSize int=25
AS
BEGIN
 SET NOCOUNT ON;
 IF @Page<1 OR @PageSize NOT BETWEEN 1 AND 100 THROW 54897,N'صفحه‌بندی نامعتبر است.',1;
 SELECT a.AssignmentId,a.ReferralId,a.StatusCode,a.Instruction,a.DueDatePersian,a.CreatedAtUtc,
  cf.ShomarehParvandeh,cf.CodeHozeh,r.ToMahal HozeCityId
 FROM TahghighatV2.ResearchAssignment a
 JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId AND r.ReceiverLevel='HOZE'
 JOIN TahghighatV2.CaseFile cf ON cf.CaseId=r.CaseId
 JOIN TahghighatV2.InvestigatorRegistry ir ON ir.InvestigatorKey=a.InvestigatorId AND ir.IsActive=1 AND ir.AuthUserId=@UserId
 JOIN dbo.Users u ON u.UserId=@UserId AND u.IsActive=1
 WHERE r.IsClosed=0 AND r.IsDeleted=0 AND a.StatusCode IN('PENDING','IN_PROGRESS')
 AND EXISTS (SELECT 1 FROM TahghighatV2.CountyInvestigator ci
   JOIN dbo.Citys city ON city.CityId=ci.CountyCityId AND city.IsActive=1 AND city.CityIdHozeh=r.ToMahal
   WHERE ci.InvestigatorKey=ir.InvestigatorKey AND ci.IsActive=1 AND u.Mahal=ci.CountyCityId)
 ORDER BY a.CreatedAtUtc DESC OFFSET (CONVERT(bigint,@Page)-1)*@PageSize ROWS FETCH NEXT @PageSize ROWS ONLY;
END;
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_GetHozeWorksheets
 @AssignmentId bigint,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 IF NOT EXISTS(SELECT 1 FROM TahghighatV2.ResearchAssignment a
 JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId AND r.ReceiverLevel='HOZE' AND r.IsDeleted=0
 JOIN dbo.Users u ON u.UserId=@UserId AND u.IsActive=1
 WHERE a.AssignmentId=@AssignmentId AND
  ((u.PostId IN(60,61) AND u.Mahal=r.ToMahal) OR
   EXISTS(SELECT 1 FROM TahghighatV2.InvestigatorRegistry ir
    JOIN TahghighatV2.CountyInvestigator ci ON ci.InvestigatorKey=ir.InvestigatorKey AND ci.IsActive=1
    JOIN dbo.Citys city ON city.CityId=ci.CountyCityId AND city.CityIdHozeh=r.ToMahal AND city.IsActive=1
    WHERE ir.InvestigatorKey=a.InvestigatorId AND ir.IsActive=1 AND ir.AuthUserId=@UserId AND u.Mahal=ci.CountyCityId)))
 THROW 54898,N'دسترسی به کاربرگ محقق حوزه مجاز نیست.',1;
 SELECT WorksheetId,AssignmentId,ReportText,CreatedAtUtc,CreatedByUserId
 FROM TahghighatV2.ResearchWorksheet WHERE AssignmentId=@AssignmentId ORDER BY WorksheetId;
END;
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_HozeInvestigatorAction
 @AssignmentId bigint,@ActionCode varchar(40),@Summary nvarchar(max)=NULL,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 IF @AssignmentId<=0 OR @UserId<=0 OR @ActionCode NOT IN('HOZE_INVESTIGATOR_START','HOZE_INVESTIGATOR_DONE')
 THROW 54899,N'اقدام محقق حوزه نامعتبر است.',1;
 IF @ActionCode='HOZE_INVESTIGATOR_DONE' AND NULLIF(LTRIM(RTRIM(@Summary)),N'') IS NULL
 THROW 54900,N'جمع‌بندی محقق برای تکمیل اجباری است.',1;
 DECLARE @Hoze bigint,@Root bigint,@Status varchar(20),@Key bigint,@Lock int;
 SELECT @Hoze=r.ReferralId,@Root=r.ParentReferralId FROM TahghighatV2.ResearchAssignment a
 JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId AND r.ReceiverLevel='HOZE'
 WHERE a.AssignmentId=@AssignmentId;
 IF @Root IS NULL THROW 54901,N'انتساب حوزه نامعتبر است.',1;
 BEGIN TRY BEGIN TRANSACTION;
 DECLARE @LockName nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(20),@Root);
 EXEC @Lock=sys.sp_getapplock @Resource=@LockName,
 @LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @Lock<0 THROW 54902,N'پرونده در حال پردازش است.',1;
 SELECT @Status=a.StatusCode,@Key=a.InvestigatorId FROM TahghighatV2.ResearchAssignment a WITH(UPDLOCK,HOLDLOCK)
 JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId
 JOIN TahghighatV2.Referral p ON p.ReferralId=r.ParentReferralId
 WHERE a.AssignmentId=@AssignmentId AND r.ReferralId=@Hoze AND r.StateCode='CHILD_WORKING'
 AND r.IsClosed=0 AND r.IsDeleted=0 AND p.StateCode='PENDING_CHILD_RESULTS' AND p.IsClosed=0 AND p.IsDeleted=0;
 IF @Status IS NULL OR NOT EXISTS(SELECT 1 FROM TahghighatV2.InvestigatorRegistry ir
 JOIN TahghighatV2.CountyInvestigator ci ON ci.InvestigatorKey=ir.InvestigatorKey AND ci.IsActive=1
 JOIN dbo.Citys city ON city.CityId=ci.CountyCityId AND city.CityIdHozeh=(SELECT ToMahal FROM TahghighatV2.Referral WHERE ReferralId=@Hoze)
 JOIN dbo.Users u ON u.UserId=@UserId AND u.IsActive=1 AND u.Mahal=ci.CountyCityId
 WHERE ir.InvestigatorKey=@Key AND ir.IsActive=1 AND ir.AuthUserId=@UserId)
 THROW 54903,N'محقق مجاز این انتساب نیستید.',1;
 IF (@ActionCode='HOZE_INVESTIGATOR_START' AND @Status<>'PENDING') OR
 (@ActionCode='HOZE_INVESTIGATOR_DONE' AND @Status<>'IN_PROGRESS')
 THROW 54904,N'وضعیت انتساب برای اقدام مجاز نیست.',1;
 IF @ActionCode='HOZE_INVESTIGATOR_DONE' AND NOT EXISTS(SELECT 1 FROM TahghighatV2.ResearchWorksheet
 WHERE AssignmentId=@AssignmentId) THROW 54905,N'حداقل یک کاربرگ تحقیق الزامی است.',1;
 DECLARE @New varchar(20)=CASE WHEN @ActionCode='HOZE_INVESTIGATOR_START' THEN 'IN_PROGRESS' ELSE 'DONE' END;
 UPDATE TahghighatV2.ResearchAssignment SET StatusCode=@New,
 Summary=CASE WHEN @New='DONE' THEN @Summary ELSE Summary END,
 FinishedAtUtc=CASE WHEN @New='DONE' THEN SYSUTCDATETIME() ELSE FinishedAtUtc END WHERE AssignmentId=@AssignmentId;
 INSERT TahghighatV2.ResearchAssignmentEvent(AssignmentId,ActionCode,BeforeStatus,AfterStatus,Description,ActorUserId)
 VALUES(@AssignmentId,@ActionCode,@Status,@New,@Summary,@UserId);
 INSERT TahghighatV2.WorkflowEvent(ReferralId,ActionCode,PreviousStateCode,NewStateCode,Description,ActorUserId)
 VALUES(@Hoze,@ActionCode,'CHILD_WORKING','CHILD_WORKING',@Summary,@UserId);
 COMMIT; SELECT CONVERT(bit,1) IsSuccess;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK;THROW;END CATCH;
END;
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_HozeSaveWorksheet
 @AssignmentId bigint,@ReportText nvarchar(max),@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 IF @AssignmentId<=0 OR @UserId<=0 OR NULLIF(LTRIM(RTRIM(@ReportText)),N'') IS NULL OR LEN(@ReportText)>12000
 THROW 54906,N'گزارش کاربرگ نامعتبر است.',1;
 DECLARE @Hoze bigint,@Root bigint,@Status varchar(20),@Lock int,@Id bigint;
 SELECT @Hoze=r.ReferralId,@Root=r.ParentReferralId FROM TahghighatV2.ResearchAssignment a
 JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId AND r.ReceiverLevel='HOZE'
 WHERE a.AssignmentId=@AssignmentId;
 IF @Root IS NULL THROW 54907,N'ارجاع محقق یافت نشد.',1;
 BEGIN TRY BEGIN TRANSACTION;
 DECLARE @LockName nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(20),@Root);
 EXEC @Lock=sys.sp_getapplock @Resource=@LockName,
 @LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @Lock<0 THROW 54908,N'پرونده در حال پردازش است.',1;
 SELECT @Status=a.StatusCode FROM TahghighatV2.ResearchAssignment a WITH(UPDLOCK,HOLDLOCK)
 JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId
 JOIN TahghighatV2.Referral p ON p.ReferralId=r.ParentReferralId
 JOIN TahghighatV2.InvestigatorRegistry ir ON ir.InvestigatorKey=a.InvestigatorId AND ir.AuthUserId=@UserId AND ir.IsActive=1
 JOIN TahghighatV2.CountyInvestigator ci ON ci.InvestigatorKey=ir.InvestigatorKey AND ci.IsActive=1
 JOIN dbo.Citys city ON city.CityId=ci.CountyCityId AND city.CityIdHozeh=r.ToMahal AND city.IsActive=1
 JOIN dbo.Users u ON u.UserId=@UserId AND u.IsActive=1 AND u.Mahal=ci.CountyCityId
 WHERE a.AssignmentId=@AssignmentId AND r.ReferralId=@Hoze AND r.StateCode='CHILD_WORKING'
 AND r.IsClosed=0 AND r.IsDeleted=0 AND p.StateCode='PENDING_CHILD_RESULTS' AND p.IsClosed=0 AND p.IsDeleted=0;
 IF @Status<>'IN_PROGRESS' OR @Status IS NULL THROW 54909,N'کاربرگ فقط برای محقق فعال قابل ثبت است.',1;
 INSERT TahghighatV2.ResearchWorksheet(AssignmentId,ReportText,CreatedByUserId)
 VALUES(@AssignmentId,@ReportText,@UserId);
 SET @Id=CONVERT(bigint,SCOPE_IDENTITY());
 INSERT TahghighatV2.ResearchAssignmentEvent(AssignmentId,ActionCode,BeforeStatus,AfterStatus,Description,ActorUserId)
 VALUES(@AssignmentId,'HOZE_SAVE_WORKSHEET',@Status,@Status,N'ثبت کاربرگ '+CONVERT(nvarchar(20),@Id),@UserId);
 COMMIT; SELECT CONVERT(bit,1) IsSuccess,@Id WorksheetId;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK;THROW;END CATCH;
END;
GO


/* Phase 89: align read-only HOZE inbox visibility with the province workflow UI.
   Roles 60 and 61 may READ only their own active HOZE referrals.
   Roles 51 and 52 retain their original permission requirement and province scope.
   No action/approval privilege is granted by this procedure. */
CREATE OR ALTER PROCEDURE TahghighatV2.SP_GetChildInbox
 @UserId bigint, @Page int=1, @PageSize int=25
AS
BEGIN
 SET NOCOUNT ON;
 IF @UserId IS NULL OR @UserId<=0 OR @Page IS NULL OR @Page<1 OR @PageSize NOT BETWEEN 1 AND 100
  THROW 53441,N'ورودی کارتابل ارجاعات فرعی نامعتبر است.',1;
 DECLARE @Mahal int,@PostId int;
 SELECT @Mahal=u.Mahal,@PostId=u.PostId FROM dbo.Users u WHERE u.UserId=@UserId AND u.IsActive=1;
 IF @Mahal IS NULL OR ISNULL(@PostId,0) NOT IN(51,52,60,61)
  THROW 53442,N'دسترسی به کارتابل ارجاعات فرعی مجاز نیست.',1;
 IF @PostId IN(51,52) AND NOT EXISTS(
  SELECT 1 FROM TahghighatV2.PostActionPermission p
  WHERE p.PostId=@PostId AND p.ActionCode='CHILD_REPLY' AND p.IsAllowed=1)
  THROW 53442,N'دسترسی به کارتابل ارجاعات فرعی مجاز نیست.',1;
 IF @PostId IN(60,61) AND NOT EXISTS(
  SELECT 1 FROM dbo.Citys center WHERE center.CityId=@Mahal AND center.IsActive=1 AND center.IsHoze=1)
  THROW 53442,N'محل خدمت با مرکز حوزه انتخابیه مطابقت ندارد.',1;
 SELECT r.ReferralId,r.ParentReferralId,r.FromMahal,r.ToMahal,r.ReceiverLevel,
  r.StateCode,r.Description,c.CaseId,c.CodeEntekhabat,c.CodeHozeh,
  c.ShomarehParvandeh,r.CreatedAtUtc,COUNT_BIG(*) OVER() TotalCount
 FROM TahghighatV2.Referral r JOIN TahghighatV2.CaseFile c ON c.CaseId=r.CaseId
 WHERE r.ParentReferralId IS NOT NULL AND r.ToMahal=@Mahal
   AND r.IsDeleted=0 AND r.IsClosed=0
   AND r.StateCode IN('CHILD_INBOX','CHILD_WORKING')
   AND ((r.ReceiverLevel='OSTAN' AND @PostId IN(51,52) AND EXISTS(
          SELECT 1 FROM dbo.Citys city WHERE city.CityId=@Mahal AND city.IsActive=1 AND city.PCityId=1))
     OR (r.ReceiverLevel='HOZE' AND @PostId IN(60,61)))
 ORDER BY r.CreatedAtUtc DESC,r.ReferralId DESC
 OFFSET (CONVERT(bigint,@Page)-1)*@PageSize ROWS FETCH NEXT @PageSize ROWS ONLY;
END;
GO

/* Phase 90: subordinate counties are valid referral destinations regardless of
   whether an active representative exists today. This does not grant anyone
   county read/action permission. A referral stays in CHILD_INBOX until an
   authorized representative is activated for the destination county.
   Keep all scope, role, state, duplicate-open and audit checks unchanged. */
CREATE OR ALTER PROCEDURE TahghighatV2.SP_HozeReferCounty
 @HozeReferralId bigint,@CountyCityId int,@Description nvarchar(max),@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 SET XACT_ABORT ON;
 IF @HozeReferralId IS NULL OR @HozeReferralId<=0 OR @CountyCityId IS NULL
  OR @CountyCityId<=0 OR @UserId IS NULL OR @UserId<=0
  OR NULLIF(LTRIM(RTRIM(@Description)),N'') IS NULL
  THROW 54010,N'حوزه، شهرستان، شرح ارجاع و کاربر الزامی‌اند.',1;
 DECLARE @Hoze int,@Post int,@RootId bigint,@CaseId bigint,@State varchar(40),@Lock int,@NewId bigint;
 SELECT @Hoze=u.Mahal,@Post=u.PostId FROM dbo.Users u WHERE u.UserId=@UserId AND u.IsActive=1;
 IF ISNULL(@Post,0) NOT IN(60,61) OR NOT EXISTS(
   SELECT 1 FROM dbo.Citys c WHERE c.CityId=@Hoze AND c.IsHoze=1 AND c.IsActive=1)
  OR NOT EXISTS(
   SELECT 1 FROM TahghighatV2.PostActionPermission p
   WHERE p.PostId=@Post AND p.ActionCode='HOZE_REFER_COUNTY' AND p.IsAllowed=1)
  THROW 54011,N'کاربر مجاز حوزه اصلی نیست.',1;
 IF NOT EXISTS(
   SELECT 1 FROM dbo.Citys c JOIN dbo.Citys h ON h.CityId=@Hoze
   WHERE c.CityId=@CountyCityId AND c.IsActive=1 AND c.IsHoze=0
     AND c.CityIdHozeh=@Hoze AND c.PCityId=h.PCityId)
  THROW 54012,N'شهرستان انتخابی تابع حوزه اصلی نیست.',1;
 -- Deliberately no CountyRepresentative/Users requirement at referral creation.
 SELECT @RootId=ParentReferralId FROM TahghighatV2.Referral
  WHERE ReferralId=@HozeReferralId;
 IF @RootId IS NULL THROW 54014,N'ارجاع حوزه اصلی یافت نشد.',1;
 BEGIN TRY
  BEGIN TRANSACTION;
  DECLARE @LockName nvarchar(200)=N'MRV2:REF:'+CONVERT(nvarchar(20),@RootId);
  EXEC @Lock=sys.sp_getapplock @Resource=@LockName,@LockMode=N'Exclusive',
   @LockOwner=N'Transaction',@LockTimeout=10000;
  IF @Lock<0 THROW 54015,N'پرونده در حال پردازش است.',1;
  SELECT @CaseId=r.CaseId,@State=r.StateCode
  FROM TahghighatV2.Referral r WITH(UPDLOCK,HOLDLOCK)
  JOIN TahghighatV2.Referral p ON p.ReferralId=r.ParentReferralId
  WHERE r.ReferralId=@HozeReferralId AND r.ParentReferralId=@RootId
   AND r.ReceiverLevel='HOZE' AND r.ToMahal=@Hoze
   AND r.IsClosed=0 AND r.IsDeleted=0
   AND p.ParentReferralId IS NULL AND p.StateCode='PENDING_CHILD_RESULTS'
   AND p.IsClosed=0 AND p.IsDeleted=0;
  IF @State<>'CHILD_WORKING' OR @State IS NULL
   THROW 54016,N'حوزه باید در وضعیت بررسی فعال باشد.',1;
  IF EXISTS(
   SELECT 1 FROM TahghighatV2.Referral c WITH(UPDLOCK,HOLDLOCK)
   WHERE c.ParentReferralId=@HozeReferralId AND c.ToMahal=@CountyCityId
    AND c.ReceiverLevel='SHAHR' AND c.IsDeleted=0)
   THROW 54017,N'برای این شهرستان در همین پرونده قبلاً ارجاع ثبت شده است.',1;
  INSERT TahghighatV2.Referral
   (CaseId,ParentReferralId,FromMahal,ToMahal,ReceiverLevel,StateCode,Description,CreatedByUserId)
  VALUES(@CaseId,@HozeReferralId,@Hoze,@CountyCityId,'SHAHR','CHILD_INBOX',@Description,@UserId);
  SET @NewId=CONVERT(bigint,SCOPE_IDENTITY());
  INSERT TahghighatV2.WorkflowEvent
   (ReferralId,ActionCode,PreviousStateCode,NewStateCode,Description,ActorUserId)
  VALUES(@HozeReferralId,'HOZE_REFER_COUNTY',@State,@State,@Description,@UserId),
        (@NewId,'CHILD_CREATED',NULL,'CHILD_INBOX',@Description,@UserId);
  COMMIT;
  SELECT CONVERT(bit,1) IsSuccess,@NewId CountyReferralId,@HozeReferralId HozeReferralId;
 END TRY
 BEGIN CATCH
  IF XACT_STATE()<>0 ROLLBACK;
  THROW;
 END CATCH;
END;
GO

/* Phase 92: soft-delete ONLY untouched subordinate county referrals issued by the current HOZE.
   Both the creation lock on root and the county-processing lock on HOZE parent
   are acquired. The child must have no destination action or downstream records.
   The operation leaves an immutable audit record, not a physical DELETE. */
CREATE OR ALTER PROCEDURE TahghighatV2.SP_HozeDeleteUntouchedCountyReferral
 @HozeReferralId bigint,@CountyReferralId bigint,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 SET XACT_ABORT ON;
 IF @HozeReferralId IS NULL OR @HozeReferralId<=0
   OR @CountyReferralId IS NULL OR @CountyReferralId<=0
   OR @UserId IS NULL OR @UserId<=0 OR @HozeReferralId=@CountyReferralId
   THROW 54920,N'شناسه ارجاع حوزه، شهرستان یا کاربر نامعتبر است.',1;
 DECLARE @Mahal int,@Post int,@RootId bigint,@HozeState varchar(40),
         @CountyState varchar(40),@Lock int;
 SELECT @Mahal=u.Mahal,@Post=u.PostId FROM dbo.Users u
 WHERE u.UserId=@UserId AND u.IsActive=1;
 IF @Post<>61 OR NOT EXISTS(SELECT 1 FROM dbo.Citys c
       WHERE c.CityId=@Mahal AND c.IsHoze=1 AND c.IsActive=1)
   OR NOT EXISTS(SELECT 1 FROM TahghighatV2.PostActionPermission p
       WHERE p.PostId=61 AND p.ActionCode='HOZE_DELETE_COUNTY_REFERRAL' AND p.IsAllowed=1)
   THROW 54921,N'مجوز حذف ارجاع شهرستان برای این کاربر وجود ندارد.',1;
 -- Only a hint before transaction; all scope/permissions and states are rechecked under locks.
 SELECT @RootId=h.ParentReferralId FROM TahghighatV2.Referral h
 WHERE h.ReferralId=@HozeReferralId AND h.ToMahal=@Mahal
   AND h.ReceiverLevel='HOZE' AND h.IsDeleted=0;
 IF @RootId IS NULL THROW 54922,N'ارجاع حوزه در محدوده دسترسی شما یافت نشد.',1;
 BEGIN TRY
  BEGIN TRANSACTION;
  DECLARE @RootResource nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(25),@RootId);
  DECLARE @HozeResource nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(25),@HozeReferralId);
  EXEC @Lock=sys.sp_getapplock @Resource=@RootResource,@LockMode=N'Exclusive',
       @LockOwner=N'Transaction',@LockTimeout=10000;
  IF @Lock<0 THROW 54923,N'پرونده در حال پردازش است؛ دوباره تلاش کنید.',1;
  EXEC @Lock=sys.sp_getapplock @Resource=@HozeResource,@LockMode=N'Exclusive',
       @LockOwner=N'Transaction',@LockTimeout=10000;
  IF @Lock<0 THROW 54924,N'پرونده در حال پردازش است؛ دوباره تلاش کنید.',1;
  SELECT @HozeState=h.StateCode
  FROM TahghighatV2.Referral h WITH(UPDLOCK,HOLDLOCK)
  JOIN TahghighatV2.Referral root WITH(UPDLOCK,HOLDLOCK) ON root.ReferralId=h.ParentReferralId
  WHERE h.ReferralId=@HozeReferralId AND h.ParentReferralId=@RootId
    AND h.ReceiverLevel='HOZE' AND h.ToMahal=@Mahal
    AND h.StateCode='CHILD_WORKING' AND h.IsClosed=0 AND h.IsDeleted=0
    AND root.ParentReferralId IS NULL AND root.StateCode='PENDING_CHILD_RESULTS'
    AND root.IsClosed=0 AND root.IsDeleted=0;
  IF @HozeState IS NULL THROW 54925,N'حوزه در وضعیت مجاز برای حذف ارجاع نیست.',1;
  SELECT @CountyState=c.StateCode
  FROM TahghighatV2.Referral c WITH(UPDLOCK,HOLDLOCK)
  JOIN dbo.Citys county ON county.CityId=c.ToMahal
  JOIN dbo.Citys hoze ON hoze.CityId=@Mahal
  WHERE c.ReferralId=@CountyReferralId AND c.ParentReferralId=@HozeReferralId
    AND c.ReceiverLevel='SHAHR' AND c.FromMahal=@Mahal
    AND county.IsHoze=0 AND county.CityIdHozeh=@Mahal AND county.PCityId=hoze.PCityId
    AND c.StateCode='CHILD_INBOX' AND c.IsClosed=0 AND c.IsDeleted=0;
  IF @CountyState IS NULL THROW 54926,N'ارجاع شهرستان رسیدگی شده یا قابل حذف نیست.',1;
  IF NOT EXISTS (SELECT 1 FROM TahghighatV2.WorkflowEvent e WITH(UPDLOCK,HOLDLOCK)
        WHERE e.ReferralId=@CountyReferralId AND e.ActionCode='CHILD_CREATED')
     OR EXISTS (SELECT 1 FROM TahghighatV2.WorkflowEvent e WITH(UPDLOCK,HOLDLOCK)
        WHERE e.ReferralId=@CountyReferralId AND e.ActionCode<>'CHILD_CREATED')
     OR EXISTS (SELECT 1 FROM TahghighatV2.Referral sub WITH(UPDLOCK,HOLDLOCK)
        WHERE sub.ParentReferralId=@CountyReferralId)
     OR EXISTS (SELECT 1 FROM TahghighatV2.ResearchAssignment a WITH(UPDLOCK,HOLDLOCK)
        WHERE a.ReferralId=@CountyReferralId)
     OR EXISTS (SELECT 1 FROM TahghighatV2.CountySummary cs WITH(UPDLOCK,HOLDLOCK)
        WHERE cs.ReferralId=@CountyReferralId)
     OR EXISTS (SELECT 1 FROM TahghighatV2.NoResearchDecision nr WITH(UPDLOCK,HOLDLOCK)
        WHERE nr.ReferralId=@CountyReferralId)
    THROW 54927,N'شهرستان اقدام، تحقیق یا جمع‌بندی ثبت کرده است؛ حذف مجاز نیست.',1;
  UPDATE TahghighatV2.Referral
    SET IsDeleted=1,UpdatedByUserId=@UserId,UpdatedAtUtc=SYSUTCDATETIME()
  WHERE ReferralId=@CountyReferralId AND ParentReferralId=@HozeReferralId
    AND StateCode='CHILD_INBOX' AND IsClosed=0 AND IsDeleted=0;
  IF @@ROWCOUNT<>1 THROW 54928,N'وضعیت ارجاع شهرستان تغییر کرده است؛ دوباره تلاش کنید.',1;
  DECLARE @Reason nvarchar(250)=N'حذف ارجاع شهرستان فرعی پیش از اقدام مقصد';
  INSERT TahghighatV2.WorkflowEvent
    (ReferralId,ActionCode,PreviousStateCode,NewStateCode,Description,ActorUserId)
  VALUES (@CountyReferralId,'HOZE_DELETE_COUNTY_REFERRAL','CHILD_INBOX','CHILD_INBOX',@Reason,@UserId),
    (@HozeReferralId,'HOZE_DELETE_COUNTY_REFERRAL',@HozeState,@HozeState,
      @Reason+N'؛ ارجاع شماره '+CONVERT(nvarchar(25),@CountyReferralId),@UserId);
  COMMIT TRANSACTION;
  SELECT CONVERT(bit,1) IsSuccess,@CountyReferralId CountyReferralId,@HozeReferralId HozeReferralId;
 END TRY
 BEGIN CATCH
  IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
  THROW;
 END CATCH;
END;
GO

/* Phase 93: restore the former system's person/cooperation-based investigator choices.
   Investigator employment/identity is separate from authentication; no dbo.Users row is required.
   This script only changes HOZE candidate and assignment procedures. */
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_GetHozeInvestigatorCandidates
 @HozeReferralId bigint,
 @UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @Hoze bigint,@Post int;
 SELECT @Hoze=u.Mahal,@Post=u.PostId
 FROM dbo.Users u WHERE u.UserId=@UserId AND u.IsActive=1;
 IF ISNULL(@Post,0) NOT IN(60,61)
   OR NOT EXISTS (SELECT 1 FROM TahghighatV2.PostActionPermission p
       WHERE p.PostId=@Post AND p.ActionCode='HOZE_ASSIGN_INVESTIGATOR' AND p.IsAllowed=1)
   OR NOT EXISTS
 ( SELECT 1 FROM TahghighatV2.Referral r
   JOIN TahghighatV2.Referral parent ON parent.ReferralId=r.ParentReferralId
   JOIN dbo.Citys h ON h.CityId=r.ToMahal AND h.IsHoze=1 AND h.IsActive=1
   WHERE r.ReferralId=@HozeReferralId AND r.ToMahal=@Hoze
   AND r.ReceiverLevel='HOZE' AND r.StateCode='CHILD_WORKING'
   AND r.IsClosed=0 AND r.IsDeleted=0
   AND parent.StateCode='PENDING_CHILD_RESULTS' AND parent.IsClosed=0 AND parent.IsDeleted=0 )
  THROW 54884,N'این پرونده در مرحله انتساب محقق حوزه نیست یا مجوز ارجاع ندارید.',1;

 /* One row per PersonId, even when one researcher has several active Hamkari
    records in this constituency. Choose the same preferred county as the
    assignment procedure: constituency center first, then the lowest CityId.
    Account creation and AuthUserId are NOT required for selection. */
 SELECT p.PersonId,ir.InvestigatorKey,ir.AuthUserId,
  selected.CountyCityId,selected.CountyName,
  LTRIM(RTRIM(CONCAT(ISNULL(p.FirstName,N''),N' ',ISNULL(p.LastName,N'')))) FullName,
  CONVERT(bit,CASE WHEN ir.InvestigatorKey IS NULL OR ir.IsActive=1 THEN 1 ELSE 0 END) IsAssignable
 FROM dbo.Person p
 JOIN dbo.Citys center ON center.CityId=@Hoze AND center.IsHoze=1 AND center.IsActive=1
 CROSS APPLY
 ( SELECT TOP (1) c.CityId CountyCityId,c.Name CountyName
   FROM Hamkari.PersonHamkari h
   JOIN dbo.Citys c ON c.CityId=h.MahalHamkari AND c.IsActive=1
   WHERE h.PersonId=p.PersonId AND h.NoeHamkari=2
    AND ISNULL(h.IsActive,0)=1 AND ISNULL(h.IsDeleted,0)=0
    AND c.PCityId=center.PCityId
    AND (c.CityIdHozeh=@Hoze OR c.CityId=@Hoze)
   ORDER BY CASE WHEN c.CityId=@Hoze THEN 0 ELSE 1 END,c.CityId
 ) selected
 OUTER APPLY
 ( SELECT TOP (1) r.InvestigatorKey,r.AuthUserId,r.IsActive
   FROM TahghighatV2.InvestigatorRegistry r
   WHERE r.PersonId=p.PersonId AND r.ProvinceCityId=center.PCityId
   ORDER BY r.IsActive DESC,r.InvestigatorKey
 ) ir
 WHERE ISNULL(p.IsDelete,0)=0
  AND NOT EXISTS (
    SELECT 1 FROM TahghighatV2.ResearchAssignment a
    JOIN TahghighatV2.InvestigatorRegistry already ON already.InvestigatorKey=a.InvestigatorId
    WHERE a.ReferralId=@HozeReferralId AND already.PersonId=p.PersonId
      AND a.StatusCode<>'CANCELLED'
  )
 ORDER BY FullName,selected.CountyName,p.PersonId;
END;
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_HozeAssignInvestigator
 @HozeReferralId bigint,
 @Instruction nvarchar(max),
 @UserId bigint,
 @InvestigatorKey bigint=NULL,
 @DueDatePersian char(10)=NULL,
 @PersonId bigint=NULL
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 IF @HozeReferralId IS NULL OR @HozeReferralId<=0 OR @UserId IS NULL OR @UserId<=0
    OR NULLIF(LTRIM(RTRIM(@Instruction)),N'') IS NULL OR LEN(@Instruction)>6000
    OR (@PersonId IS NULL AND @InvestigatorKey IS NULL)
  THROW 54886,N'اطلاعات انتساب کامل نیست.',1;
 IF @PersonId IS NULL AND @InvestigatorKey IS NOT NULL
  SELECT @PersonId=PersonId FROM TahghighatV2.InvestigatorRegistry
  WHERE InvestigatorKey=@InvestigatorKey AND IsActive=1;
 IF @PersonId IS NULL OR @PersonId<=0
  THROW 54888,N'هویت محقق انتخاب‌شده معتبر نیست.',1;

 DECLARE @Hoze bigint,@Post int,@Root bigint,@State varchar(40),@Lock int,
  @InvLock int,@NewId bigint,@Province int,@County int,@EffectiveKey bigint,@RegActive bit;
 SELECT @Hoze=u.Mahal,@Post=u.PostId
 FROM dbo.Users u WHERE u.UserId=@UserId AND u.IsActive=1;
 IF ISNULL(@Post,0) NOT IN(60,61)
    OR NOT EXISTS (SELECT 1 FROM TahghighatV2.PostActionPermission p
      WHERE p.PostId=@Post AND p.ActionCode='HOZE_ASSIGN_INVESTIGATOR' AND p.IsAllowed=1)
    OR NOT EXISTS
 (SELECT 1 FROM dbo.Citys c WHERE c.CityId=@Hoze AND c.IsHoze=1 AND c.IsActive=1)
  THROW 54887,N'مجوز ارجاع به محقق ویژه در حوزه انتخابیه وجود ندارد.',1;
 SELECT @Root=r.ParentReferralId
 FROM TahghighatV2.Referral r WHERE r.ReferralId=@HozeReferralId
  AND r.ToMahal=@Hoze AND r.ReceiverLevel='HOZE' AND r.IsDeleted=0;
 IF @Root IS NULL THROW 54889,N'ارجاع حوزه معتبر نیست.',1;

 BEGIN TRY
  BEGIN TRANSACTION;
  DECLARE @LockName nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(20),@Root);
  EXEC @Lock=sys.sp_getapplock @Resource=@LockName,
   @LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
  IF @Lock<0 THROW 54890,N'پرونده در حال پردازش است.',1;

  SELECT @State=r.StateCode FROM TahghighatV2.Referral r WITH(UPDLOCK,HOLDLOCK)
  JOIN TahghighatV2.Referral parent ON parent.ReferralId=r.ParentReferralId
  WHERE r.ReferralId=@HozeReferralId AND r.ToMahal=@Hoze
   AND r.ReceiverLevel='HOZE' AND r.IsClosed=0 AND r.IsDeleted=0
   AND parent.ReferralId=@Root AND parent.StateCode='PENDING_CHILD_RESULTS'
   AND parent.IsClosed=0 AND parent.IsDeleted=0;
  IF ISNULL(@State,'')<>'CHILD_WORKING'
   THROW 54891,N'ارجاع حوزه در مرحله بررسی فعال نیست.',1;

  /* Resolve and validate actual person+cooperation in this constituency.
     It never requires a login or attempts to create one. */
  SELECT TOP(1) @County=CONVERT(int,c.CityId),@Province=CONVERT(int,center.PCityId)
  FROM Hamkari.PersonHamkari h
  JOIN dbo.Person p ON p.PersonId=h.PersonId AND ISNULL(p.IsDelete,0)=0
  JOIN dbo.Citys c ON c.CityId=h.MahalHamkari AND c.IsActive=1
  JOIN dbo.Citys center ON center.CityId=@Hoze AND center.IsActive=1 AND center.IsHoze=1
    AND c.PCityId=center.PCityId AND (c.CityIdHozeh=@Hoze OR c.CityId=@Hoze)
  WHERE h.PersonId=@PersonId AND h.NoeHamkari=2
    AND ISNULL(h.IsActive,0)=1 AND ISNULL(h.IsDeleted,0)=0
  ORDER BY CASE WHEN c.CityId=@Hoze THEN 0 ELSE 1 END,c.CityId;
  IF @County IS NULL OR @Province IS NULL
   THROW 54888,N'محقق فاقد همکاری فعال در این حوزه انتخابیه است.',1;

  /* The registry is an identity mapping, not a login. Create on the first
     assignment only; respect an explicitly deactivated existing identity. */
  DECLARE @InvestigatorLockName nvarchar(255)=N'MRV2:INV:'+CONVERT(nvarchar(20),@Province)
    +N':'+CONVERT(nvarchar(20),@PersonId);
  EXEC @InvLock=sys.sp_getapplock @Resource=@InvestigatorLockName,
   @LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
  IF @InvLock<0 THROW 54890,N'اطلاعات محقق در حال پردازش است.',1;
  SELECT TOP(1) @EffectiveKey=r.InvestigatorKey,@RegActive=r.IsActive
  FROM TahghighatV2.InvestigatorRegistry r WITH(UPDLOCK,HOLDLOCK)
  WHERE r.PersonId=@PersonId AND r.ProvinceCityId=@Province
  ORDER BY r.IsActive DESC,r.InvestigatorKey;
  IF @EffectiveKey IS NOT NULL AND @RegActive=0
   THROW 54888,N'ثبت محقق در رجیستری غیرفعال شده است.',1;
  IF @EffectiveKey IS NULL
  BEGIN
   INSERT TahghighatV2.InvestigatorRegistry
    (PersonId,ProvinceCityId,LegacyCodeMohaghegh,AuthUserId,IsActive,RegisteredBySqlLogin)
   SELECT p.PersonId,@Province,p.ShomarehParvandeh,NULL,1,ORIGINAL_LOGIN()
   FROM dbo.Person p WHERE p.PersonId=@PersonId;
   SET @EffectiveKey=CONVERT(bigint,SCOPE_IDENTITY());
  END;

  /* An existing inactive CountyInvestigator link is an explicit revocation. */
  IF EXISTS(SELECT 1 FROM TahghighatV2.CountyInvestigator ci
   WHERE ci.InvestigatorKey=@EffectiveKey AND ci.CountyCityId=@County AND ci.IsActive=0)
   THROW 54888,N'مجوز همکاری شهرستانی این محقق غیرفعال است.',1;
  IF NOT EXISTS(SELECT 1 FROM TahghighatV2.CountyInvestigator ci WITH(UPDLOCK,HOLDLOCK)
   WHERE ci.InvestigatorKey=@EffectiveKey AND ci.CountyCityId=@County)
   INSERT TahghighatV2.CountyInvestigator
    (InvestigatorKey,CountyCityId,IsActive,RegisteredBySqlLogin)
   VALUES(@EffectiveKey,@County,1,ORIGINAL_LOGIN());

  IF EXISTS(SELECT 1 FROM TahghighatV2.ResearchAssignment a WITH(UPDLOCK,HOLDLOCK)
   JOIN TahghighatV2.InvestigatorRegistry already ON already.InvestigatorKey=a.InvestigatorId
   WHERE a.ReferralId=@HozeReferralId AND already.PersonId=@PersonId
   AND a.StatusCode<>'CANCELLED')
   THROW 54892,N'برای همین محقق در این پرونده قبلاً انتساب ثبت شده است.',1;

  INSERT TahghighatV2.ResearchAssignment
   (ReferralId,InvestigatorId,DueDatePersian,Instruction,StatusCode,CreatedByUserId)
  VALUES(@HozeReferralId,@EffectiveKey,@DueDatePersian,@Instruction,'PENDING',@UserId);
  SET @NewId=CONVERT(bigint,SCOPE_IDENTITY());
  INSERT TahghighatV2.ResearchAssignmentEvent
   (AssignmentId,ActionCode,BeforeStatus,AfterStatus,Description,ActorUserId)
  VALUES(@NewId,'HOZE_ASSIGN_INVESTIGATOR',NULL,'PENDING',@Instruction,@UserId);
  INSERT TahghighatV2.WorkflowEvent
   (ReferralId,ActionCode,PreviousStateCode,NewStateCode,Description,ActorUserId)
  VALUES(@HozeReferralId,'HOZE_ASSIGN_INVESTIGATOR',@State,@State,@Instruction,@UserId);
  COMMIT;
  SELECT CONVERT(bit,1) IsSuccess,@NewId AssignmentId,@EffectiveKey InvestigatorKey;
 END TRY
 BEGIN CATCH
  IF XACT_STATE()<>0 ROLLBACK;
  THROW;
 END CATCH;
END;
GO


/* Phase 97: authorized HOZE officer may document a worksheet for a registry-only
   investigator, without creating or assuming any dbo.Users account for them.
   The actor and investigator remain distinct and fully auditable. */
IF NOT EXISTS (SELECT 1 FROM TahghighatV2.WorkflowAction WHERE ActionCode='HOZE_OFFICER_SAVE_WORKSHEET')
  INSERT TahghighatV2.WorkflowAction(ActionCode,TitleFa)
  VALUES('HOZE_OFFICER_SAVE_WORKSHEET',N'ثبت کاربرگ محقق توسط مسئول حوزه');
GO
IF NOT EXISTS (SELECT 1 FROM TahghighatV2.WorkflowAction WHERE ActionCode='HOZE_OFFICER_START')
  INSERT TahghighatV2.WorkflowAction(ActionCode,TitleFa)
  VALUES('HOZE_OFFICER_START',N'شروع تحقیق با ثبت کاربرگ توسط مسئول حوزه');
GO
IF NOT EXISTS (SELECT 1 FROM TahghighatV2.PostActionPermission WHERE PostId=61 AND ActionCode='HOZE_OFFICER_SAVE_WORKSHEET')
  INSERT TahghighatV2.PostActionPermission(PostId,ActionCode,IsAllowed)
  VALUES(61,'HOZE_OFFICER_SAVE_WORKSHEET',1);
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_HozeOfficerSaveWorksheet
 @AssignmentId bigint,@ReportText nvarchar(max),@UserId bigint
AS
BEGIN
  SET NOCOUNT ON; SET XACT_ABORT ON;
  IF @AssignmentId IS NULL OR @AssignmentId<=0 OR @UserId IS NULL OR @UserId<=0
    OR NULLIF(LTRIM(RTRIM(@ReportText)),N'') IS NULL OR LEN(@ReportText)>12000
    THROW 54950,N'اطلاعات کاربرگ معتبر نیست.',1;

  DECLARE @Root bigint,@Hoze bigint,@OldStatus varchar(20),@HozeState varchar(40),
          @Lock int,@Id bigint;
  -- Scope is tied to the officer's *actual* active role and assigned HOZE.
  SELECT @Hoze=r.ReferralId,@Root=r.ParentReferralId
  FROM TahghighatV2.ResearchAssignment a
  JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId AND r.ReceiverLevel='HOZE'
  JOIN dbo.Users u ON u.UserId=@UserId AND u.IsActive=1 AND u.PostId=61 AND u.Mahal=r.ToMahal
  JOIN TahghighatV2.PostActionPermission perm ON perm.PostId=u.PostId
    AND perm.ActionCode='HOZE_OFFICER_SAVE_WORKSHEET' AND perm.IsAllowed=1
  WHERE a.AssignmentId=@AssignmentId AND r.IsDeleted=0 AND r.IsClosed=0;
  IF @Root IS NULL THROW 54951,N'برای ثبت کاربرگ این انتساب مجوز ندارید.',1;

  BEGIN TRY
    BEGIN TRANSACTION;
    DECLARE @LockName nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(20),@Root);
    EXEC @Lock=sys.sp_getapplock @Resource=@LockName,@LockMode='Exclusive',
      @LockOwner='Transaction',@LockTimeout=10000;
    IF @Lock<0 THROW 54952,N'پرونده در حال پردازش است.',1;

    SELECT @OldStatus=a.StatusCode,@HozeState=r.StateCode
    FROM TahghighatV2.ResearchAssignment a WITH(UPDLOCK,HOLDLOCK)
    JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId
    JOIN TahghighatV2.Referral p ON p.ReferralId=r.ParentReferralId
    WHERE a.AssignmentId=@AssignmentId AND r.ReferralId=@Hoze AND r.IsDeleted=0
      AND r.IsClosed=0 AND p.ReferralId=@Root AND p.IsDeleted=0 AND p.IsClosed=0
      AND p.StateCode='PENDING_CHILD_RESULTS' AND r.StateCode='CHILD_WORKING';
    IF @OldStatus NOT IN('PENDING','IN_PROGRESS') OR @HozeState<>'CHILD_WORKING'
      OR @OldStatus IS NULL THROW 54953,N'این انتساب در وضعیت مجاز ثبت کاربرگ نیست.',1;

    IF @OldStatus='PENDING'
    BEGIN
      UPDATE TahghighatV2.ResearchAssignment SET StatusCode='IN_PROGRESS'
      WHERE AssignmentId=@AssignmentId;
      INSERT TahghighatV2.ResearchAssignmentEvent
        (AssignmentId,ActionCode,BeforeStatus,AfterStatus,Description,ActorUserId)
      VALUES(@AssignmentId,'HOZE_OFFICER_START','PENDING','IN_PROGRESS',
             N'آغاز تحقیق با ثبت اولین کاربرگ توسط مسئول مجاز حوزه',@UserId);
    END;
    INSERT TahghighatV2.ResearchWorksheet(AssignmentId,ReportText,CreatedByUserId)
    VALUES(@AssignmentId,LTRIM(RTRIM(@ReportText)),@UserId);
    SET @Id=CONVERT(bigint,SCOPE_IDENTITY());
    INSERT TahghighatV2.ResearchAssignmentEvent
      (AssignmentId,ActionCode,BeforeStatus,AfterStatus,Description,ActorUserId)
    VALUES(@AssignmentId,'HOZE_OFFICER_SAVE_WORKSHEET',
           'IN_PROGRESS','IN_PROGRESS',N'ثبت کاربرگ توسط مسئول حوزه؛ شناسه '+CONVERT(nvarchar(20),@Id),@UserId);
    INSERT TahghighatV2.WorkflowEvent
      (ReferralId,ActionCode,PreviousStateCode,NewStateCode,Description,ActorUserId)
    VALUES(@Hoze,'HOZE_OFFICER_SAVE_WORKSHEET','CHILD_WORKING','CHILD_WORKING',
           N'ثبت کاربرگ محقق؛ شناسه '+CONVERT(nvarchar(20),@Id),@UserId);
    COMMIT;
    SELECT CONVERT(bit,1) IsSuccess,@Id WorksheetId;
  END TRY
  BEGIN CATCH
    IF XACT_STATE()<>0 ROLLBACK;
    THROW;
  END CATCH;
END;
GO
GO

/* Phase 104: Province-style investigator worksheet, investigator consolidation,
   and constituency consolidation for HOZE chair (60) and officer (61).
   These grants do not grant CHILD_REPLY, HOZE_CANCEL_ASSIGNMENT or final approval.
   All explicit administrative denials are preserved. */
IF NOT EXISTS (SELECT 1 FROM TahghighatV2.WorkflowAction WHERE ActionCode='HOZE_SAVE_SUMMARY')
 INSERT TahghighatV2.WorkflowAction(ActionCode,TitleFa) VALUES('HOZE_SAVE_SUMMARY',N'ثبت جمع‌بندی حوزه');
GO
IF NOT EXISTS (SELECT 1 FROM TahghighatV2.WorkflowAction WHERE ActionCode='HOZE_OFFICER_COMPLETE_ASSIGNMENT')
 INSERT TahghighatV2.WorkflowAction(ActionCode,TitleFa) VALUES('HOZE_OFFICER_COMPLETE_ASSIGNMENT',N'ثبت جمع‌بندی و تکمیل تحقیق محقق توسط حوزه');
GO
INSERT TahghighatV2.PostActionPermission(PostId,ActionCode,IsAllowed)
SELECT p.PostId,actions.ActionCode,CONVERT(bit,1)
FROM (VALUES(60),(61)) p(PostId)
CROSS JOIN (VALUES('HOZE_OFFICER_SAVE_WORKSHEET'),('HOZE_SAVE_SUMMARY'),('HOZE_OFFICER_COMPLETE_ASSIGNMENT')) actions(ActionCode)
WHERE NOT EXISTS(SELECT 1 FROM TahghighatV2.PostActionPermission existing
 WHERE existing.PostId=p.PostId AND existing.ActionCode=actions.ActionCode);
GO
/* Keep the original summary transaction semantics. */
CREATE OR ALTER PROCEDURE [TahghighatV2].[SP_SaveHozeSummary]
 @HozeReferralId bigint,@SummaryText nvarchar(max),@UserId bigint
AS BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 IF @HozeReferralId IS NULL OR @HozeReferralId<=0 OR @UserId IS NULL OR @UserId<=0
  OR @SummaryText IS NULL OR LEN(LTRIM(RTRIM(@SummaryText)))<20 OR LEN(@SummaryText)>10000
 THROW 54510,N'متن جمع‌بندی حوزه باید بین ۲۰ تا ۱۰۰۰۰ نویسه باشد.',1;
 DECLARE @HozeCity int,@Post int,@Root bigint,@Lock int,@SummaryId bigint;
 SELECT @HozeCity=Mahal,@Post=PostId FROM dbo.Users WHERE UserId=@UserId AND IsActive=1;
 IF ISNULL(@Post,0) NOT IN(60,61) OR NOT EXISTS(SELECT 1 FROM TahghighatV2.PostActionPermission
 WHERE PostId=@Post AND ActionCode='HOZE_SAVE_SUMMARY' AND IsAllowed=1)
 THROW 54511,N'مجوز پاسخ حوزه موجود نیست.',1;
 SELECT @Root=ParentReferralId FROM TahghighatV2.Referral
 WHERE ReferralId=@HozeReferralId AND ReceiverLevel='HOZE' AND ToMahal=@HozeCity AND IsDeleted=0;
 IF @Root IS NULL THROW 54512,N'ارجاع حوزه مجاز یافت نشد.',1;
 BEGIN TRY BEGIN TRANSACTION;
 DECLARE @Key nvarchar(200)=N'MRV2:REF:'+CONVERT(nvarchar(20),@Root);
 EXEC @Lock=sys.sp_getapplock @Resource=@Key,@LockMode=N'Exclusive',@LockOwner=N'Transaction',@LockTimeout=10000;
 IF @Lock<0 THROW 54513,N'پرونده در حال پردازش است.',1;
 IF NOT EXISTS(SELECT 1 FROM TahghighatV2.Referral h WITH(UPDLOCK,HOLDLOCK)
 JOIN TahghighatV2.Referral p ON p.ReferralId=h.ParentReferralId
 WHERE h.ReferralId=@HozeReferralId AND h.ToMahal=@HozeCity AND h.StateCode='CHILD_WORKING'
 AND h.IsClosed=0 AND h.IsDeleted=0 AND p.ReferralId=@Root
 AND p.StateCode='PENDING_CHILD_RESULTS' AND p.IsClosed=0 AND p.IsDeleted=0)
 THROW 54514,N'حوزه در وضعیت قابل ویرایش جمع‌بندی نیست.',1;
 UPDATE TahghighatV2.HozeSummary WITH(UPDLOCK,SERIALIZABLE)
 SET SummaryText=LTRIM(RTRIM(@SummaryText)),UpdatedByUserId=@UserId,UpdatedAtUtc=SYSUTCDATETIME()
 WHERE ReferralId=@HozeReferralId;
 IF @@ROWCOUNT=0 INSERT TahghighatV2.HozeSummary(ReferralId,SummaryText,CreatedByUserId,UpdatedByUserId)
 VALUES(@HozeReferralId,LTRIM(RTRIM(@SummaryText)),@UserId,@UserId);
 SELECT @SummaryId=SummaryId FROM TahghighatV2.HozeSummary WHERE ReferralId=@HozeReferralId;
 INSERT TahghighatV2.WorkflowEvent(ReferralId,ActionCode,PreviousStateCode,NewStateCode,Description,ActorUserId)
 VALUES(@HozeReferralId,'HOZE_SAVE_SUMMARY','CHILD_WORKING','CHILD_WORKING',N'ذخیره جمع‌بندی حوزه',@UserId);
 COMMIT; SELECT CONVERT(bit,1) IsSuccess,@SummaryId SummaryId;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK; THROW; END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE TahghighatV2.SP_HozeOfficerCompleteAssignment
 @AssignmentId bigint,@Summary nvarchar(max),@UserId bigint
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 SET @Summary=LTRIM(RTRIM(ISNULL(@Summary,N'')));
 IF ISNULL(@AssignmentId,0)<=0 OR ISNULL(@UserId,0)<=0
   OR LEN(@Summary)<20 OR LEN(@Summary)>12000
  THROW 54960,N'شناسه انتساب و متن جمع‌بندی حداقل ۲۰ و حداکثر ۱۲۰۰۰ نویسه الزامی است.',1;
 DECLARE @Hoze bigint,@Root bigint,@Mahal int,@Post int,@Status varchar(20),@Lock int;
 SELECT @Mahal=u.Mahal,@Post=u.PostId FROM dbo.Users u WHERE u.UserId=@UserId AND u.IsActive=1;
 IF ISNULL(@Post,0) NOT IN(60,61)
  OR NOT EXISTS(SELECT 1 FROM dbo.Citys c WHERE c.CityId=@Mahal AND c.IsHoze=1 AND c.IsActive=1)
  OR NOT EXISTS(SELECT 1 FROM TahghighatV2.PostActionPermission ap
    WHERE ap.PostId=@Post AND ap.ActionCode='HOZE_OFFICER_COMPLETE_ASSIGNMENT' AND ap.IsAllowed=1)
  THROW 54961,N'مجوز جمع‌بندی و تکمیل تحقیق محقق در این حوزه وجود ندارد.',1;
 SELECT @Hoze=r.ReferralId,@Root=r.ParentReferralId
 FROM TahghighatV2.ResearchAssignment a
 JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId AND r.ReceiverLevel='HOZE'
 WHERE a.AssignmentId=@AssignmentId AND r.ToMahal=@Mahal AND r.IsDeleted=0 AND r.IsClosed=0;
 IF @Root IS NULL THROW 54962,N'انتساب مربوط به حوزه انتخابیه این کاربر نیست.',1;
 BEGIN TRY
  BEGIN TRANSACTION;
  DECLARE @Resource nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(20),@Root);
  EXEC @Lock=sys.sp_getapplock @Resource=@Resource,@LockMode='Exclusive',
    @LockOwner='Transaction',@LockTimeout=10000;
  IF @Lock<0 THROW 54963,N'پرونده در حال پردازش است.',1;
  SELECT @Status=a.StatusCode FROM TahghighatV2.ResearchAssignment a WITH(UPDLOCK,HOLDLOCK)
  JOIN TahghighatV2.Referral h ON h.ReferralId=a.ReferralId
  JOIN TahghighatV2.Referral parent ON parent.ReferralId=h.ParentReferralId
  WHERE a.AssignmentId=@AssignmentId AND h.ReferralId=@Hoze AND h.ToMahal=@Mahal
   AND h.ReceiverLevel='HOZE' AND h.StateCode='CHILD_WORKING'
   AND h.IsClosed=0 AND h.IsDeleted=0 AND parent.ReferralId=@Root
   AND parent.StateCode='PENDING_CHILD_RESULTS' AND parent.IsClosed=0 AND parent.IsDeleted=0;
  IF @Status IS NULL OR @Status<>'IN_PROGRESS'
    THROW 54964,N'محقق باید در وضعیت در حال تحقیق باشد.',1;
  IF NOT EXISTS(SELECT 1 FROM TahghighatV2.ResearchWorksheet w WITH(HOLDLOCK)
   WHERE w.AssignmentId=@AssignmentId)
    THROW 54965,N'برای جمع‌بندی محقق حداقل یک کاربرگ الزامی است.',1;
  UPDATE TahghighatV2.ResearchAssignment
   SET StatusCode='DONE',Summary=@Summary,FinishedAtUtc=SYSUTCDATETIME()
   WHERE AssignmentId=@AssignmentId AND StatusCode='IN_PROGRESS';
  IF @@ROWCOUNT<>1 THROW 54966,N'وضعیت انتساب تغییر کرده است.',1;
  INSERT TahghighatV2.ResearchAssignmentEvent
   (AssignmentId,ActionCode,BeforeStatus,AfterStatus,Description,ActorUserId)
  VALUES(@AssignmentId,'HOZE_OFFICER_COMPLETE_ASSIGNMENT','IN_PROGRESS','DONE',@Summary,@UserId);
  INSERT TahghighatV2.WorkflowEvent
   (ReferralId,ActionCode,PreviousStateCode,NewStateCode,Description,ActorUserId)
  VALUES(@Hoze,'HOZE_OFFICER_COMPLETE_ASSIGNMENT','CHILD_WORKING','CHILD_WORKING',
   N'جمع‌بندی و تکمیل محقق؛ انتساب '+CONVERT(nvarchar(20),@AssignmentId),@UserId);
  COMMIT;
  SELECT CONVERT(bit,1) IsSuccess,@AssignmentId AssignmentId;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK; THROW; END CATCH;
END;
GO
/* Extend attachment access to the HOZE for worksheets and consolidation.
   The authenticated user's actual PostId and Mahal are always checked. */
CREATE OR ALTER PROCEDURE [TahghighatV2].[SP_UnifiedAttachmentTargetAccess]
    @TargetEntity varchar(40),
    @TargetRecordId bigint,
    @UserId bigint
AS
BEGIN
    SET NOCOUNT ON;

    IF @UserId IS NULL OR @UserId <= 0
       OR @TargetRecordId IS NULL OR @TargetRecordId <= 0
       OR @TargetEntity IS NULL
       OR @TargetEntity NOT IN
       (
           'RESEARCH_WORKSHEET',
           'RESEARCH_ASSIGNMENT',
           'COUNTY_REPLY_EVENT',
           'PROVINCE_SUMMARY',
           'COUNTY_SUMMARY',
           'HOZE_SUMMARY'
       )
        THROW 54610, N'نوع سند، شناسه یا کاربر معتبر نیست.', 1;

    DECLARE @Mahal int, @PostId int;

    SELECT
        @Mahal = u.Mahal,
        @PostId = u.PostId
    FROM dbo.Users u
    WHERE u.UserId = @UserId
      AND u.IsActive = 1;

    IF @Mahal IS NULL
        THROW 54611, N'کاربر فعال یافت نشد.', 1;

    DECLARE @Access TABLE
    (
        CaseId bigint,
        ShomarehParvandeh bigint,
        PersonId bigint NULL,
        ReferralId bigint,
        AssignmentId bigint NULL,
        RootReferralId bigint,
        CanRead bit,
        CanWrite bit
    );

    /* ---------------------------------------------------------
       Existing target: RESEARCH_WORKSHEET
       --------------------------------------------------------- */
    IF @TargetEntity = 'RESEARCH_WORKSHEET'
    BEGIN
        INSERT @Access
        (
            CaseId, ShomarehParvandeh, PersonId, ReferralId,
            AssignmentId, RootReferralId, CanRead, CanWrite
        )
        SELECT
            c.CaseId,
            c.ShomarehParvandeh,
            personLink.PersonId,
            r.ReferralId,
            a.AssignmentId,
            CASE
                WHEN r.ReceiverLevel = 'SHAHR' THEN h.ParentReferralId
                ELSE COALESCE(r.ParentReferralId, r.ReferralId)
            END,
            CONVERT(bit,
                CASE
                    WHEN
                    (
                        r.ReceiverLevel = 'OSTAN'
                        AND @Mahal = r.ToMahal
                        AND r.IsDeleted = 0
                        AND
                        (
                            EXISTS
                            (
                                SELECT 1
                                FROM TahghighatV2.InvestigatorRegistry i
                                WHERE i.InvestigatorKey = a.InvestigatorId
                                  AND i.AuthUserId = @UserId
                                  AND i.IsActive = 1
                                  AND i.ProvinceCityId = r.ToMahal
                            )
                            OR
                            (
                                @PostId IN (50,51,52)
                                AND EXISTS
                                (
                                    SELECT 1
                                    FROM TahghighatV2.PostActionPermission x
                                    WHERE x.PostId = @PostId
                                      AND x.IsAllowed = 1
                                      AND x.ActionCode IN
                                          ('SAVE_PROVINCE_SUMMARY',
                                           'DIRECTOR_APPROVE',
                                           'ASSIGN_INVESTIGATOR')
                                )
                            )
                        )
                    )
                    OR
                    (
                        r.ReceiverLevel = 'SHAHR'
                        AND EXISTS
                        (
                            SELECT 1
                            FROM TahghighatV2.fn_CountyWorksheetAccess
                                 (w.WorksheetId, @UserId) ca
                            WHERE ca.CanRead = 1
                        )
                    )
                    OR
                    (
                        r.ReceiverLevel = 'HOZE'
                        AND r.IsDeleted = 0
                        AND @Mahal = r.ToMahal
                        AND @PostId IN (60,61)
                    )
                    THEN 1 ELSE 0
                END
            ),
            CONVERT(bit,
                CASE
                    WHEN
                    (
                        r.ReceiverLevel = 'OSTAN'
                        AND @Mahal = r.ToMahal
                        AND r.IsDeleted = 0
                        AND r.IsClosed = 0
                        AND r.StateCode IN
                            ('PROVINCE_WORKING',
                             'PENDING_CHILD_RESULTS',
                             'PROVINCE_RETURNED',
                             'CHILD_WORKING')
                        AND a.StatusCode = 'IN_PROGRESS'
                        AND EXISTS
                        (
                            SELECT 1
                            FROM TahghighatV2.InvestigatorRegistry i
                            WHERE i.InvestigatorKey = a.InvestigatorId
                              AND i.AuthUserId = @UserId
                              AND i.IsActive = 1
                              AND i.ProvinceCityId = r.ToMahal
                        )
                    )
                    OR
                    (
                        r.ReceiverLevel = 'SHAHR'
                        AND (EXISTS
                        (
                            SELECT 1
                            FROM TahghighatV2.fn_CountyWorksheetAccess
                                 (w.WorksheetId, @UserId) ca
                            WHERE ca.CanWrite = 1
                        )
                        OR (r.IsClosed=0 AND r.IsDeleted=0 AND r.StateCode='CHILD_WORKING'
                          AND a.StatusCode='IN_PROGRESS' AND h.IsClosed=0 AND h.IsDeleted=0
                          AND h.StateCode='CHILD_WORKING'
                          AND EXISTS (SELECT 1 FROM TahghighatV2.CountyRepresentative cr
                           WHERE cr.AuthUserId=@UserId AND cr.CountyCityId=r.ToMahal
                            AND cr.HozeCityId=h.ToMahal AND cr.IsActive=1)
                          AND @PostId=70 AND @Mahal=r.ToMahal)
                        )
                    )
                    OR
                    (
                        r.ReceiverLevel = 'HOZE'
                        AND r.IsDeleted = 0 AND r.IsClosed = 0
                        AND r.StateCode = 'CHILD_WORKING'
                        AND a.StatusCode = 'IN_PROGRESS'
                        AND @Mahal = r.ToMahal AND @PostId IN (60,61)
                        AND EXISTS (SELECT 1 FROM TahghighatV2.PostActionPermission ap
                            WHERE ap.PostId=@PostId AND ap.ActionCode='HOZE_OFFICER_SAVE_WORKSHEET' AND ap.IsAllowed=1)
                        AND EXISTS (SELECT 1 FROM TahghighatV2.Referral parent
                            WHERE parent.ReferralId=r.ParentReferralId AND parent.IsDeleted=0
                              AND parent.IsClosed=0 AND parent.StateCode='PENDING_CHILD_RESULTS')
                    )
                    THEN 1 ELSE 0
                END
            )
        FROM TahghighatV2.ResearchWorksheet w
        JOIN TahghighatV2.ResearchAssignment a
            ON a.AssignmentId = w.AssignmentId
        JOIN TahghighatV2.Referral r
            ON r.ReferralId = a.ReferralId
        JOIN TahghighatV2.CaseFile c
            ON c.CaseId = r.CaseId
        LEFT JOIN TahghighatV2.Referral h
            ON h.ReferralId = r.ParentReferralId
           AND r.ReceiverLevel = 'SHAHR'
        OUTER APPLY
        (
            SELECT
                CASE WHEN COUNT_BIG(*) = 1 THEN MAX(p.PersonId) END AS PersonId
            FROM dbo.Person p
            WHERE p.ShomarehParvandeh = c.ShomarehParvandeh
              AND c.ShomarehParvandeh > 0
        ) personLink
        WHERE w.WorksheetId = @TargetRecordId
          AND r.ReceiverLevel IN ('OSTAN','SHAHR','HOZE');
    END

    /* ---------------------------------------------------------
       Existing target: RESEARCH_ASSIGNMENT
       --------------------------------------------------------- */
    ELSE IF @TargetEntity = 'RESEARCH_ASSIGNMENT'
    BEGIN
        INSERT @Access
        (
            CaseId, ShomarehParvandeh, PersonId, ReferralId,
            AssignmentId, RootReferralId, CanRead, CanWrite
        )
        SELECT
            c.CaseId,
            c.ShomarehParvandeh,
            personLink.PersonId,
            r.ReferralId,
            a.AssignmentId,
            CASE
                WHEN r.ReceiverLevel = 'SHAHR' THEN h.ParentReferralId
                ELSE COALESCE(r.ParentReferralId, r.ReferralId)
            END,
            CONVERT(bit,
                CASE
                    WHEN
                    (
                        r.ReceiverLevel = 'OSTAN'
                        AND @Mahal = r.ToMahal
                        AND r.IsDeleted = 0
                        AND
                        (
                            EXISTS
                            (
                                SELECT 1
                                FROM TahghighatV2.InvestigatorRegistry i
                                WHERE i.InvestigatorKey = a.InvestigatorId
                                  AND i.IsActive = 1
                                  AND i.AuthUserId = @UserId
                                  AND i.ProvinceCityId = r.ToMahal
                            )
                            OR
                            (
                                @PostId IN (50,51,52)
                                AND EXISTS
                                (
                                    SELECT 1
                                    FROM TahghighatV2.PostActionPermission x
                                    WHERE x.PostId = @PostId
                                      AND x.IsAllowed = 1
                                      AND x.ActionCode IN
                                          ('DIRECTOR_APPROVE',
                                           'SAVE_PROVINCE_SUMMARY',
                                           'ASSIGN_INVESTIGATOR')
                                )
                            )
                        )
                    )
                    OR
                    (
                        r.ReceiverLevel = 'SHAHR'
                        AND @Mahal = r.ToMahal
                        AND r.IsDeleted = 0
                        AND
                        (
                            EXISTS
                            (
                                SELECT 1
                                FROM TahghighatV2.CountyInvestigator ci
                                JOIN TahghighatV2.InvestigatorRegistry ir
                                  ON ir.InvestigatorKey = ci.InvestigatorKey
                                 AND ir.AuthUserId = @UserId
                                 AND ir.IsActive = 1
                                WHERE ci.CountyCityId = r.ToMahal
                                  AND ci.InvestigatorKey = a.InvestigatorId
                                  AND ci.IsActive = 1
                            )
                            OR EXISTS
                            (
                                SELECT 1
                                FROM TahghighatV2.CountyRepresentative cr
                                WHERE cr.AuthUserId = @UserId
                                  AND cr.CountyCityId = r.ToMahal
                                  AND cr.HozeCityId = h.ToMahal
                                  AND cr.IsActive = 1
                            )
                        )
                    )
                    OR
                    (
                        r.ReceiverLevel = 'HOZE' AND r.IsDeleted = 0
                        AND
                        (
                          (@Mahal = r.ToMahal AND @PostId IN (60,61))
                          OR
                          (@PostId IN (50,51,52,53) AND EXISTS
                           (SELECT 1 FROM TahghighatV2.Referral parent
                            WHERE parent.ReferralId=r.ParentReferralId
                              AND parent.ToMahal=@Mahal AND parent.IsDeleted=0))
                        )
                    )
                    THEN 1 ELSE 0
                END
            ),
            CONVERT(bit,
                CASE
                    WHEN
                        r.IsClosed = 0
                        AND r.IsDeleted = 0
                        AND a.StatusCode = 'IN_PROGRESS'
                        AND
                        (
                            (
                                r.ReceiverLevel = 'OSTAN'
                                AND @Mahal = r.ToMahal
                                AND r.StateCode IN
                                    ('PROVINCE_WORKING',
                                     'PROVINCE_RETURNED',
                                     'PENDING_CHILD_RESULTS',
                                     'CHILD_WORKING')
                                AND EXISTS
                                (
                                    SELECT 1
                                    FROM TahghighatV2.InvestigatorRegistry ir
                                    WHERE ir.InvestigatorKey = a.InvestigatorId
                                      AND ir.IsActive = 1
                                      AND ir.AuthUserId = @UserId
                                      AND ir.ProvinceCityId = r.ToMahal
                                )
                            )
                            OR
                            (
                                r.ReceiverLevel = 'SHAHR'
                                AND @Mahal = r.ToMahal
                                AND r.StateCode = 'CHILD_WORKING'
                                AND h.StateCode = 'CHILD_WORKING'
                                AND h.IsClosed = 0
                                AND h.IsDeleted = 0
                                AND EXISTS
                                (
                                    SELECT 1
                                    FROM TahghighatV2.CountyInvestigator ci
                                    JOIN TahghighatV2.InvestigatorRegistry ir
                                      ON ir.InvestigatorKey = ci.InvestigatorKey
                                     AND ir.AuthUserId = @UserId
                                     AND ir.IsActive = 1
                                    WHERE ci.CountyCityId = r.ToMahal
                                      AND ci.InvestigatorKey = a.InvestigatorId
                                      AND ci.IsActive = 1
                                )
                                OR (@PostId=70 AND @Mahal=r.ToMahal
                                 AND EXISTS (SELECT 1 FROM TahghighatV2.CountyRepresentative cr
                                  WHERE cr.AuthUserId=@UserId AND cr.CountyCityId=r.ToMahal
                                   AND cr.HozeCityId=h.ToMahal AND cr.IsActive=1))
                            )
                            OR
                            (
                                r.ReceiverLevel = 'HOZE'
                                AND @Mahal = r.ToMahal AND @PostId IN (60,61)
                                AND r.StateCode = 'CHILD_WORKING'
                                AND EXISTS (SELECT 1 FROM TahghighatV2.Referral parent
                                   WHERE parent.ReferralId=r.ParentReferralId
                                   AND parent.IsClosed=0 AND parent.IsDeleted=0
                                   AND parent.StateCode='PENDING_CHILD_RESULTS')
                                AND EXISTS(SELECT 1 FROM TahghighatV2.PostActionPermission ap
                                   WHERE ap.PostId=@PostId
                                   AND ap.ActionCode='HOZE_OFFICER_SAVE_WORKSHEET'
                                   AND ap.IsAllowed=1)
                            )
                        )
                    THEN 1 ELSE 0
                END
            )
        FROM TahghighatV2.ResearchAssignment a
        JOIN TahghighatV2.Referral r
            ON r.ReferralId = a.ReferralId
        JOIN TahghighatV2.CaseFile c
            ON c.CaseId = r.CaseId
        LEFT JOIN TahghighatV2.Referral h
            ON h.ReferralId = r.ParentReferralId
           AND r.ReceiverLevel = 'SHAHR'
        OUTER APPLY
        (
            SELECT
                CASE WHEN COUNT_BIG(*) = 1 THEN MAX(p.PersonId) END AS PersonId
            FROM dbo.Person p
            WHERE p.ShomarehParvandeh = c.ShomarehParvandeh
              AND c.ShomarehParvandeh > 0
        ) personLink
        WHERE a.AssignmentId = @TargetRecordId
          AND r.ReceiverLevel IN ('OSTAN','SHAHR','HOZE');
    END

    /* ---------------------------------------------------------
       Existing target: COUNTY_REPLY_EVENT
       --------------------------------------------------------- */
    ELSE IF @TargetEntity = 'COUNTY_REPLY_EVENT'
    BEGIN
        INSERT @Access
        (
            CaseId, ShomarehParvandeh, PersonId, ReferralId,
            AssignmentId, RootReferralId, CanRead, CanWrite
        )
        SELECT
            c.CaseId,
            c.ShomarehParvandeh,
            personLink.PersonId,
            r.ReferralId,
            NULL,
            h.ParentReferralId,
            CONVERT(bit,
                CASE
                    WHEN r.IsDeleted = 0
                     AND
                     (
                         (
                             @Mahal = r.ToMahal
                             AND EXISTS
                             (
                                 SELECT 1
                                 FROM TahghighatV2.CountyRepresentative cr
                                 WHERE cr.AuthUserId = @UserId
                                   AND cr.CountyCityId = r.ToMahal
                                   AND cr.HozeCityId = h.ToMahal
                                   AND cr.IsActive = 1
                             )
                         )
                         OR
                         (
                             @PostId = 61
                             AND @Mahal = h.ToMahal
                             AND EXISTS
                             (
                                 SELECT 1
                                 FROM TahghighatV2.PostActionPermission ap
                                 WHERE ap.PostId = 61
                                   AND ap.ActionCode = 'HOZE_REFER_COUNTY'
                                   AND ap.IsAllowed = 1
                             )
                         )
                         OR
                         (
                             @PostId IN (50,51,52)
                             AND @Mahal = root.ToMahal
                             AND EXISTS
                             (
                                 SELECT 1
                                 FROM TahghighatV2.PostActionPermission ap
                                 WHERE ap.PostId = @PostId
                                   AND ap.IsAllowed = 1
                                   AND ap.ActionCode IN
                                       ('DIRECTOR_APPROVE',
                                        'SAVE_PROVINCE_SUMMARY')
                             )
                         )
                     )
                    THEN 1 ELSE 0
                END
            ),
            CONVERT(bit,
                CASE
                    WHEN r.IsDeleted = 0
                     AND e.ActionCode = 'COUNTY_REPLY'
                     AND h.IsClosed = 0
                     AND h.IsDeleted = 0
                     AND @Mahal = r.ToMahal
                     AND EXISTS
                     (
                         SELECT 1
                         FROM TahghighatV2.CountyRepresentative cr
                         WHERE cr.AuthUserId = @UserId
                           AND cr.CountyCityId = r.ToMahal
                           AND cr.HozeCityId = h.ToMahal
                           AND cr.IsActive = 1
                     )
                    THEN 1 ELSE 0
                END
            )
        FROM TahghighatV2.WorkflowEvent e
        JOIN TahghighatV2.Referral r
            ON r.ReferralId = e.ReferralId
           AND r.ReceiverLevel = 'SHAHR'
        JOIN TahghighatV2.Referral h
            ON h.ReferralId = r.ParentReferralId
           AND h.ReceiverLevel = 'HOZE'
        JOIN TahghighatV2.Referral root
            ON root.ReferralId = h.ParentReferralId
        JOIN TahghighatV2.CaseFile c
            ON c.CaseId = r.CaseId
        OUTER APPLY
        (
            SELECT
                CASE WHEN COUNT_BIG(*) = 1 THEN MAX(p.PersonId) END AS PersonId
            FROM dbo.Person p
            WHERE p.ShomarehParvandeh = c.ShomarehParvandeh
              AND c.ShomarehParvandeh > 0
        ) personLink
        WHERE e.EventId = @TargetRecordId
          AND e.ActionCode = 'COUNTY_REPLY';
    END

    /* ---------------------------------------------------------
       Existing target: PROVINCE_SUMMARY
       --------------------------------------------------------- */
    ELSE IF @TargetEntity = 'PROVINCE_SUMMARY'
    BEGIN
        INSERT @Access
        (
            CaseId, ShomarehParvandeh, PersonId, ReferralId,
            AssignmentId, RootReferralId, CanRead, CanWrite
        )
        SELECT
            c.CaseId,
            c.ShomarehParvandeh,
            personLink.PersonId,
            r.ReferralId,
            NULL,
            COALESCE(r.ParentReferralId, r.ReferralId),
            CONVERT(bit,
                CASE
                    WHEN r.IsDeleted = 0
                     AND @Mahal = r.ToMahal
                     AND @PostId IN (50,51,52)
                     AND EXISTS
                     (
                         SELECT 1
                         FROM TahghighatV2.PostActionPermission ap
                         WHERE ap.PostId = @PostId
                           AND ap.IsAllowed = 1
                           AND ap.ActionCode IN
                               ('DIRECTOR_APPROVE','SAVE_PROVINCE_SUMMARY')
                     )
                    THEN 1 ELSE 0
                END
            ),
            CONVERT(bit,
                CASE
                    WHEN r.IsDeleted = 0
                     AND r.IsClosed = 0
                     AND @Mahal = r.ToMahal
                     AND r.StateCode IN ('PROVINCE_WORKING','PROVINCE_RETURNED')
                     AND @PostId IN (51,52)
                     AND EXISTS
                     (
                         SELECT 1
                         FROM TahghighatV2.PostActionPermission ap
                         WHERE ap.PostId = @PostId
                           AND ap.IsAllowed = 1
                           AND ap.ActionCode = 'SAVE_PROVINCE_SUMMARY'
                     )
                    THEN 1 ELSE 0
                END
            )
        FROM TahghighatV2.ProvinceSummary s
        JOIN TahghighatV2.Referral r
            ON r.ReferralId = s.ReferralId
           AND r.ReceiverLevel = 'OSTAN'
        JOIN TahghighatV2.CaseFile c
            ON c.CaseId = r.CaseId
        OUTER APPLY
        (
            SELECT
                CASE WHEN COUNT_BIG(*) = 1 THEN MAX(p.PersonId) END AS PersonId
            FROM dbo.Person p
            WHERE p.ShomarehParvandeh = c.ShomarehParvandeh
              AND c.ShomarehParvandeh > 0
        ) personLink
        WHERE s.SummaryId = @TargetRecordId;
    END

    /* ---------------------------------------------------------
       New target: COUNTY_SUMMARY
       TargetRecordId is CountySummary.SummaryId.
       Read access mirrors SP_GetCountyConsolidation and
       SP_GetHozeConsolidation.
       Write access mirrors SP_SaveCountySummary.
       --------------------------------------------------------- */
    ELSE IF @TargetEntity = 'COUNTY_SUMMARY'
    BEGIN
        INSERT @Access
        (
            CaseId, ShomarehParvandeh, PersonId, ReferralId,
            AssignmentId, RootReferralId, CanRead, CanWrite
        )
        SELECT
            cf.CaseId,
            cf.ShomarehParvandeh,
            personLink.PersonId,
            county.ReferralId,
            NULL,
            root.ReferralId,
            CONVERT(bit,
                CASE
                    WHEN county.IsDeleted = 0
                     AND
                     (
                         (
                             @Mahal = county.ToMahal
                             AND EXISTS
                             (
                                 SELECT 1
                                 FROM TahghighatV2.CountyRepresentative cr
                                 WHERE cr.AuthUserId = @UserId
                                   AND cr.CountyCityId = county.ToMahal
                                   AND cr.HozeCityId = hoze.ToMahal
                                   AND cr.IsActive = 1
                             )
                         )
                         OR
                         (
                             @PostId = 61
                             AND @Mahal = hoze.ToMahal
                             AND hoze.IsDeleted = 0
                             AND EXISTS
                             (
                                 SELECT 1
                                 FROM TahghighatV2.PostActionPermission ap
                                 WHERE ap.PostId = 61
                                   AND ap.ActionCode = 'CHILD_REPLY'
                                   AND ap.IsAllowed = 1
                             )
                         )
                     )
                    THEN 1 ELSE 0
                END
            ),
            CONVERT(bit,
                CASE
                    WHEN county.IsDeleted = 0
                     AND county.IsClosed = 0
                     AND county.StateCode = 'CHILD_WORKING'
                     AND hoze.IsDeleted = 0
                     AND hoze.IsClosed = 0
                     AND hoze.StateCode = 'CHILD_WORKING'
                     AND root.IsDeleted = 0
                     AND root.IsClosed = 0
                     AND root.StateCode = 'PENDING_CHILD_RESULTS'
                     AND @Mahal = county.ToMahal
                     AND EXISTS
                     (
                         SELECT 1
                         FROM TahghighatV2.CountyRepresentative cr
                         WHERE cr.AuthUserId = @UserId
                           AND cr.CountyCityId = county.ToMahal
                           AND cr.HozeCityId = hoze.ToMahal
                           AND cr.IsActive = 1
                     )
                    THEN 1 ELSE 0
                END
            )
        FROM TahghighatV2.CountySummary cs
        JOIN TahghighatV2.Referral county
            ON county.ReferralId = cs.ReferralId
           AND county.ReceiverLevel = 'SHAHR'
        JOIN TahghighatV2.Referral hoze
            ON hoze.ReferralId = county.ParentReferralId
           AND hoze.ReceiverLevel = 'HOZE'
        JOIN TahghighatV2.Referral root
            ON root.ReferralId = hoze.ParentReferralId
        JOIN TahghighatV2.CaseFile cf
            ON cf.CaseId = county.CaseId
        OUTER APPLY
        (
            SELECT
                CASE WHEN COUNT_BIG(*) = 1 THEN MAX(p.PersonId) END AS PersonId
            FROM dbo.Person p
            WHERE p.ShomarehParvandeh = cf.ShomarehParvandeh
              AND cf.ShomarehParvandeh > 0
        ) personLink
        WHERE cs.SummaryId = @TargetRecordId;
    END

    /* ---------------------------------------------------------
       New target: HOZE_SUMMARY
       TargetRecordId is HozeSummary.SummaryId.
       Read access mirrors SP_GetHozeConsolidation and
       SP_GetProvinceHozeConsolidation.
       Write access mirrors SP_SaveHozeSummary.
       --------------------------------------------------------- */
    ELSE IF @TargetEntity = 'HOZE_SUMMARY'
    BEGIN
        INSERT @Access
        (
            CaseId, ShomarehParvandeh, PersonId, ReferralId,
            AssignmentId, RootReferralId, CanRead, CanWrite
        )
        SELECT
            cf.CaseId,
            cf.ShomarehParvandeh,
            personLink.PersonId,
            hoze.ReferralId,
            NULL,
            root.ReferralId,
            CONVERT(bit,
                CASE
                    WHEN hoze.IsDeleted = 0
                     AND
                     (
                         (
                             @PostId IN (60,61)
                             AND @Mahal = hoze.ToMahal
                             AND EXISTS
                             (
                                 SELECT 1
                                 FROM TahghighatV2.PostActionPermission ap
                                 WHERE ap.PostId = @PostId
                                   AND ap.ActionCode = 'HOZE_SAVE_SUMMARY'
                                   AND ap.IsAllowed = 1
                             )
                         )
                         OR
                         (
                             @PostId IN (51,52)
                             AND root.ParentReferralId IS NULL
                             AND root.ReceiverLevel = 'OSTAN'
                             AND root.IsDeleted = 0
                             AND @Mahal = root.ToMahal
                         )
                     )
                    THEN 1 ELSE 0
                END
            ),
            CONVERT(bit,
                CASE
                    WHEN @PostId IN (60,61)
                     AND @Mahal = hoze.ToMahal
                     AND hoze.ReceiverLevel = 'HOZE'
                     AND hoze.StateCode = 'CHILD_WORKING'
                     AND hoze.IsClosed = 0
                     AND hoze.IsDeleted = 0
                     AND root.StateCode = 'PENDING_CHILD_RESULTS'
                     AND root.IsClosed = 0
                     AND root.IsDeleted = 0
                     AND EXISTS
                     (
                         SELECT 1
                         FROM TahghighatV2.PostActionPermission ap
                         WHERE ap.PostId = @PostId
                           AND ap.ActionCode = 'HOZE_SAVE_SUMMARY'
                           AND ap.IsAllowed = 1
                     )
                    THEN 1 ELSE 0
                END
            )
        FROM TahghighatV2.HozeSummary hs
        JOIN TahghighatV2.Referral hoze
            ON hoze.ReferralId = hs.ReferralId
           AND hoze.ReceiverLevel = 'HOZE'
        JOIN TahghighatV2.Referral root
            ON root.ReferralId = hoze.ParentReferralId
        JOIN TahghighatV2.CaseFile cf
            ON cf.CaseId = root.CaseId
        OUTER APPLY
        (
            SELECT
                CASE WHEN COUNT_BIG(*) = 1 THEN MAX(p.PersonId) END AS PersonId
            FROM dbo.Person p
            WHERE p.ShomarehParvandeh = cf.ShomarehParvandeh
              AND cf.ShomarehParvandeh > 0
        ) personLink
        WHERE hs.SummaryId = @TargetRecordId;
    END;

    SELECT
        CaseId,
        ShomarehParvandeh,
        PersonId,
        ReferralId,
        AssignmentId,
        RootReferralId,
        CanRead,
        CanWrite
    FROM @Access;
END;

GO


/* Phase 105: reuse the exact structured worksheet data table used by Province. */
IF OBJECT_ID(N'TahghighatV2.ResearchWorksheetDetails',N'U') IS NULL
BEGIN
 CREATE TABLE TahghighatV2.ResearchWorksheetDetails(
  WorksheetId bigint NOT NULL CONSTRAINT PK_MRV2_ResearchWorksheetDetails PRIMARY KEY,
  TahghighType int NOT NULL, TypeMahalTahghigh int NOT NULL,
  AzSal int NOT NULL, TaSal int NOT NULL,CodeManba bigint NOT NULL,
  NahveAshnai nvarchar(200) NOT NULL,NoeParvandeh int NULL,NahveBazkhani int NULL,
  NameSazman nvarchar(300) NULL,NameShahr nvarchar(300) NULL,
  PeyvastCount int NULL,Description nvarchar(max) NULL,
  LastEditedByUserId bigint NULL,LastEditedAtUtc datetime2(3) NULL,
  CONSTRAINT FK_MRV2_ResearchWorksheetDetails_Worksheet FOREIGN KEY(WorksheetId)
   REFERENCES TahghighatV2.ResearchWorksheet(WorksheetId),
  CONSTRAINT CK_MRV2_WorksheetYears CHECK(AzSal BETWEEN 1320 AND 1500 AND TaSal BETWEEN AzSal AND 1500),
  CONSTRAINT CK_MRV2_WorksheetPeyvastCount CHECK(PeyvastCount IS NULL OR PeyvastCount BETWEEN 0 AND 9999)
 );
END;
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_GetHozeInvestigatorWorksheetDetails
 @AssignmentId bigint,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 IF NOT EXISTS(
  SELECT 1 FROM TahghighatV2.ResearchAssignment a
  JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId AND r.ReceiverLevel='HOZE' AND r.IsDeleted=0
  JOIN dbo.Users u ON u.UserId=@UserId AND u.IsActive=1 AND u.PostId IN(60,61) AND u.Mahal=r.ToMahal
  WHERE a.AssignmentId=@AssignmentId
 ) THROW 54970,N'مجوز مشاهده کاربرگ محقق این حوزه وجود ندارد.',1;
 SELECT w.WorksheetId,w.AssignmentId,w.ReportText,w.CreatedAtUtc,w.CreatedByUserId,
        d.TahghighType,d.TypeMahalTahghigh,d.CodeManba,d.NahveAshnai,
        d.AzSal,d.TaSal,d.NoeParvandeh,d.NahveBazkhani,d.NameSazman,
        d.NameShahr,d.PeyvastCount,d.Description,
        t.NameFarsi TahghighTypeName, m.NameFarsi TypeMahalTahghighName,
        np.NameFarsi NoeParvandehName,nb.NameFarsi NahveBazkhaniName,
        LTRIM(RTRIM(CONCAT(ISNULL(src.FirstName,N''),N' ',ISNULL(src.LastName,N'')))) ManbaName
 FROM TahghighatV2.ResearchWorksheet w
 LEFT JOIN TahghighatV2.ResearchWorksheetDetails d ON d.WorksheetId=w.WorksheetId
 OUTER APPLY(SELECT TOP(1) x.NameFarsi FROM dbo.DFN x WHERE x.PID=102 AND x.Value=d.TahghighType) t
 OUTER APPLY(SELECT TOP(1) x.NameFarsi FROM dbo.DFN x WHERE x.PID=111 AND x.Value=d.TypeMahalTahghigh) m
 OUTER APPLY(SELECT TOP(1) x.NameFarsi FROM dbo.DFN x WHERE x.PID=113 AND x.Value=d.NoeParvandeh) np
 OUTER APPLY(SELECT TOP(1) x.NameFarsi FROM dbo.DFN x WHERE x.PID=114 AND x.Value=d.NahveBazkhani) nb
 OUTER APPLY(SELECT TOP(1) FirstName,LastName FROM dbo.Person WHERE ShomarehParvandeh=d.CodeManba ORDER BY PersonId) src
 WHERE w.AssignmentId=@AssignmentId ORDER BY w.WorksheetId DESC;
END;
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_SaveHozeInvestigatorWorksheetDetails
 @AssignmentId bigint,@UserId bigint,@WorksheetId bigint=NULL,
 @TahghighType int,@TypeMahalTahghigh int,@CodeManba bigint=NULL,
 @AzSal int,@TaSal int,@NahveAshnai nvarchar(200),
 @NoeParvandeh int=NULL,@NahveBazkhani int=NULL,
 @NameSazman nvarchar(300)=NULL,@NameShahr nvarchar(300)=NULL,
 @PeyvastCount int=NULL,@Description nvarchar(max)=NULL
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 SET @NahveAshnai=NULLIF(LTRIM(RTRIM(@NahveAshnai)),N'');
 SET @Description=NULLIF(LTRIM(RTRIM(@Description)),N'');
 IF ISNULL(@AssignmentId,0)<=0 OR ISNULL(@UserId,0)<=0
   OR ISNULL(@TahghighType,0)<=0 OR ISNULL(@TypeMahalTahghigh,0)<=0
   OR @NahveAshnai IS NULL OR LEN(@NahveAshnai)>200
   OR @AzSal IS NULL OR @TaSal IS NULL
   OR @AzSal NOT BETWEEN 1320 AND COALESCE(TRY_CONVERT(int,LEFT(dbo.FarsiDateTimeNow(),4)),1500)
   OR @TaSal NOT BETWEEN @AzSal AND COALESCE(TRY_CONVERT(int,LEFT(dbo.FarsiDateTimeNow(),4)),1500)
   OR LEN(ISNULL(@Description,N''))>12000
   OR (@PeyvastCount IS NOT NULL AND @PeyvastCount NOT BETWEEN 0 AND 9999)
   OR (@WorksheetId IS NOT NULL AND @WorksheetId<=0)
  THROW 54971,N'مقادیر کاربرگ یا مدت آشنایی معتبر نیست.',1;
 IF NOT EXISTS(SELECT 1 FROM dbo.DFN WHERE PID=102 AND Value=@TahghighType)
  OR NOT EXISTS(SELECT 1 FROM dbo.DFN WHERE PID=111 AND Value=@TypeMahalTahghigh)
  THROW 54972,N'نوع یا محل تحقیق معتبر نیست.',1;
 IF @TahghighType=2
 BEGIN
  IF ISNULL(@NoeParvandeh,0)<=0 OR ISNULL(@NahveBazkhani,0)<=0
    OR NOT EXISTS(SELECT 1 FROM dbo.DFN WHERE PID=113 AND Value=@NoeParvandeh)
    OR NOT EXISTS(SELECT 1 FROM dbo.DFN WHERE PID=114 AND Value=@NahveBazkhani)
    THROW 54973,N'نوع پرونده و نحوه بازخوانی را انتخاب کنید.',1;
  SET @CodeManba=0;
 END
 ELSE
 BEGIN
  IF ISNULL(@CodeManba,0)<=0 THROW 54974,N'انتخاب منبع تحقیق الزامی است.',1;
  SET @NoeParvandeh=NULL;SET @NahveBazkhani=NULL;
  SET @NameSazman=NULL;SET @NameShahr=NULL;SET @PeyvastCount=NULL;
 END;
 DECLARE @Hoze bigint,@Root bigint,@OldStatus varchar(20),@Lock int,@ResultId bigint,
         @ActorPost int,@ActorMahal int,@IsEdit bit=0;
 SELECT @ActorPost=u.PostId,@ActorMahal=u.Mahal FROM dbo.Users u WHERE u.UserId=@UserId AND u.IsActive=1;
 IF ISNULL(@ActorPost,0) NOT IN(60,61) OR NOT EXISTS(
  SELECT 1 FROM TahghighatV2.PostActionPermission p WHERE p.PostId=@ActorPost
  AND p.ActionCode='HOZE_OFFICER_SAVE_WORKSHEET' AND p.IsAllowed=1)
  THROW 54975,N'کاربر مجاز به ثبت کاربرگ محقق حوزه نیست.',1;
 SELECT @Hoze=r.ReferralId,@Root=r.ParentReferralId
 FROM TahghighatV2.ResearchAssignment a
 JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId AND r.ReceiverLevel='HOZE'
 WHERE a.AssignmentId=@AssignmentId AND r.ToMahal=@ActorMahal AND r.IsDeleted=0 AND r.IsClosed=0;
 IF @Root IS NULL THROW 54976,N'انتساب محقق برای این حوزه معتبر نیست.',1;
 BEGIN TRY
 BEGIN TRANSACTION;
 DECLARE @LockKey nvarchar(200)=N'MRV2:REF:'+CONVERT(nvarchar(20),@Root);
 EXEC @Lock=sys.sp_getapplock @Resource=@LockKey,@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @Lock<0 THROW 54977,N'پرونده در حال پردازش است.',1;
 SELECT @OldStatus=a.StatusCode FROM TahghighatV2.ResearchAssignment a WITH(UPDLOCK,HOLDLOCK)
 JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId
 JOIN TahghighatV2.Referral p ON p.ReferralId=r.ParentReferralId
 WHERE a.AssignmentId=@AssignmentId AND r.ReferralId=@Hoze
 AND r.IsDeleted=0 AND r.IsClosed=0 AND r.StateCode='CHILD_WORKING'
 AND p.ReferralId=@Root AND p.IsDeleted=0 AND p.IsClosed=0 AND p.StateCode='PENDING_CHILD_RESULTS';
 IF @OldStatus NOT IN('PENDING','IN_PROGRESS') OR @OldStatus IS NULL
  THROW 54978,N'ثبت کاربرگ برای وضعیت فعلی پرونده یا انتساب مجاز نیست.',1;
 SET @ResultId=@WorksheetId;
 IF @WorksheetId IS NOT NULL
 BEGIN
  IF NOT EXISTS(SELECT 1 FROM TahghighatV2.ResearchWorksheet w WITH(UPDLOCK,HOLDLOCK)
    WHERE w.WorksheetId=@WorksheetId AND w.AssignmentId=@AssignmentId)
   THROW 54979,N'کاربرگ قابل ویرایش در این انتساب یافت نشد.',1;
  SET @IsEdit=1;
  UPDATE TahghighatV2.ResearchWorksheet
   SET ReportText=COALESCE(@Description, @NahveAshnai),UpdatedAtUtc=SYSUTCDATETIME()
   WHERE WorksheetId=@WorksheetId AND AssignmentId=@AssignmentId;
 END
 ELSE
 BEGIN
  INSERT TahghighatV2.ResearchWorksheet(AssignmentId,ReportText,CreatedByUserId)
    VALUES(@AssignmentId,COALESCE(@Description,@NahveAshnai),@UserId);
  SET @ResultId=CONVERT(bigint,SCOPE_IDENTITY());
 END;
 UPDATE TahghighatV2.ResearchWorksheetDetails
 SET TahghighType=@TahghighType,TypeMahalTahghigh=@TypeMahalTahghigh,
  CodeManba=@CodeManba,NahveAshnai=@NahveAshnai,AzSal=@AzSal,TaSal=@TaSal,
  NoeParvandeh=@NoeParvandeh,NahveBazkhani=@NahveBazkhani,
  NameSazman=@NameSazman,NameShahr=@NameShahr,PeyvastCount=@PeyvastCount,
  Description=@Description,LastEditedByUserId=@UserId,LastEditedAtUtc=SYSUTCDATETIME()
 WHERE WorksheetId=@ResultId;
 IF @@ROWCOUNT=0
  INSERT TahghighatV2.ResearchWorksheetDetails
   (WorksheetId,TahghighType,TypeMahalTahghigh,CodeManba,NahveAshnai,AzSal,TaSal,
    NoeParvandeh,NahveBazkhani,NameSazman,NameShahr,PeyvastCount,Description,LastEditedByUserId)
  VALUES(@ResultId,@TahghighType,@TypeMahalTahghigh,@CodeManba,@NahveAshnai,@AzSal,@TaSal,
    @NoeParvandeh,@NahveBazkhani,@NameSazman,@NameShahr,@PeyvastCount,@Description,@UserId);
 IF @OldStatus='PENDING'
 BEGIN
  UPDATE TahghighatV2.ResearchAssignment SET StatusCode='IN_PROGRESS' WHERE AssignmentId=@AssignmentId;
  INSERT TahghighatV2.ResearchAssignmentEvent(AssignmentId,ActionCode,BeforeStatus,AfterStatus,Description,ActorUserId)
  VALUES(@AssignmentId,'HOZE_OFFICER_START','PENDING','IN_PROGRESS',N'شروع تحقیق با کاربرگ رسمی',@UserId);
 END;
 INSERT TahghighatV2.ResearchAssignmentEvent(AssignmentId,ActionCode,BeforeStatus,AfterStatus,Description,ActorUserId)
 VALUES(@AssignmentId,'HOZE_OFFICER_SAVE_WORKSHEET','IN_PROGRESS','IN_PROGRESS',
  CASE WHEN @IsEdit=1 THEN N'ویرایش کاربرگ رسمی حوزه ' ELSE N'ثبت کاربرگ رسمی حوزه ' END+CONVERT(nvarchar(20),@ResultId),@UserId);
 INSERT TahghighatV2.WorkflowEvent(ReferralId,ActionCode,PreviousStateCode,NewStateCode,Description,ActorUserId)
 VALUES(@Hoze,'HOZE_OFFICER_SAVE_WORKSHEET','CHILD_WORKING','CHILD_WORKING',
  CASE WHEN @IsEdit=1 THEN N'ویرایش کاربرگ محقق ' ELSE N'ثبت کاربرگ محقق ' END+CONVERT(nvarchar(20),@ResultId),@UserId);
 COMMIT;
 SELECT CONVERT(bit,1) IsSuccess,@ResultId WorksheetId;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK; THROW; END CATCH;
END;
GO


/* Phase 107: the HOZE investigator uses the exact province report + image gallery.
   These endpoints are always scoped to the HOZE assignment and current user.
   Summary SAVE does not complete an assignment: completion is a separate,
   audited action after the official image is attached. */
CREATE OR ALTER PROCEDURE TahghighatV2.SP_GetHozeInvestigatorSummary
 @AssignmentId bigint, @UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @Mahal int,@Post int;
 SELECT @Mahal=u.Mahal,@Post=u.PostId FROM dbo.Users u
  WHERE u.UserId=@UserId AND u.IsActive=1;
 IF @AssignmentId IS NULL OR @AssignmentId<=0 OR @Post NOT IN (60,61)
  OR NOT EXISTS(SELECT 1 FROM dbo.Citys c WHERE c.CityId=@Mahal AND c.IsHoze=1 AND c.IsActive=1)
  THROW 55001,N'دسترسی به گزارش محقق حوزه وجود ندارد.',1;
 SELECT a.Summary AS SummaryText,CONVERT(bit,CASE
   WHEN r.IsClosed=0 AND r.IsDeleted=0 AND r.StateCode='CHILD_WORKING'
    AND a.StatusCode='IN_PROGRESS'
    AND EXISTS(SELECT 1 FROM TahghighatV2.Referral parent
       WHERE parent.ReferralId=r.ParentReferralId AND parent.IsClosed=0
        AND parent.IsDeleted=0 AND parent.StateCode='PENDING_CHILD_RESULTS')
    AND EXISTS(SELECT 1 FROM TahghighatV2.PostActionPermission p
       WHERE p.PostId=@Post AND p.ActionCode='HOZE_OFFICER_SAVE_WORKSHEET' AND p.IsAllowed=1)
   THEN 1 ELSE 0 END) CanWrite
 FROM TahghighatV2.ResearchAssignment a
 JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId
 WHERE a.AssignmentId=@AssignmentId AND r.ReceiverLevel='HOZE'
   AND r.ToMahal=@Mahal AND r.IsDeleted=0;
 IF @@ROWCOUNT<>1 THROW 55002,N'انتساب محقق در حوزه شما یافت نشد.',1;
END;
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_SaveHozeInvestigatorSummary
 @AssignmentId bigint,@SummaryText nvarchar(max),@UserId bigint
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 SET @SummaryText=LTRIM(RTRIM(ISNULL(@SummaryText,N'')));
 IF @AssignmentId IS NULL OR @AssignmentId<=0 OR @UserId IS NULL OR @UserId<=0
   OR LEN(@SummaryText)<50 OR LEN(@SummaryText)>12000
   THROW 55003,N'متن جمع‌بندی باید بین ۵۰ تا ۱۲۰۰۰ نویسه باشد.',1;
 DECLARE @Mahal int,@Post int,@Hoze bigint,@Root bigint,@Status varchar(20),@Lock int;
 SELECT @Mahal=u.Mahal,@Post=u.PostId FROM dbo.Users u WHERE u.UserId=@UserId AND u.IsActive=1;
 IF @Post NOT IN(60,61)
   OR NOT EXISTS(SELECT 1 FROM dbo.Citys c WHERE c.CityId=@Mahal AND c.IsHoze=1 AND c.IsActive=1)
   OR NOT EXISTS(SELECT 1 FROM TahghighatV2.PostActionPermission ap WHERE ap.PostId=@Post
     AND ap.ActionCode='HOZE_OFFICER_SAVE_WORKSHEET' AND ap.IsAllowed=1)
   THROW 55004,N'مجوز ثبت جمع‌بندی محقق حوزه وجود ندارد.',1;
 SELECT @Hoze=r.ReferralId,@Root=r.ParentReferralId
 FROM TahghighatV2.ResearchAssignment a
 JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId AND r.ReceiverLevel='HOZE'
 WHERE a.AssignmentId=@AssignmentId AND r.ToMahal=@Mahal AND r.IsDeleted=0;
 IF @Root IS NULL THROW 55005,N'انتساب محقق مربوط به این حوزه نیست.',1;
 BEGIN TRY
  BEGIN TRANSACTION;
  DECLARE @Resource nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(20),@Root);
  EXEC @Lock=sys.sp_getapplock @Resource=@Resource,@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
  IF @Lock<0 THROW 55006,N'پرونده در حال پردازش است.',1;
  SELECT @Status=a.StatusCode FROM TahghighatV2.ResearchAssignment a WITH(UPDLOCK,HOLDLOCK)
  JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId
  JOIN TahghighatV2.Referral parent ON parent.ReferralId=r.ParentReferralId
  WHERE a.AssignmentId=@AssignmentId AND r.ReferralId=@Hoze AND r.ReceiverLevel='HOZE'
   AND r.ToMahal=@Mahal AND r.IsDeleted=0 AND r.IsClosed=0 AND r.StateCode='CHILD_WORKING'
   AND parent.ReferralId=@Root AND parent.IsDeleted=0 AND parent.IsClosed=0 AND parent.StateCode='PENDING_CHILD_RESULTS';
  IF @Status IS NULL OR @Status<>'IN_PROGRESS'
     THROW 55007,N'انتساب در وضعیت قابل ثبت جمع‌بندی نیست.',1;
  IF NOT EXISTS(SELECT 1 FROM TahghighatV2.ResearchWorksheet w WITH(HOLDLOCK) WHERE w.AssignmentId=@AssignmentId)
     THROW 55008,N'ابتدا دست‌کم یک کاربرگ ثبت کنید.',1;
  UPDATE TahghighatV2.ResearchAssignment SET Summary=@SummaryText WHERE AssignmentId=@AssignmentId AND StatusCode='IN_PROGRESS';
  IF @@ROWCOUNT<>1 THROW 55009,N'وضعیت انتساب تغییر کرده است.',1;
  INSERT TahghighatV2.ResearchAssignmentEvent(AssignmentId,ActionCode,BeforeStatus,AfterStatus,Description,ActorUserId)
   VALUES(@AssignmentId,'HOZE_OFFICER_SAVE_SUMMARY','IN_PROGRESS','IN_PROGRESS',N'ثبت و ویرایش فرم رسمی جمع‌بندی محقق',@UserId);
  COMMIT;
  SELECT CONVERT(bit,1) IsSuccess,@AssignmentId AssignmentId;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK; THROW; END CATCH;
END;
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_GetHozeInvestigatorReport
 @AssignmentId bigint,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @Mahal int,@Post int;
 SELECT @Mahal=u.Mahal,@Post=u.PostId FROM dbo.Users u WHERE u.UserId=@UserId AND u.IsActive=1;
 IF @Post NOT IN(60,61) OR NOT EXISTS(SELECT 1 FROM dbo.Citys c
    WHERE c.CityId=@Mahal AND c.IsHoze=1 AND c.IsActive=1)
  THROW 55010,N'مجوز مشاهده فرم محقق حوزه وجود ندارد.',1;
 IF NOT EXISTS(SELECT 1 FROM TahghighatV2.ResearchAssignment ra
   JOIN TahghighatV2.Referral r ON r.ReferralId=ra.ReferralId
   WHERE ra.AssignmentId=@AssignmentId AND r.ReceiverLevel='HOZE' AND r.ToMahal=@Mahal AND r.IsDeleted=0)
  THROW 55011,N'انتساب محقق در شهرستان شما یافت نشد.',1;
    SELECT
        cf.ShomarehParvandeh,
        cf.CodeEntekhabat,
        cf.CodeHozeh,
        province.Name AS NameOstan,
        hoze.NameHozeh,
        a.FirstName,
        a.LastName,
        a.NamePedar,
        a.NameMostar,
        a.CodeMelli,
        /* SalTavalod is NOT a physical column of Davtalab.Ashkhas. */
        NULLIF(LEFT(LTRIM(RTRIM(a.TarikhTavalod)), 4), N'') AS SalTavalod,
        COALESCE(religionLegacy.NameFarsi,
                 religionNew.NameFarsi) AS DinMazhab_NameFarsi,
        occupation.Shoghl,
        COALESCE(academic.Tahsilat, modernEducation.Tahsilat) AS Tahsilat,
        residence.Sokonat,
        /* Match the old SP_GetOneErja_ByIDErja candidacy criterion. */
        (SELECT COUNT(*)
         FROM Davtalab.AshkhasEntekhabat priorElection
         WHERE priorElection.ShomarehParvandeh = cf.ShomarehParvandeh
           AND priorElection.CodeEntekhabat NOT IN (31210, 31250)) AS Sabeghe
    FROM TahghighatV2.ResearchAssignment ra
    JOIN TahghighatV2.Referral r ON r.ReferralId=ra.ReferralId
     AND r.ReceiverLevel='HOZE' AND r.IsDeleted=0 AND r.ToMahal=@Mahal
    JOIN TahghighatV2.CaseFile cf ON cf.CaseId=r.CaseId
    JOIN Davtalab.Ashkhas a ON a.ShomarehParvandeh = cf.ShomarehParvandeh
     AND ISNULL(a.IsDelete, 0) = 0
    LEFT JOIN dbo.Citys province ON province.CityId = cf.OstanCityId
    OUTER APPLY
    (
        SELECT TOP (1) v.NameHozeh
        FROM dbo.Vbl_AshkhasEntekhabat v
        WHERE v.ShomarehParvandeh = cf.ShomarehParvandeh
          AND v.CodeEntekhabat = cf.CodeEntekhabat
          AND v.CodeHozeh = cf.CodeHozeh
    ) hoze
    OUTER APPLY
    (
        SELECT STRING_AGG(CONVERT(nvarchar(max), job.Shoghl), N'، ') AS Shoghl
        FROM
        (
            SELECT DISTINCT NULLIF(LTRIM(RTRIM(COALESCE(
                NULLIF(jobRow.SHOGHL, N''),
                NULLIF(jobRow.SHOGHL_FELI_Farsi, N'')
            ))), N'') AS Shoghl
            FROM Davtalab.Sbgh_kari_davtalab jobRow
            WHERE jobRow.ShomarehParvandeh = cf.ShomarehParvandeh
        ) job
        WHERE job.Shoghl IS NOT NULL
    ) occupation
    OUTER APPLY
    (
        /* The old summary used TAHSILAT_DANESHGAHI.maghta_tahsil;
           choose the highest known degree deterministically. */
        SELECT TOP (1)
            CASE t.maghta_tahsil
                WHEN 5 THEN N'کارشناسی ارشد'
                WHEN 4 THEN N'کارشناسی'
                WHEN 3 THEN N'کاردانی'
                WHEN 2 THEN N'دیپلم'
            END AS Tahsilat
        FROM Davtalab.TAHSILAT_DANESHGAHI t
        WHERE t.ShomarehParvandeh = cf.ShomarehParvandeh
          AND t.maghta_tahsil IN (2, 3, 4, 5)
        ORDER BY t.maghta_tahsil DESC, t.id DESC
    ) academic
    OUTER APPLY
    (
        /* Some records only exist in the newer Davtalab.Tahsilat table. */
        SELECT TOP (1)
           COALESCE(NULLIF(LTRIM(RTRIM(d.NameFarsi)), N''),
                    NULLIF(LTRIM(RTRIM(t.ReshteTahsili)), N'')) AS Tahsilat
        FROM Davtalab.Tahsilat t
        LEFT JOIN dbo.DFN d ON d.PID = 1032 AND d.Value = t.MadrakTahsili
        WHERE t.ShomarehParvandeh = cf.ShomarehParvandeh
        ORDER BY t.SalAkhzMadrak DESC, t.ID DESC
    ) modernEducation
    OUTER APPLY
    (
        /* Do not mix a residence address with a research location count. */
        SELECT TOP (1)
            COALESCE(NULLIF(LTRIM(RTRIM(city.FullName)), N''),
                     NULLIF(LTRIM(RTRIM(city.Name)), N''),
                     NULLIF(LTRIM(RTRIM(s.Neshani)), N'')) AS Sokonat
        FROM Davtalab.Sokonat s
        LEFT JOIN dbo.Citys city ON city.CityId = s.Mahal
        WHERE s.ShomarehParvandeh = cf.ShomarehParvandeh
        ORDER BY CASE WHEN NULLIF(LTRIM(RTRIM(s.TaSal)), N'') IS NULL THEN 0 ELSE 1 END,
                 TRY_CONVERT(int, s.TaSal) DESC,
                 TRY_CONVERT(int, s.AzSal) DESC,
                 s.ID DESC
    ) residence
    OUTER APPLY
    (
       SELECT TOP (1) d.NameFarsi
       FROM dbo.DFN d WHERE d.PID = 205 AND d.Value = a.Din
    ) religionLegacy
    OUTER APPLY
    (
       SELECT TOP (1) d.NameFarsi
       FROM dbo.DFN d WHERE d.PID = 10101 AND d.Value = a.Din
    ) religionNew
    WHERE ra.AssignmentId=@AssignmentId;
END;
GO


/* Phase 114. County representative may delegate to active investigators
   who have a PersonHamkari row in precisely their own county, independent
   of an AuthUserId. Identity is resolved or registered atomically. */
CREATE OR ALTER PROCEDURE TahghighatV2.SP_GetCountyInvestigatorCandidates
 @CountyReferralId bigint,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @County int,@Hoze int,@Post int;
 SELECT @County=Mahal,@Post=PostId FROM dbo.Users WHERE UserId=@UserId AND IsActive=1;
 SELECT @Hoze=h.ToMahal FROM TahghighatV2.Referral r
 JOIN TahghighatV2.Referral h ON h.ReferralId=r.ParentReferralId AND h.ReceiverLevel='HOZE' AND h.IsDeleted=0
 WHERE r.ReferralId=@CountyReferralId AND r.ReceiverLevel='SHAHR' AND r.ToMahal=@County AND r.IsDeleted=0;
 IF @Post<>70 OR @Hoze IS NULL OR NOT EXISTS(SELECT 1 FROM TahghighatV2.CountyRepresentative cr
  WHERE cr.AuthUserId=@UserId AND cr.CountyCityId=@County AND cr.HozeCityId=@Hoze AND cr.IsActive=1)
   THROW 55101,N'مجوز مشاهده محققان این شهرستان وجود ندارد.',1;
 SELECT p.PersonId, reg.InvestigatorKey, reg.AuthUserId,c.CityId CountyCityId,c.Name CountyName,
   LTRIM(RTRIM(CONCAT(ISNULL(p.FirstName,N''),N' ',ISNULL(p.LastName,N'')))) FullName,
   CONVERT(bit,CASE WHEN EXISTS(
    SELECT 1 FROM TahghighatV2.ResearchAssignment a
    JOIN TahghighatV2.InvestigatorRegistry ir ON ir.InvestigatorKey=a.InvestigatorId
    WHERE a.ReferralId=@CountyReferralId AND ir.PersonId=p.PersonId AND a.StatusCode<>'CANCELLED')
    OR (reg.InvestigatorKey IS NOT NULL AND reg.IsActive=0)
    OR (reg.InvestigatorKey IS NOT NULL AND EXISTS(SELECT 1 FROM TahghighatV2.CountyInvestigator ci
       WHERE ci.InvestigatorKey=reg.InvestigatorKey AND ci.CountyCityId=@County AND ci.IsActive=0))
    THEN 0 ELSE 1 END) IsAssignable
 FROM dbo.Person p JOIN dbo.Citys c ON c.CityId=@County AND c.IsActive=1
 CROSS APPLY (SELECT TOP(1) h.PersonId FROM Hamkari.PersonHamkari h
  WHERE h.PersonId=p.PersonId AND h.MahalHamkari=@County AND h.NoeHamkari=2
   AND ISNULL(h.IsActive,0)=1 AND ISNULL(h.IsDeleted,0)=0 ORDER BY h.PersonId) cooperation
 OUTER APPLY (SELECT TOP(1) ir.InvestigatorKey,ir.AuthUserId,ir.IsActive
  FROM TahghighatV2.InvestigatorRegistry ir
  WHERE ir.PersonId=p.PersonId AND ir.ProvinceCityId=c.PCityId
  ORDER BY ir.IsActive DESC,ir.InvestigatorKey) reg
 WHERE ISNULL(p.IsDelete,0)=0 ORDER BY FullName,p.PersonId;
END;
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_CountyAssignInvestigator
 @CountyReferralId bigint,@PersonId bigint,@Instruction nvarchar(max),
 @UserId bigint,@DueDatePersian char(10)=NULL
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 IF ISNULL(@CountyReferralId,0)<=0 OR ISNULL(@PersonId,0)<=0 OR ISNULL(@UserId,0)<=0
  OR NULLIF(LTRIM(RTRIM(@Instruction)),N'') IS NULL OR LEN(@Instruction)>6000
  THROW 55102,N'اطلاعات انتساب محقق شهرستان کامل نیست.',1;
 DECLARE @County int,@Post int,@HozeId bigint,@Hoze int,@Root bigint,@Province int,
  @Status varchar(40),@Lock int,@InvLock int,@InvestigatorKey bigint,@RegActive bit,@NewId bigint;
 SELECT @County=Mahal,@Post=PostId FROM dbo.Users WHERE UserId=@UserId AND IsActive=1;
 SELECT @HozeId=r.ParentReferralId FROM TahghighatV2.Referral r
 WHERE r.ReferralId=@CountyReferralId AND r.ReceiverLevel='SHAHR' AND r.ToMahal=@County AND r.IsDeleted=0;
 SELECT @Hoze=h.ToMahal,@Root=h.ParentReferralId FROM TahghighatV2.Referral h
 WHERE h.ReferralId=@HozeId AND h.ReceiverLevel='HOZE' AND h.IsDeleted=0;
 IF @Post<>70 OR @Root IS NULL OR NOT EXISTS(SELECT 1 FROM TahghighatV2.CountyRepresentative cr
  WHERE cr.AuthUserId=@UserId AND cr.CountyCityId=@County AND cr.HozeCityId=@Hoze AND cr.IsActive=1)
  THROW 55103,N'نماینده مجاز شهرستان نیستید.',1;
 IF NOT EXISTS(SELECT 1 FROM Hamkari.PersonHamkari ph
 JOIN dbo.Person p ON p.PersonId=ph.PersonId AND ISNULL(p.IsDelete,0)=0
 WHERE ph.PersonId=@PersonId AND ph.MahalHamkari=@County AND ph.NoeHamkari=2
 AND ISNULL(ph.IsActive,0)=1 AND ISNULL(ph.IsDeleted,0)=0)
 THROW 55104,N'محقق در شهرستان شما همکاری فعال ندارد.',1;
 SELECT @Province=c.PCityId FROM dbo.Citys c WHERE c.CityId=@County AND c.IsActive=1;
 IF @Province IS NULL THROW 55105,N'محل خدمت شهرستان نامعتبر است.',1;
 BEGIN TRY
 BEGIN TRANSACTION;
 DECLARE @LockName nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(20),@Root);
 EXEC @Lock=sys.sp_getapplock @Resource=@LockName,@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @Lock<0 THROW 55106,N'پرونده در حال پردازش است.',1;
 SELECT @Status=r.StateCode FROM TahghighatV2.Referral r WITH(UPDLOCK,HOLDLOCK)
 JOIN TahghighatV2.Referral h ON h.ReferralId=r.ParentReferralId
 JOIN TahghighatV2.Referral p ON p.ReferralId=h.ParentReferralId
 WHERE r.ReferralId=@CountyReferralId AND r.ToMahal=@County AND r.IsDeleted=0 AND r.IsClosed=0
 AND r.StateCode='CHILD_WORKING' AND h.ReferralId=@HozeId AND h.StateCode='CHILD_WORKING'
 AND h.IsClosed=0 AND h.IsDeleted=0 AND p.ReferralId=@Root AND p.IsClosed=0 AND p.IsDeleted=0
 AND p.StateCode='PENDING_CHILD_RESULTS';
 IF @Status IS NULL THROW 55107,N'پرونده در مرحله ارجاع محقق شهرستان نیست.',1;
 DECLARE @InvestigatorResource nvarchar(255)=N'MRV2:INV:'+CONVERT(nvarchar(20),@Province)+N':'+CONVERT(nvarchar(20),@PersonId);
 EXEC @InvLock=sys.sp_getapplock @Resource=@InvestigatorResource,@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @InvLock<0 THROW 55106,N'محقق در حال پردازش است.',1;
 SELECT TOP(1) @InvestigatorKey=InvestigatorKey,@RegActive=IsActive
 FROM TahghighatV2.InvestigatorRegistry WITH(UPDLOCK,HOLDLOCK)
 WHERE PersonId=@PersonId AND ProvinceCityId=@Province ORDER BY IsActive DESC,InvestigatorKey;
 IF @InvestigatorKey IS NOT NULL AND @RegActive=0 THROW 55108,N'رجیستری محقق غیرفعال است.',1;
 IF @InvestigatorKey IS NULL
 BEGIN
  INSERT TahghighatV2.InvestigatorRegistry(PersonId,ProvinceCityId,LegacyCodeMohaghegh,AuthUserId,IsActive,RegisteredBySqlLogin)
  SELECT PersonId,@Province,ShomarehParvandeh,NULL,1,ORIGINAL_LOGIN() FROM dbo.Person WHERE PersonId=@PersonId;
  SET @InvestigatorKey=CONVERT(bigint,SCOPE_IDENTITY());
 END;
 IF EXISTS(SELECT 1 FROM TahghighatV2.CountyInvestigator WHERE InvestigatorKey=@InvestigatorKey AND CountyCityId=@County AND IsActive=0)
  THROW 55109,N'مجوز همکاری شهرستانی محقق لغو شده است.',1;
 IF NOT EXISTS(SELECT 1 FROM TahghighatV2.CountyInvestigator WITH(UPDLOCK,HOLDLOCK)
 WHERE InvestigatorKey=@InvestigatorKey AND CountyCityId=@County)
  INSERT TahghighatV2.CountyInvestigator(InvestigatorKey,CountyCityId,IsActive,RegisteredBySqlLogin)
  VALUES(@InvestigatorKey,@County,1,ORIGINAL_LOGIN());
 IF EXISTS(SELECT 1 FROM TahghighatV2.ResearchAssignment a WITH(UPDLOCK,HOLDLOCK)
 JOIN TahghighatV2.InvestigatorRegistry ir ON ir.InvestigatorKey=a.InvestigatorId
 WHERE a.ReferralId=@CountyReferralId AND ir.PersonId=@PersonId AND a.StatusCode<>'CANCELLED')
 THROW 55110,N'به این محقق برای همین پرونده قبلاً ارجاع شده است.',1;
 INSERT TahghighatV2.ResearchAssignment(ReferralId,InvestigatorId,DueDatePersian,Instruction,StatusCode,CreatedByUserId)
 VALUES(@CountyReferralId,@InvestigatorKey,@DueDatePersian,@Instruction,'PENDING',@UserId);
 SET @NewId=CONVERT(bigint,SCOPE_IDENTITY());
 INSERT TahghighatV2.ResearchAssignmentEvent(AssignmentId,ActionCode,BeforeStatus,AfterStatus,Description,ActorUserId)
 VALUES(@NewId,'COUNTY_ASSIGN_INVESTIGATOR',NULL,'PENDING',@Instruction,@UserId);
 INSERT TahghighatV2.WorkflowEvent(ReferralId,ActionCode,PreviousStateCode,NewStateCode,Description,ActorUserId)
 VALUES(@CountyReferralId,'COUNTY_ASSIGN_INVESTIGATOR',@Status,@Status,@Instruction,@UserId);
 COMMIT;SELECT CONVERT(bit,1) IsSuccess,@NewId AssignmentId;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK;THROW;END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE TahghighatV2.SP_GetCountyInvestigatorWorksheetDetails
 @AssignmentId bigint,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 IF NOT EXISTS(
  SELECT 1 FROM TahghighatV2.ResearchAssignment a
  JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId AND r.ReceiverLevel='SHAHR' AND r.IsDeleted=0
  JOIN TahghighatV2.Referral h ON h.ReferralId=r.ParentReferralId AND h.ReceiverLevel='HOZE'
  JOIN dbo.Users u ON u.UserId=@UserId AND u.IsActive=1 AND u.PostId=70 AND u.Mahal=r.ToMahal
  JOIN TahghighatV2.CountyRepresentative cr ON cr.AuthUserId=u.UserId AND cr.CountyCityId=r.ToMahal AND cr.HozeCityId=h.ToMahal AND cr.IsActive=1
  WHERE a.AssignmentId=@AssignmentId
 ) THROW 54970,N'مجوز مشاهده کاربرگ محقق این شهرستان وجود ندارد.',1;
 SELECT w.WorksheetId,w.AssignmentId,w.ReportText,w.CreatedAtUtc,w.CreatedByUserId,
        d.TahghighType,d.TypeMahalTahghigh,d.CodeManba,d.NahveAshnai,
        d.AzSal,d.TaSal,d.NoeParvandeh,d.NahveBazkhani,d.NameSazman,
        d.NameShahr,d.PeyvastCount,d.Description,
        t.NameFarsi TahghighTypeName, m.NameFarsi TypeMahalTahghighName,
        np.NameFarsi NoeParvandehName,nb.NameFarsi NahveBazkhaniName,
        LTRIM(RTRIM(CONCAT(ISNULL(src.FirstName,N''),N' ',ISNULL(src.LastName,N'')))) ManbaName
 FROM TahghighatV2.ResearchWorksheet w
 LEFT JOIN TahghighatV2.ResearchWorksheetDetails d ON d.WorksheetId=w.WorksheetId
 OUTER APPLY(SELECT TOP(1) x.NameFarsi FROM dbo.DFN x WHERE x.PID=102 AND x.Value=d.TahghighType) t
 OUTER APPLY(SELECT TOP(1) x.NameFarsi FROM dbo.DFN x WHERE x.PID=111 AND x.Value=d.TypeMahalTahghigh) m
 OUTER APPLY(SELECT TOP(1) x.NameFarsi FROM dbo.DFN x WHERE x.PID=113 AND x.Value=d.NoeParvandeh) np
 OUTER APPLY(SELECT TOP(1) x.NameFarsi FROM dbo.DFN x WHERE x.PID=114 AND x.Value=d.NahveBazkhani) nb
 OUTER APPLY(SELECT TOP(1) FirstName,LastName FROM dbo.Person WHERE ShomarehParvandeh=d.CodeManba ORDER BY PersonId) src
 WHERE w.AssignmentId=@AssignmentId ORDER BY w.WorksheetId DESC;
END;
GO

CREATE OR ALTER PROCEDURE TahghighatV2.SP_SaveCountyInvestigatorWorksheetDetails
 @AssignmentId bigint,@UserId bigint,@WorksheetId bigint=NULL,
 @TahghighType int,@TypeMahalTahghigh int,@CodeManba bigint=NULL,
 @AzSal int,@TaSal int,@NahveAshnai nvarchar(200),
 @NoeParvandeh int=NULL,@NahveBazkhani int=NULL,
 @NameSazman nvarchar(300)=NULL,@NameShahr nvarchar(300)=NULL,
 @PeyvastCount int=NULL,@Description nvarchar(max)=NULL
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 SET @NahveAshnai=NULLIF(LTRIM(RTRIM(@NahveAshnai)),N'');
 SET @Description=NULLIF(LTRIM(RTRIM(@Description)),N'');
 IF ISNULL(@AssignmentId,0)<=0 OR ISNULL(@UserId,0)<=0
   OR ISNULL(@TahghighType,0)<=0 OR ISNULL(@TypeMahalTahghigh,0)<=0
   OR @NahveAshnai IS NULL OR LEN(@NahveAshnai)>200
   OR @AzSal IS NULL OR @TaSal IS NULL
   OR @AzSal NOT BETWEEN 1320 AND COALESCE(TRY_CONVERT(int,LEFT(dbo.FarsiDateTimeNow(),4)),1500)
   OR @TaSal NOT BETWEEN @AzSal AND COALESCE(TRY_CONVERT(int,LEFT(dbo.FarsiDateTimeNow(),4)),1500)
   OR LEN(ISNULL(@Description,N''))>12000
   OR (@PeyvastCount IS NOT NULL AND @PeyvastCount NOT BETWEEN 0 AND 9999)
   OR (@WorksheetId IS NOT NULL AND @WorksheetId<=0)
  THROW 54971,N'مقادیر کاربرگ یا مدت آشنایی معتبر نیست.',1;
 IF NOT EXISTS(SELECT 1 FROM dbo.DFN WHERE PID=102 AND Value=@TahghighType)
  OR NOT EXISTS(SELECT 1 FROM dbo.DFN WHERE PID=111 AND Value=@TypeMahalTahghigh)
  THROW 54972,N'نوع یا محل تحقیق معتبر نیست.',1;
 IF @TahghighType=2
 BEGIN
  IF ISNULL(@NoeParvandeh,0)<=0 OR ISNULL(@NahveBazkhani,0)<=0
    OR NOT EXISTS(SELECT 1 FROM dbo.DFN WHERE PID=113 AND Value=@NoeParvandeh)
    OR NOT EXISTS(SELECT 1 FROM dbo.DFN WHERE PID=114 AND Value=@NahveBazkhani)
    THROW 54973,N'نوع پرونده و نحوه بازخوانی را انتخاب کنید.',1;
  SET @CodeManba=0;
 END
 ELSE
 BEGIN
  IF ISNULL(@CodeManba,0)<=0 THROW 54974,N'انتخاب منبع تحقیق الزامی است.',1;
  SET @NoeParvandeh=NULL;SET @NahveBazkhani=NULL;
  SET @NameSazman=NULL;SET @NameShahr=NULL;SET @PeyvastCount=NULL;
 END;
 DECLARE @CountyRef bigint,@Root bigint,@OldStatus varchar(20),@Lock int,@ResultId bigint,
         @ActorPost int,@ActorMahal int,@IsEdit bit=0;
 SELECT @ActorPost=u.PostId,@ActorMahal=u.Mahal FROM dbo.Users u WHERE u.UserId=@UserId AND u.IsActive=1;
 IF ISNULL(@ActorPost,0)<>70
  THROW 54975,N'کاربر مجاز به ثبت کاربرگ محقق شهرستان نیست.',1;
 SELECT @CountyRef=r.ReferralId,@Root=h.ParentReferralId
 FROM TahghighatV2.ResearchAssignment a
 JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId AND r.ReceiverLevel='SHAHR'
 JOIN TahghighatV2.Referral h ON h.ReferralId=r.ParentReferralId AND h.ReceiverLevel='HOZE'
 JOIN TahghighatV2.CountyRepresentative cr ON cr.AuthUserId=@UserId AND cr.CountyCityId=r.ToMahal
    AND cr.HozeCityId=h.ToMahal AND cr.IsActive=1
 WHERE a.AssignmentId=@AssignmentId AND r.ToMahal=@ActorMahal AND r.IsDeleted=0 AND r.IsClosed=0;
 IF @Root IS NULL THROW 54976,N'انتساب محقق برای این شهرستان معتبر نیست.',1;
 BEGIN TRY
 BEGIN TRANSACTION;
 DECLARE @LockKey nvarchar(200)=N'MRV2:REF:'+CONVERT(nvarchar(20),@Root);
 EXEC @Lock=sys.sp_getapplock @Resource=@LockKey,@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @Lock<0 THROW 54977,N'پرونده در حال پردازش است.',1;
 SELECT @OldStatus=a.StatusCode FROM TahghighatV2.ResearchAssignment a WITH(UPDLOCK,HOLDLOCK)
 JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId
 JOIN TahghighatV2.Referral p ON p.ReferralId=r.ParentReferralId
 WHERE a.AssignmentId=@AssignmentId AND r.ReferralId=@CountyRef AND r.ReceiverLevel='SHAHR'
 AND r.IsDeleted=0 AND r.IsClosed=0 AND r.StateCode='CHILD_WORKING'
 AND p.ReferralId=r.ParentReferralId AND p.ReceiverLevel='HOZE' AND p.IsDeleted=0 AND p.IsClosed=0 AND p.StateCode='CHILD_WORKING'
 AND EXISTS(SELECT 1 FROM TahghighatV2.Referral root WHERE root.ReferralId=@Root AND root.StateCode='PENDING_CHILD_RESULTS'
 AND root.IsClosed=0 AND root.IsDeleted=0);
 IF @OldStatus NOT IN('PENDING','IN_PROGRESS') OR @OldStatus IS NULL
  THROW 54978,N'ثبت کاربرگ برای وضعیت فعلی پرونده یا انتساب مجاز نیست.',1;
 SET @ResultId=@WorksheetId;
 IF @WorksheetId IS NOT NULL
 BEGIN
  IF NOT EXISTS(SELECT 1 FROM TahghighatV2.ResearchWorksheet w WITH(UPDLOCK,HOLDLOCK)
    WHERE w.WorksheetId=@WorksheetId AND w.AssignmentId=@AssignmentId)
   THROW 54979,N'کاربرگ قابل ویرایش در این انتساب یافت نشد.',1;
  SET @IsEdit=1;
  UPDATE TahghighatV2.ResearchWorksheet
   SET ReportText=COALESCE(@Description, @NahveAshnai),UpdatedAtUtc=SYSUTCDATETIME()
   WHERE WorksheetId=@WorksheetId AND AssignmentId=@AssignmentId;
 END
 ELSE
 BEGIN
  INSERT TahghighatV2.ResearchWorksheet(AssignmentId,ReportText,CreatedByUserId)
    VALUES(@AssignmentId,COALESCE(@Description,@NahveAshnai),@UserId);
  SET @ResultId=CONVERT(bigint,SCOPE_IDENTITY());
 END;
 UPDATE TahghighatV2.ResearchWorksheetDetails
 SET TahghighType=@TahghighType,TypeMahalTahghigh=@TypeMahalTahghigh,
  CodeManba=@CodeManba,NahveAshnai=@NahveAshnai,AzSal=@AzSal,TaSal=@TaSal,
  NoeParvandeh=@NoeParvandeh,NahveBazkhani=@NahveBazkhani,
  NameSazman=@NameSazman,NameShahr=@NameShahr,PeyvastCount=@PeyvastCount,
  Description=@Description,LastEditedByUserId=@UserId,LastEditedAtUtc=SYSUTCDATETIME()
 WHERE WorksheetId=@ResultId;
 IF @@ROWCOUNT=0
  INSERT TahghighatV2.ResearchWorksheetDetails
   (WorksheetId,TahghighType,TypeMahalTahghigh,CodeManba,NahveAshnai,AzSal,TaSal,
    NoeParvandeh,NahveBazkhani,NameSazman,NameShahr,PeyvastCount,Description,LastEditedByUserId)
  VALUES(@ResultId,@TahghighType,@TypeMahalTahghigh,@CodeManba,@NahveAshnai,@AzSal,@TaSal,
    @NoeParvandeh,@NahveBazkhani,@NameSazman,@NameShahr,@PeyvastCount,@Description,@UserId);
 IF @OldStatus='PENDING'
 BEGIN
  UPDATE TahghighatV2.ResearchAssignment SET StatusCode='IN_PROGRESS' WHERE AssignmentId=@AssignmentId;
  INSERT TahghighatV2.ResearchAssignmentEvent(AssignmentId,ActionCode,BeforeStatus,AfterStatus,Description,ActorUserId)
  VALUES(@AssignmentId,'COUNTY_OFFICER_START','PENDING','IN_PROGRESS',N'شروع تحقیق با کاربرگ رسمی',@UserId);
 END;
 INSERT TahghighatV2.ResearchAssignmentEvent(AssignmentId,ActionCode,BeforeStatus,AfterStatus,Description,ActorUserId)
 VALUES(@AssignmentId,'COUNTY_OFFICER_SAVE_WORKSHEET','IN_PROGRESS','IN_PROGRESS',
  CASE WHEN @IsEdit=1 THEN N'ویرایش کاربرگ رسمی شهرستان ' ELSE N'ثبت کاربرگ رسمی شهرستان ' END+CONVERT(nvarchar(20),@ResultId),@UserId);
 INSERT TahghighatV2.WorkflowEvent(ReferralId,ActionCode,PreviousStateCode,NewStateCode,Description,ActorUserId)
 VALUES(@CountyRef,'COUNTY_OFFICER_SAVE_WORKSHEET','CHILD_WORKING','CHILD_WORKING',
  CASE WHEN @IsEdit=1 THEN N'ویرایش کاربرگ محقق ' ELSE N'ثبت کاربرگ محقق ' END+CONVERT(nvarchar(20),@ResultId),@UserId);
 COMMIT;
 SELECT CONVERT(bit,1) IsSuccess,@ResultId WorksheetId;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK; THROW; END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE TahghighatV2.SP_GetCountyInvestigatorSummary
 @AssignmentId bigint,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @County int,@Post int;
 SELECT @County=Mahal,@Post=PostId FROM dbo.Users WHERE UserId=@UserId AND IsActive=1;
 IF @Post<>70 THROW 55120,N'دسترسی محقق شهرستان معتبر نیست.',1;
 SELECT a.Summary SummaryText,CONVERT(bit,CASE WHEN a.StatusCode='IN_PROGRESS'
  AND r.StateCode='CHILD_WORKING' AND r.IsClosed=0 AND h.StateCode='CHILD_WORKING' AND h.IsClosed=0
  AND root.StateCode='PENDING_CHILD_RESULTS' AND root.IsClosed=0 THEN 1 ELSE 0 END) CanWrite
 FROM TahghighatV2.ResearchAssignment a
 JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId AND r.ReceiverLevel='SHAHR' AND r.IsDeleted=0
 JOIN TahghighatV2.Referral h ON h.ReferralId=r.ParentReferralId AND h.ReceiverLevel='HOZE' AND h.IsDeleted=0
 JOIN TahghighatV2.Referral root ON root.ReferralId=h.ParentReferralId AND root.IsDeleted=0
 JOIN TahghighatV2.CountyRepresentative cr ON cr.AuthUserId=@UserId AND cr.CountyCityId=r.ToMahal
 AND cr.HozeCityId=h.ToMahal AND cr.IsActive=1
 WHERE a.AssignmentId=@AssignmentId AND r.ToMahal=@County;
 IF @@ROWCOUNT<>1 THROW 55121,N'محقق در این شهرستان یافت نشد.',1;
END;
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_SaveCountyInvestigatorSummary
 @AssignmentId bigint,@SummaryText nvarchar(max),@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 SET @SummaryText=LTRIM(RTRIM(ISNULL(@SummaryText,N'')));
 IF ISNULL(@AssignmentId,0)<=0 OR LEN(@SummaryText)<50 OR LEN(@SummaryText)>12000
 THROW 55122,N'جمع‌بندی محقق باید بین ۵۰ تا ۱۲۰۰۰ نویسه باشد.',1;
 DECLARE @County int,@Post int,@CountyRef bigint,@Hoze bigint,@Root bigint,@Status varchar(20),@Lock int;
 SELECT @County=Mahal,@Post=PostId FROM dbo.Users WHERE UserId=@UserId AND IsActive=1;
 SELECT @CountyRef=r.ReferralId,@Hoze=h.ReferralId,@Root=h.ParentReferralId
 FROM TahghighatV2.ResearchAssignment a JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId AND r.ReceiverLevel='SHAHR'
 JOIN TahghighatV2.Referral h ON h.ReferralId=r.ParentReferralId AND h.ReceiverLevel='HOZE'
 JOIN TahghighatV2.CountyRepresentative cr ON cr.AuthUserId=@UserId AND cr.CountyCityId=r.ToMahal
 AND cr.HozeCityId=h.ToMahal AND cr.IsActive=1
 WHERE a.AssignmentId=@AssignmentId AND r.ToMahal=@County AND r.IsDeleted=0;
 IF @Post<>70 OR @Root IS NULL THROW 55123,N'مجوز جمع‌بندی محقق این شهرستان وجود ندارد.',1;
 BEGIN TRY BEGIN TRANSACTION;
 DECLARE @LockName nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(20),@Root);
 EXEC @Lock=sys.sp_getapplock @Resource=@LockName,@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @Lock<0 THROW 55124,N'پرونده در حال پردازش است.',1;
 SELECT @Status=a.StatusCode FROM TahghighatV2.ResearchAssignment a WITH(UPDLOCK,HOLDLOCK)
 JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId
 JOIN TahghighatV2.Referral h ON h.ReferralId=r.ParentReferralId
 JOIN TahghighatV2.Referral root ON root.ReferralId=h.ParentReferralId
 WHERE a.AssignmentId=@AssignmentId AND r.ReferralId=@CountyRef AND r.StateCode='CHILD_WORKING'
 AND r.IsClosed=0 AND r.IsDeleted=0 AND h.StateCode='CHILD_WORKING' AND h.IsClosed=0 AND h.IsDeleted=0
 AND root.ReferralId=@Root AND root.StateCode='PENDING_CHILD_RESULTS' AND root.IsClosed=0 AND root.IsDeleted=0;
 IF @Status<>'IN_PROGRESS' OR @Status IS NULL THROW 55125,N'محقق در وضعیت قابل جمع‌بندی نیست.',1;
 IF NOT EXISTS(SELECT 1 FROM TahghighatV2.ResearchWorksheet WHERE AssignmentId=@AssignmentId)
 THROW 55126,N'ابتدا کاربرگ تحقیق ثبت کنید.',1;
 UPDATE TahghighatV2.ResearchAssignment SET Summary=@SummaryText WHERE AssignmentId=@AssignmentId;
 INSERT TahghighatV2.ResearchAssignmentEvent(AssignmentId,ActionCode,BeforeStatus,AfterStatus,Description,ActorUserId)
 VALUES(@AssignmentId,'COUNTY_OFFICER_SAVE_SUMMARY','IN_PROGRESS','IN_PROGRESS',N'ثبت فرم جمع‌بندی محقق شهرستان',@UserId);
 COMMIT;SELECT CONVERT(bit,1) IsSuccess;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK;THROW;END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE TahghighatV2.SP_GetCountyInvestigatorReport
 @AssignmentId bigint,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @Mahal int,@Post int;
 SELECT @Mahal=u.Mahal,@Post=u.PostId FROM dbo.Users u WHERE u.UserId=@UserId AND u.IsActive=1;
 IF @Post<>70
  THROW 55010,N'مجوز مشاهده فرم محقق شهرستان وجود ندارد.',1;
 IF NOT EXISTS(SELECT 1 FROM TahghighatV2.ResearchAssignment ra
   JOIN TahghighatV2.Referral r ON r.ReferralId=ra.ReferralId
   JOIN TahghighatV2.Referral h ON h.ReferralId=r.ParentReferralId AND h.ReceiverLevel='HOZE'
   JOIN TahghighatV2.CountyRepresentative cr ON cr.AuthUserId=@UserId AND cr.CountyCityId=r.ToMahal
     AND cr.HozeCityId=h.ToMahal AND cr.IsActive=1
   WHERE ra.AssignmentId=@AssignmentId AND r.ReceiverLevel='SHAHR' AND r.ToMahal=@Mahal AND r.IsDeleted=0)
  THROW 55011,N'انتساب محقق در شهرستان شما یافت نشد.',1;
    SELECT
        cf.ShomarehParvandeh,
        cf.CodeEntekhabat,
        cf.CodeHozeh,
        province.Name AS NameOstan,
        hoze.NameHozeh,
        a.FirstName,
        a.LastName,
        a.NamePedar,
        a.NameMostar,
        a.CodeMelli,
        /* SalTavalod is NOT a physical column of Davtalab.Ashkhas. */
        NULLIF(LEFT(LTRIM(RTRIM(a.TarikhTavalod)), 4), N'') AS SalTavalod,
        COALESCE(religionLegacy.NameFarsi,
                 religionNew.NameFarsi) AS DinMazhab_NameFarsi,
        occupation.Shoghl,
        COALESCE(academic.Tahsilat, modernEducation.Tahsilat) AS Tahsilat,
        residence.Sokonat,
        /* Match the old SP_GetOneErja_ByIDErja candidacy criterion. */
        (SELECT COUNT(*)
         FROM Davtalab.AshkhasEntekhabat priorElection
         WHERE priorElection.ShomarehParvandeh = cf.ShomarehParvandeh
           AND priorElection.CodeEntekhabat NOT IN (31210, 31250)) AS Sabeghe
    FROM TahghighatV2.ResearchAssignment ra
    JOIN TahghighatV2.Referral r ON r.ReferralId=ra.ReferralId
     AND r.ReceiverLevel='SHAHR' AND r.IsDeleted=0 AND r.ToMahal=@Mahal
    JOIN TahghighatV2.CaseFile cf ON cf.CaseId=r.CaseId
    JOIN Davtalab.Ashkhas a ON a.ShomarehParvandeh = cf.ShomarehParvandeh
     AND ISNULL(a.IsDelete, 0) = 0
    LEFT JOIN dbo.Citys province ON province.CityId = cf.OstanCityId
    OUTER APPLY
    (
        SELECT TOP (1) v.NameHozeh
        FROM dbo.Vbl_AshkhasEntekhabat v
        WHERE v.ShomarehParvandeh = cf.ShomarehParvandeh
          AND v.CodeEntekhabat = cf.CodeEntekhabat
          AND v.CodeHozeh = cf.CodeHozeh
    ) hoze
    OUTER APPLY
    (
        SELECT STRING_AGG(CONVERT(nvarchar(max), job.Shoghl), N'، ') AS Shoghl
        FROM
        (
            SELECT DISTINCT NULLIF(LTRIM(RTRIM(COALESCE(
                NULLIF(jobRow.SHOGHL, N''),
                NULLIF(jobRow.SHOGHL_FELI_Farsi, N'')
            ))), N'') AS Shoghl
            FROM Davtalab.Sbgh_kari_davtalab jobRow
            WHERE jobRow.ShomarehParvandeh = cf.ShomarehParvandeh
        ) job
        WHERE job.Shoghl IS NOT NULL
    ) occupation
    OUTER APPLY
    (
        /* The old summary used TAHSILAT_DANESHGAHI.maghta_tahsil;
           choose the highest known degree deterministically. */
        SELECT TOP (1)
            CASE t.maghta_tahsil
                WHEN 5 THEN N'کارشناسی ارشد'
                WHEN 4 THEN N'کارشناسی'
                WHEN 3 THEN N'کاردانی'
                WHEN 2 THEN N'دیپلم'
            END AS Tahsilat
        FROM Davtalab.TAHSILAT_DANESHGAHI t
        WHERE t.ShomarehParvandeh = cf.ShomarehParvandeh
          AND t.maghta_tahsil IN (2, 3, 4, 5)
        ORDER BY t.maghta_tahsil DESC, t.id DESC
    ) academic
    OUTER APPLY
    (
        /* Some records only exist in the newer Davtalab.Tahsilat table. */
        SELECT TOP (1)
           COALESCE(NULLIF(LTRIM(RTRIM(d.NameFarsi)), N''),
                    NULLIF(LTRIM(RTRIM(t.ReshteTahsili)), N'')) AS Tahsilat
        FROM Davtalab.Tahsilat t
        LEFT JOIN dbo.DFN d ON d.PID = 1032 AND d.Value = t.MadrakTahsili
        WHERE t.ShomarehParvandeh = cf.ShomarehParvandeh
        ORDER BY t.SalAkhzMadrak DESC, t.ID DESC
    ) modernEducation
    OUTER APPLY
    (
        /* Do not mix a residence address with a research location count. */
        SELECT TOP (1)
            COALESCE(NULLIF(LTRIM(RTRIM(city.FullName)), N''),
                     NULLIF(LTRIM(RTRIM(city.Name)), N''),
                     NULLIF(LTRIM(RTRIM(s.Neshani)), N'')) AS Sokonat
        FROM Davtalab.Sokonat s
        LEFT JOIN dbo.Citys city ON city.CityId = s.Mahal
        WHERE s.ShomarehParvandeh = cf.ShomarehParvandeh
        ORDER BY CASE WHEN NULLIF(LTRIM(RTRIM(s.TaSal)), N'') IS NULL THEN 0 ELSE 1 END,
                 TRY_CONVERT(int, s.TaSal) DESC,
                 TRY_CONVERT(int, s.AzSal) DESC,
                 s.ID DESC
    ) residence
    OUTER APPLY
    (
       SELECT TOP (1) d.NameFarsi
       FROM dbo.DFN d WHERE d.PID = 205 AND d.Value = a.Din
    ) religionLegacy
    OUTER APPLY
    (
       SELECT TOP (1) d.NameFarsi
       FROM dbo.DFN d WHERE d.PID = 10101 AND d.Value = a.Din
    ) religionNew
    WHERE ra.AssignmentId=@AssignmentId;
END;
GO

CREATE OR ALTER PROCEDURE TahghighatV2.SP_CountyOfficerCompleteAssignment
 @AssignmentId bigint,@Summary nvarchar(max),@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 SET @Summary=LTRIM(RTRIM(ISNULL(@Summary,N'')));
 IF ISNULL(@AssignmentId,0)<=0 OR LEN(@Summary)<50 OR LEN(@Summary)>12000
 THROW 55130,N'شناسه محقق یا متن جمع‌بندی معتبر نیست.',1;
 DECLARE @County int,@Post int,@CountyRef bigint,@Root bigint,@Status varchar(20),@Saved nvarchar(max),@Lock int;
 SELECT @County=Mahal,@Post=PostId FROM dbo.Users WHERE UserId=@UserId AND IsActive=1;
 SELECT @CountyRef=r.ReferralId,@Root=h.ParentReferralId
 FROM TahghighatV2.ResearchAssignment a JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId AND r.ReceiverLevel='SHAHR'
 JOIN TahghighatV2.Referral h ON h.ReferralId=r.ParentReferralId AND h.ReceiverLevel='HOZE'
 JOIN TahghighatV2.CountyRepresentative cr ON cr.AuthUserId=@UserId AND cr.CountyCityId=r.ToMahal
   AND cr.HozeCityId=h.ToMahal AND cr.IsActive=1
 WHERE a.AssignmentId=@AssignmentId AND r.ToMahal=@County AND r.IsDeleted=0;
 IF @Post<>70 OR @Root IS NULL THROW 55131,N'تکمیل محقق خارج از محدوده شهرستان است.',1;
 BEGIN TRY BEGIN TRANSACTION;
 DECLARE @LockName nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(20),@Root);
 EXEC @Lock=sys.sp_getapplock @Resource=@LockName,@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @Lock<0 THROW 55132,N'پرونده در حال پردازش است.',1;
 SELECT @Status=a.StatusCode,@Saved=a.Summary FROM TahghighatV2.ResearchAssignment a WITH(UPDLOCK,HOLDLOCK)
 JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId
 JOIN TahghighatV2.Referral h ON h.ReferralId=r.ParentReferralId
 JOIN TahghighatV2.Referral root ON root.ReferralId=h.ParentReferralId
 WHERE a.AssignmentId=@AssignmentId AND r.ReferralId=@CountyRef AND r.StateCode='CHILD_WORKING'
 AND r.IsClosed=0 AND r.IsDeleted=0 AND h.StateCode='CHILD_WORKING' AND h.IsClosed=0 AND h.IsDeleted=0
 AND root.ReferralId=@Root AND root.StateCode='PENDING_CHILD_RESULTS' AND root.IsClosed=0 AND root.IsDeleted=0;
 IF @Status<>'IN_PROGRESS' OR @Status IS NULL THROW 55133,N'محقق باید در حال تحقیق باشد.',1;
 IF @Saved IS NULL OR LTRIM(RTRIM(@Saved))<>@Summary THROW 55134,N'ابتدا فرم جمع‌بندی محقق را ذخیره کنید.',1;
 IF NOT EXISTS(SELECT 1 FROM TahghighatV2.ResearchWorksheet WHERE AssignmentId=@AssignmentId)
 THROW 55135,N'ثبت حداقل یک کاربرگ الزامی است.',1;
 UPDATE TahghighatV2.ResearchAssignment SET StatusCode='DONE',FinishedAtUtc=SYSUTCDATETIME() WHERE AssignmentId=@AssignmentId;
 INSERT TahghighatV2.ResearchAssignmentEvent(AssignmentId,ActionCode,BeforeStatus,AfterStatus,Description,ActorUserId)
 VALUES(@AssignmentId,'COUNTY_OFFICER_COMPLETE_ASSIGNMENT','IN_PROGRESS','DONE',N'تکمیل تحقیق محقق شهرستان',@UserId);
 INSERT TahghighatV2.WorkflowEvent(ReferralId,ActionCode,PreviousStateCode,NewStateCode,Description,ActorUserId)
 VALUES(@CountyRef,'COUNTY_OFFICER_COMPLETE_ASSIGNMENT','CHILD_WORKING','CHILD_WORKING',N'تکمیل تحقیق محقق شهرستان',@UserId);
 COMMIT; SELECT CONVERT(bit,1) IsSuccess;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK;THROW;END CATCH;
END;
GO

/* Display names must be returned for county investigator cards, not only numeric keys. */
CREATE OR ALTER PROCEDURE TahghighatV2.SP_GetCountyAssignments
 @CountyReferralId bigint,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @County int,@Hoze int,@Post int;
 SELECT @County=Mahal,@Post=PostId FROM dbo.Users WHERE UserId=@UserId AND IsActive=1;
 SELECT @Hoze=h.ToMahal FROM TahghighatV2.Referral r
 JOIN TahghighatV2.Referral h ON h.ReferralId=r.ParentReferralId AND h.ReceiverLevel='HOZE' AND h.IsDeleted=0
 WHERE r.ReferralId=@CountyReferralId AND r.ToMahal=@County AND r.ReceiverLevel='SHAHR' AND r.IsDeleted=0;
 IF @Post<>70 OR @Hoze IS NULL OR NOT EXISTS(SELECT 1 FROM TahghighatV2.CountyRepresentative cr
  WHERE cr.AuthUserId=@UserId AND cr.CountyCityId=@County AND cr.HozeCityId=@Hoze AND cr.IsActive=1)
 THROW 55140,N'مجوز مشاهده محققان شهرستان وجود ندارد.',1;
 SELECT a.AssignmentId,a.ReferralId,a.InvestigatorId InvestigatorKey,ir.AuthUserId,ir.PersonId,
  LTRIM(RTRIM(CONCAT(ISNULL(p.FirstName,N''),N' ',ISNULL(p.LastName,N'')))) FullName,
  a.Instruction,a.StatusCode,a.DueDatePersian,a.Summary,a.CreatedAtUtc,a.FinishedAtUtc,
  (SELECT COUNT_BIG(*) FROM TahghighatV2.ResearchWorksheet w WHERE w.AssignmentId=a.AssignmentId) WorksheetCount
 FROM TahghighatV2.ResearchAssignment a
 JOIN TahghighatV2.InvestigatorRegistry ir ON ir.InvestigatorKey=a.InvestigatorId
 LEFT JOIN dbo.Person p ON p.PersonId=ir.PersonId
 WHERE a.ReferralId=@CountyReferralId ORDER BY a.AssignmentId DESC;
END;
GO

/* Phase 116 — explicit confirmation and atomic replacement of investigator
   summary documents. Existing worksheet / county / province documents are
   never touched. Existing files remain in the audit trail (soft delete).
   The expected-ID set prevents deletion of files added after confirmation. */
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_ReplaceInvestigatorSummaryImage
    @AssignmentId bigint,
    @Scope varchar(10),                -- OSTAN | HOZE | COUNTY
    @UserId bigint,
    @ExpectedAttachmentIds nvarchar(1000),
    @OriginalFileName nvarchar(255),
    @MimeType nvarchar(100),
    @FileData varbinary(max)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    IF @AssignmentId IS NULL OR @AssignmentId<=0 OR @UserId IS NULL OR @UserId<=0
       OR @Scope NOT IN ('OSTAN','HOZE','COUNTY') OR @Scope IS NULL
        THROW 56701,N'شناسه انتساب، کاربر یا محدوده معتبر نیست.',1;
    IF @ExpectedAttachmentIds IS NULL OR LEN(@ExpectedAttachmentIds)>1000
        THROW 56702,N'فهرست اسناد پیشین معتبر نیست.',1;
    IF @OriginalFileName IS NULL OR @OriginalFileName NOT LIKE N'JambandiMohaghegh[_]%.%'
       OR LEN(@OriginalFileName)>255 OR CHARINDEX(N'/',@OriginalFileName)>0
       OR CHARINDEX(N'\',@OriginalFileName)>0
       OR DATALENGTH(@FileData) NOT BETWEEN 1 AND 3145728
       OR NOT ((@MimeType=N'image/png' AND SUBSTRING(@FileData,1,8)=0x89504E470D0A1A0A)
             OR (@MimeType=N'image/jpeg' AND SUBSTRING(@FileData,1,3)=0xFFD8FF))
        THROW 56703,N'تصویر جدید جمع‌بندی معتبر نیست.',1;

    DECLARE @Expected TABLE (AttachmentId uniqueidentifier PRIMARY KEY);
    IF LEN(@ExpectedAttachmentIds)>0
    BEGIN
        IF EXISTS(SELECT 1 FROM STRING_SPLIT(@ExpectedAttachmentIds,N',')
                  WHERE TRY_CONVERT(uniqueidentifier,value) IS NULL OR LTRIM(RTRIM(value))=N'')
            THROW 56704,N'فهرست شناسه پیوست‌ها نامعتبر است.',1;
        IF (SELECT COUNT(*) FROM STRING_SPLIT(@ExpectedAttachmentIds,N','))>20
            THROW 56704,N'تعداد اسناد پیشین نامعتبر است.',1;
        BEGIN TRY
            INSERT @Expected(AttachmentId)
            SELECT CONVERT(uniqueidentifier,value) FROM STRING_SPLIT(@ExpectedAttachmentIds,N',');
        END TRY BEGIN CATCH
            THROW 56704,N'شناسه تکراری یا نامعتبر در فهرست پیوست‌ها وجود دارد.',1;
        END CATCH;
    END;

    DECLARE @CaseId bigint,@Number bigint,@PersonId bigint,@ReferralId bigint,
            @RootId bigint,@CanWrite bit,@InvestigatorKey bigint,@InvestigatorPersonId bigint,
            @InvestigatorLegacyCode bigint,@Lock int,@FileId uniqueidentifier=NEWID();
    DECLARE @Access TABLE (
      CaseId bigint,ShomarehParvandeh bigint,PersonId bigint NULL,
      ReferralId bigint,AssignmentId bigint NULL,RootReferralId bigint,
      CanRead bit,CanWrite bit
    );

    BEGIN TRY
      BEGIN TRANSACTION;
      -- The same access checks used for normal attachment uploads apply here.
      -- A client-provided role or level never grants permissions by itself.
      IF @Scope='OSTAN'
      BEGIN
        SELECT TOP(1) @CaseId=sc.CaseId,@Number=sc.ShomarehParvandeh,
          @PersonId=sc.CasePersonId,@ReferralId=sc.ReferralId,
          @RootId=sc.RootReferralId,@InvestigatorKey=sc.InvestigatorKey,
          @InvestigatorPersonId=sc.InvestigatorPersonId,
          @InvestigatorLegacyCode=sc.InvestigatorLegacyCode
        FROM TahghighatV2.fn_ProvinceInvestigatorDocumentScope
          ('RESEARCH_ASSIGNMENT',@AssignmentId,@UserId) sc
        JOIN TahghighatV2.Referral r ON r.ReferralId=sc.ReferralId
        WHERE sc.CanWrite=1 AND sc.AssignmentId=@AssignmentId AND r.ReceiverLevel='OSTAN';
      END
      ELSE
      BEGIN
        INSERT @Access
        EXEC TahghighatV2.SP_UnifiedAttachmentTargetAccess
             'RESEARCH_ASSIGNMENT',@AssignmentId,@UserId;
        SELECT TOP(1) @CaseId=sc.CaseId,@Number=sc.ShomarehParvandeh,
          @PersonId=sc.PersonId,@ReferralId=sc.ReferralId,@RootId=sc.RootReferralId
        FROM @Access sc
        JOIN TahghighatV2.Referral r ON r.ReferralId=sc.ReferralId
        WHERE sc.AssignmentId=@AssignmentId AND sc.CanWrite=1
          AND r.ReceiverLevel=CASE WHEN @Scope='HOZE' THEN 'HOZE' ELSE 'SHAHR' END;
      END;
      IF @CaseId IS NULL OR @RootId IS NULL OR @ReferralId IS NULL
        THROW 56705,N'مجوز جایگزینی تصویر جمع‌بندی در این انتساب وجود ندارد.',1;
      IF NOT EXISTS (SELECT 1 FROM TahghighatV2.InvestigatorSummary
                     WHERE AssignmentId=@AssignmentId)
        THROW 56706,N'ابتدا متن جمع‌بندی محقق را ثبت کنید.',1;

      DECLARE @Resource nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(25),@RootId);
      EXEC @Lock=sys.sp_getapplock @Resource=@Resource,
          @LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
      IF @Lock<0 THROW 56707,N'پرونده همزمان در حال پردازش است.',1;

      -- Re-check permission after serializing the whole referral tree.
      SET @CanWrite=0;
      IF @Scope='OSTAN'
      BEGIN
        IF EXISTS(SELECT 1 FROM TahghighatV2.fn_ProvinceInvestigatorDocumentScope
                   ('RESEARCH_ASSIGNMENT',@AssignmentId,@UserId) sc
                  WHERE sc.CanWrite=1 AND sc.CaseId=@CaseId AND sc.ReferralId=@ReferralId
                    AND sc.AssignmentId=@AssignmentId)
            SET @CanWrite=1;
      END
      ELSE
      BEGIN
        DELETE FROM @Access;
        INSERT @Access EXEC TahghighatV2.SP_UnifiedAttachmentTargetAccess
            'RESEARCH_ASSIGNMENT',@AssignmentId,@UserId;
        IF EXISTS(SELECT 1 FROM @Access
                  WHERE CanWrite=1 AND CaseId=@CaseId AND ReferralId=@ReferralId
                    AND AssignmentId=@AssignmentId) SET @CanWrite=1;
      END;
      IF @CanWrite<>1 THROW 56708,N'دسترسی ویرایش پیوست دیگر معتبر نیست.',1;

      DECLARE @FileResource nvarchar(255)=N'MRV2:FILE:RESEARCH_ASSIGNMENT:'+CONVERT(nvarchar(25),@AssignmentId);
      EXEC @Lock=sys.sp_getapplock @Resource=@FileResource,
          @LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
      IF @Lock<0 THROW 56709,N'اسناد همزمان در حال تغییر هستند.',1;

      -- Confirm that the user approved exactly the current document set.
      DECLARE @ExistingCount int;
      SELECT @ExistingCount=COUNT(*)
      FROM MeratFilesDB.dbo.TahghighatDocument WITH(UPDLOCK,HOLDLOCK)
      WHERE TargetEntity='RESEARCH_ASSIGNMENT' AND TargetRecordId=@AssignmentId AND IsDeleted=0;
      IF @ExistingCount<>(SELECT COUNT(*) FROM @Expected)
         OR EXISTS(
           SELECT 1 FROM MeratFilesDB.dbo.TahghighatDocument d
           WHERE d.TargetEntity='RESEARCH_ASSIGNMENT' AND d.TargetRecordId=@AssignmentId
             AND d.IsDeleted=0
             AND NOT EXISTS(SELECT 1 FROM @Expected e WHERE e.AttachmentId=d.AttachmentId)
         )
        THROW 56710,N'فهرست اسناد تغییر کرده است؛ آن را بازخوانی و دوباره حذف را تأیید کنید.',1;

      UPDATE MeratFilesDB.dbo.TahghighatDocument
       SET IsDeleted=1,DeletedByUserId=@UserId,DeletedAtUtc=SYSUTCDATETIME(),
           DeleteReason=N'جایگزینی تصویر جمع‌بندی محقق با تأیید کاربر'
       WHERE TargetEntity='RESEARCH_ASSIGNMENT' AND TargetRecordId=@AssignmentId AND IsDeleted=0;

      INSERT MeratFilesDB.dbo.TahghighatDocument
       (AttachmentId,CaseId,ShomarehParvandeh,PersonId,ReferralId,AssignmentId,
        AttachmentKind,SummaryLevel,TargetEntity,TargetRecordId,OriginalFileName,
        MimeType,FileSizeBytes,Sha256,FileData,CreatedByUserId,
        InvestigatorKey,InvestigatorPersonId,InvestigatorLegacyCode,AttachmentDescription)
      VALUES
       (@FileId,@CaseId,@Number,@PersonId,@ReferralId,@AssignmentId,
        'SUMMARY','INVESTIGATOR','RESEARCH_ASSIGNMENT',@AssignmentId,
        @OriginalFileName,@MimeType,DATALENGTH(@FileData),
        CONVERT(binary(32),HASHBYTES('SHA2_256',@FileData)),@FileData,@UserId,
        @InvestigatorKey,@InvestigatorPersonId,@InvestigatorLegacyCode,
        N'تصویر تولیدشده از فرم جمع‌بندی محقق');

      COMMIT TRANSACTION;
      SELECT CONVERT(bit,1) AS IsSuccess,@FileId AS AttachmentId,
             @ExistingCount AS ReplacedCount;
    END TRY
    BEGIN CATCH
      IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
      THROW;
    END CATCH;
END;
GO
