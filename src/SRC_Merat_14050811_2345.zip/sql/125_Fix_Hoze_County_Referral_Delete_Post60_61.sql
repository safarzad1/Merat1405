﻿SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
-- Allow deletion only with post permission; preserve untouched-destination checks.
UPDATE TahghighatV2.PostActionPermission SET IsAllowed=1
WHERE PostId IN (60,61) AND ActionCode='HOZE_DELETE_COUNTY_REFERRAL';
INSERT INTO TahghighatV2.PostActionPermission(PostId,ActionCode,IsAllowed)
SELECT v.PostId,'HOZE_DELETE_COUNTY_REFERRAL',1 FROM (VALUES(60),(61)) v(PostId)
WHERE NOT EXISTS (SELECT 1 FROM TahghighatV2.PostActionPermission p
 WHERE p.PostId=v.PostId AND p.ActionCode='HOZE_DELETE_COUNTY_REFERRAL');
GO
CREATE OR ALTER PROCEDURE [TahghighatV2].[SP_GetHozeCountyReferrals]
 @HozeReferralId bigint,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @Hoze int,@Post int;
 SELECT @Hoze=u.Mahal,@Post=u.PostId FROM dbo.Users u WHERE u.UserId=@UserId AND u.IsActive=1;
 IF ISNULL(@Post,0) NOT IN(60,61) OR NOT EXISTS(
  SELECT 1 FROM TahghighatV2.Referral h WHERE h.ReferralId=@HozeReferralId
  AND h.ToMahal=@Hoze AND h.ReceiverLevel='HOZE' AND h.IsDeleted=0)
  THROW 54882,N'فهرست ارجاعات شهرستان در محدوده دسترسی شما نیست.',1;
 SELECT r.ReferralId CountyReferralId,r.ToMahal CountyCityId,city.Name CountyName,
  r.StateCode,r.IsClosed,r.Description,r.CreatedAtUtc,r.UpdatedAtUtc,
  s.SummaryText CountySummaryText,
  (SELECT COUNT_BIG(*) FROM TahghighatV2.ResearchAssignment a
    WHERE a.ReferralId=r.ReferralId AND a.StatusCode IN('PENDING','IN_PROGRESS')) OpenAssignments,
  CONVERT(bit,CASE WHEN @Post IN (60,61)
    AND EXISTS (SELECT 1 FROM TahghighatV2.PostActionPermission ap
      WHERE ap.PostId=@Post AND ap.ActionCode='HOZE_DELETE_COUNTY_REFERRAL' AND ap.IsAllowed=1)
    AND h.StateCode='CHILD_WORKING' AND h.IsClosed=0 AND h.IsDeleted=0
    AND root.StateCode='PENDING_CHILD_RESULTS' AND root.IsClosed=0 AND root.IsDeleted=0
    AND r.ReceiverLevel='SHAHR' AND r.StateCode='CHILD_INBOX' AND r.IsClosed=0
    AND EXISTS (SELECT 1 FROM TahghighatV2.WorkflowEvent e
      WHERE e.ReferralId=r.ReferralId AND e.ActionCode='CHILD_CREATED')
    AND NOT EXISTS (SELECT 1 FROM TahghighatV2.WorkflowEvent e
      WHERE e.ReferralId=r.ReferralId AND e.ActionCode<>'CHILD_CREATED')
    AND NOT EXISTS (SELECT 1 FROM TahghighatV2.Referral descendants WHERE descendants.ParentReferralId=r.ReferralId)
    AND NOT EXISTS (SELECT 1 FROM TahghighatV2.ResearchAssignment a WHERE a.ReferralId=r.ReferralId)
    AND NOT EXISTS (SELECT 1 FROM TahghighatV2.CountySummary cs WHERE cs.ReferralId=r.ReferralId)
    AND NOT EXISTS (SELECT 1 FROM TahghighatV2.NoResearchDecision nr WHERE nr.ReferralId=r.ReferralId)
    THEN 1 ELSE 0 END) CanDelete
 FROM TahghighatV2.Referral r LEFT JOIN dbo.Citys city ON city.CityId=r.ToMahal
 LEFT JOIN TahghighatV2.CountySummary s ON s.ReferralId=r.ReferralId
 LEFT JOIN TahghighatV2.Referral h ON h.ReferralId=r.ParentReferralId
 LEFT JOIN TahghighatV2.Referral root ON root.ReferralId=h.ParentReferralId
 WHERE r.ParentReferralId=@HozeReferralId AND r.ReceiverLevel='SHAHR' AND r.IsDeleted=0
 ORDER BY r.ReferralId DESC;
END;

GO
CREATE OR ALTER PROCEDURE [TahghighatV2].[SP_HozeDeleteUntouchedCountyReferral]
 @HozeReferralId bigint,@CountyReferralId bigint,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 SET XACT_ABORT ON;
 IF @HozeReferralId IS NULL OR @HozeReferralId<=0
   OR @CountyReferralId IS NULL OR @CountyReferralId<=0
   OR @UserId IS NULL OR @UserId<=0 OR @HozeReferralId=@CountyReferralId
   THROW 54920,N'شناسه ارجاع حوزه، شهرستان یا کاربر نامعتبر است.',1;
 DECLARE @Mahal int,@Post int,@RootId bigint,@HozeState varchar(40),
         @CountyState varchar(40),@Lock int;
 SELECT @Mahal=u.Mahal,@Post=u.PostId FROM dbo.Users u
 WHERE u.UserId=@UserId AND u.IsActive=1;
 IF @Post NOT IN (60,61) OR NOT EXISTS(SELECT 1 FROM dbo.Citys c
       WHERE c.CityId=@Mahal AND c.IsHoze=1 AND c.IsActive=1)
   OR NOT EXISTS(SELECT 1 FROM TahghighatV2.PostActionPermission p
       WHERE p.PostId=@Post AND p.ActionCode='HOZE_DELETE_COUNTY_REFERRAL' AND p.IsAllowed=1)
   THROW 54921,N'مجوز حذف ارجاع شهرستان برای این کاربر وجود ندارد.',1;
 -- Only a hint before transaction; all scope/permissions and states are rechecked under locks.
 SELECT @RootId=h.ParentReferralId FROM TahghighatV2.Referral h
 WHERE h.ReferralId=@HozeReferralId AND h.ToMahal=@Mahal
   AND h.ReceiverLevel='HOZE' AND h.IsDeleted=0;
 IF @RootId IS NULL THROW 54922,N'ارجاع حوزه در محدوده دسترسی شما یافت نشد.',1;
 BEGIN TRY
  BEGIN TRANSACTION;
  DECLARE @RootResource nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(25),@RootId);
  DECLARE @HozeResource nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(25),@HozeReferralId);
  EXEC @Lock=sys.sp_getapplock @Resource=@RootResource,@LockMode=N'Exclusive',
       @LockOwner=N'Transaction',@LockTimeout=10000;
  IF @Lock<0 THROW 54923,N'پرونده در حال پردازش است؛ دوباره تلاش کنید.',1;
  EXEC @Lock=sys.sp_getapplock @Resource=@HozeResource,@LockMode=N'Exclusive',
       @LockOwner=N'Transaction',@LockTimeout=10000;
  IF @Lock<0 THROW 54924,N'پرونده در حال پردازش است؛ دوباره تلاش کنید.',1;
  SELECT @HozeState=h.StateCode
  FROM TahghighatV2.Referral h WITH(UPDLOCK,HOLDLOCK)
  JOIN TahghighatV2.Referral root WITH(UPDLOCK,HOLDLOCK) ON root.ReferralId=h.ParentReferralId
  WHERE h.ReferralId=@HozeReferralId AND h.ParentReferralId=@RootId
    AND h.ReceiverLevel='HOZE' AND h.ToMahal=@Mahal
    AND h.StateCode='CHILD_WORKING' AND h.IsClosed=0 AND h.IsDeleted=0
    AND root.ParentReferralId IS NULL AND root.StateCode='PENDING_CHILD_RESULTS'
    AND root.IsClosed=0 AND root.IsDeleted=0;
  IF @HozeState IS NULL THROW 54925,N'حوزه در وضعیت مجاز برای حذف ارجاع نیست.',1;
  SELECT @CountyState=c.StateCode
  FROM TahghighatV2.Referral c WITH(UPDLOCK,HOLDLOCK)
  JOIN dbo.Citys county ON county.CityId=c.ToMahal
  JOIN dbo.Citys hoze ON hoze.CityId=@Mahal
  WHERE c.ReferralId=@CountyReferralId AND c.ParentReferralId=@HozeReferralId
    AND c.ReceiverLevel='SHAHR' AND c.FromMahal=@Mahal
    AND county.IsHoze=0 AND county.CityIdHozeh=@Mahal AND county.PCityId=hoze.PCityId
    AND c.StateCode='CHILD_INBOX' AND c.IsClosed=0 AND c.IsDeleted=0;
  IF @CountyState IS NULL THROW 54926,N'ارجاع شهرستان رسیدگی شده یا قابل حذف نیست.',1;
  IF NOT EXISTS (SELECT 1 FROM TahghighatV2.WorkflowEvent e WITH(UPDLOCK,HOLDLOCK)
        WHERE e.ReferralId=@CountyReferralId AND e.ActionCode='CHILD_CREATED')
     OR EXISTS (SELECT 1 FROM TahghighatV2.WorkflowEvent e WITH(UPDLOCK,HOLDLOCK)
        WHERE e.ReferralId=@CountyReferralId AND e.ActionCode<>'CHILD_CREATED')
     OR EXISTS (SELECT 1 FROM TahghighatV2.Referral sub WITH(UPDLOCK,HOLDLOCK)
        WHERE sub.ParentReferralId=@CountyReferralId)
     OR EXISTS (SELECT 1 FROM TahghighatV2.ResearchAssignment a WITH(UPDLOCK,HOLDLOCK)
        WHERE a.ReferralId=@CountyReferralId)
     OR EXISTS (SELECT 1 FROM TahghighatV2.CountySummary cs WITH(UPDLOCK,HOLDLOCK)
        WHERE cs.ReferralId=@CountyReferralId)
     OR EXISTS (SELECT 1 FROM TahghighatV2.NoResearchDecision nr WITH(UPDLOCK,HOLDLOCK)
        WHERE nr.ReferralId=@CountyReferralId)
    THROW 54927,N'شهرستان اقدام، تحقیق یا جمع‌بندی ثبت کرده است؛ حذف مجاز نیست.',1;
  UPDATE TahghighatV2.Referral
    SET IsDeleted=1,UpdatedByUserId=@UserId,UpdatedAtUtc=SYSUTCDATETIME()
  WHERE ReferralId=@CountyReferralId AND ParentReferralId=@HozeReferralId
    AND StateCode='CHILD_INBOX' AND IsClosed=0 AND IsDeleted=0;
  IF @@ROWCOUNT<>1 THROW 54928,N'وضعیت ارجاع شهرستان تغییر کرده است؛ دوباره تلاش کنید.',1;
  DECLARE @Reason nvarchar(250)=N'حذف ارجاع شهرستان فرعی پیش از اقدام مقصد';
  INSERT TahghighatV2.WorkflowEvent
    (ReferralId,ActionCode,PreviousStateCode,NewStateCode,Description,ActorUserId)
  VALUES (@CountyReferralId,'HOZE_DELETE_COUNTY_REFERRAL','CHILD_INBOX','CHILD_INBOX',@Reason,@UserId),
    (@HozeReferralId,'HOZE_DELETE_COUNTY_REFERRAL',@HozeState,@HozeState,
      @Reason+N'؛ ارجاع شماره '+CONVERT(nvarchar(25),@CountyReferralId),@UserId);
  COMMIT TRANSACTION;
  SELECT CONVERT(bit,1) IsSuccess,@CountyReferralId CountyReferralId,@HozeReferralId HozeReferralId;
 END TRY
 BEGIN CATCH
  IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
  THROW;
 END CATCH;
END;

GO
