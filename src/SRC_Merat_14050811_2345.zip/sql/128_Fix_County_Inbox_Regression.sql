﻿SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE [TahghighatV2].[SP_GetCountyInbox]
 @UserId bigint,@Page int=1,@PageSize int=25
AS
BEGIN
 SET NOCOUNT ON;
 IF @UserId IS NULL OR @UserId<=0 OR @Page<1 OR @PageSize NOT BETWEEN 1 AND 100
 THROW 54072,N'ورودی کارتابل شهرستان معتبر نیست.',1;
 SELECT r.ReferralId CountyReferralId,r.ParentReferralId HozeReferralId,
  r.ToMahal CountyCityId,r.StateCode,r.Description,r.CreatedAtUtc,
  cf.CaseId,cf.CodeEntekhabat,cf.CodeHozeh,cf.ShomarehParvandeh,
  applicant.FirstName,applicant.LastName,applicant.NamePedar,
  NULLIF(LEFT(LTRIM(RTRIM(applicant.TarikhTavalod)),4),N'') SalTavalod,
  city.Name CountyName,city.PCityId ProvinceCityId,province.Name ProvinceName,
  COUNT_BIG(*) OVER() TotalCount
 FROM TahghighatV2.Referral r
 JOIN dbo.Users u ON u.UserId=@UserId AND u.IsActive=1 AND u.PostId=70 AND u.Mahal=r.ToMahal
 JOIN TahghighatV2.Referral h ON h.ReferralId=r.ParentReferralId
  AND h.ReceiverLevel='HOZE' AND h.IsDeleted=0
 JOIN dbo.Citys county ON county.CityId=r.ToMahal AND county.CityIdHozeh=h.ToMahal
 JOIN TahghighatV2.CaseFile cf ON cf.CaseId=r.CaseId
 LEFT JOIN dbo.Citys city ON city.CityId=r.ToMahal
 LEFT JOIN dbo.Citys province ON province.CityId=city.PCityId
 OUTER APPLY (SELECT TOP(1) a.FirstName,a.LastName,a.NamePedar,a.TarikhTavalod
 FROM Davtalab.Ashkhas a WHERE a.ShomarehParvandeh=cf.ShomarehParvandeh
 AND ISNULL(a.IsDelete,0)=0) applicant
 WHERE r.ReceiverLevel='SHAHR' AND r.IsDeleted=0 AND r.IsClosed=0
  AND r.StateCode IN('CHILD_INBOX','CHILD_WORKING')
 ORDER BY r.CreatedAtUtc DESC,r.ReferralId DESC
 OFFSET (CONVERT(bigint,@Page)-1)*@PageSize ROWS FETCH NEXT @PageSize ROWS ONLY;
END;
GO
CREATE OR ALTER PROCEDURE [TahghighatV2].[SP_GetCountyAssignments]
 @CountyReferralId bigint,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @County int,@Hoze int,@Post int;
 SELECT @County=Mahal,@Post=PostId FROM dbo.Users WHERE UserId=@UserId AND IsActive=1;
 SELECT @Hoze=h.ToMahal FROM TahghighatV2.Referral r
 JOIN TahghighatV2.Referral h ON h.ReferralId=r.ParentReferralId AND h.ReceiverLevel='HOZE' AND h.IsDeleted=0
 WHERE r.ReferralId=@CountyReferralId AND r.ToMahal=@County AND r.ReceiverLevel='SHAHR' AND r.IsDeleted=0;
 IF @Post<>70 OR NOT EXISTS (
  SELECT 1 FROM TahghighatV2.Referral r
  JOIN dbo.Users u ON u.UserId=@UserId AND u.IsActive=1 AND u.PostId=70 AND u.Mahal=r.ToMahal
  JOIN TahghighatV2.Referral h ON h.ReferralId=r.ParentReferralId
    AND h.ReceiverLevel='HOZE' AND h.IsDeleted=0
  JOIN dbo.Citys c ON c.CityId=r.ToMahal AND c.CityIdHozeh=h.ToMahal
  WHERE r.ReferralId=@CountyReferralId AND r.ReceiverLevel='SHAHR' AND r.IsDeleted=0
 ) THROW 55101,N'ارجاع در حوزه دسترسی نماینده شهرستان نیست.',1;
 SELECT a.AssignmentId,a.ReferralId,a.InvestigatorId InvestigatorKey,ir.AuthUserId,ir.PersonId,
  LTRIM(RTRIM(CONCAT(ISNULL(p.FirstName,N''),N' ',ISNULL(p.LastName,N'')))) FullName,
  a.Instruction,a.StatusCode,a.DueDatePersian,a.Summary,a.CreatedAtUtc,a.FinishedAtUtc,
  (SELECT COUNT_BIG(*) FROM TahghighatV2.ResearchWorksheet w WHERE w.AssignmentId=a.AssignmentId) WorksheetCount
 FROM TahghighatV2.ResearchAssignment a
 JOIN TahghighatV2.InvestigatorRegistry ir ON ir.InvestigatorKey=a.InvestigatorId
 LEFT JOIN dbo.Person p ON p.PersonId=ir.PersonId
 WHERE a.ReferralId=@CountyReferralId ORDER BY a.AssignmentId DESC;
END;
GO
CREATE OR ALTER PROCEDURE [TahghighatV2].[SP_GetCountyInvestigatorCandidates]
 @CountyReferralId bigint,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @County int,@Hoze int,@Post int;
 SELECT @County=Mahal,@Post=PostId FROM dbo.Users WHERE UserId=@UserId AND IsActive=1;
 SELECT @Hoze=h.ToMahal FROM TahghighatV2.Referral r
 JOIN TahghighatV2.Referral h ON h.ReferralId=r.ParentReferralId AND h.ReceiverLevel='HOZE' AND h.IsDeleted=0
 WHERE r.ReferralId=@CountyReferralId AND r.ReceiverLevel='SHAHR' AND r.ToMahal=@County AND r.IsDeleted=0;
 IF @Post<>70 OR NOT EXISTS (
  SELECT 1 FROM TahghighatV2.Referral r
  JOIN dbo.Users u ON u.UserId=@UserId AND u.IsActive=1 AND u.PostId=70 AND u.Mahal=r.ToMahal
  JOIN TahghighatV2.Referral h ON h.ReferralId=r.ParentReferralId
    AND h.ReceiverLevel='HOZE' AND h.IsDeleted=0
  JOIN dbo.Citys c ON c.CityId=r.ToMahal AND c.CityIdHozeh=h.ToMahal
  WHERE r.ReferralId=@CountyReferralId AND r.ReceiverLevel='SHAHR' AND r.IsDeleted=0
 ) THROW 55101,N'ارجاع در حوزه دسترسی نماینده شهرستان نیست.',1;
 SELECT p.PersonId, reg.InvestigatorKey, reg.AuthUserId,c.CityId CountyCityId,c.Name CountyName,
   LTRIM(RTRIM(CONCAT(ISNULL(p.FirstName,N''),N' ',ISNULL(p.LastName,N'')))) FullName,
   CONVERT(bit,CASE WHEN EXISTS(
    SELECT 1 FROM TahghighatV2.ResearchAssignment a
    JOIN TahghighatV2.InvestigatorRegistry ir ON ir.InvestigatorKey=a.InvestigatorId
    WHERE a.ReferralId=@CountyReferralId AND ir.PersonId=p.PersonId AND a.StatusCode<>'CANCELLED')
    OR (reg.InvestigatorKey IS NOT NULL AND reg.IsActive=0)
    OR (reg.InvestigatorKey IS NOT NULL AND EXISTS(SELECT 1 FROM TahghighatV2.CountyInvestigator ci
       WHERE ci.InvestigatorKey=reg.InvestigatorKey AND ci.CountyCityId=@County AND ci.IsActive=0))
    THEN 0 ELSE 1 END) IsAssignable
 FROM dbo.Person p JOIN dbo.Citys c ON c.CityId=@County AND c.IsActive=1
 CROSS APPLY (SELECT TOP(1) h.PersonId FROM Hamkari.PersonHamkari h
  WHERE h.PersonId=p.PersonId AND h.MahalHamkari=@County AND h.NoeHamkari=2
   AND ISNULL(h.IsActive,0)=1 AND ISNULL(h.IsDeleted,0)=0 ORDER BY h.PersonId) cooperation
 OUTER APPLY (SELECT TOP(1) ir.InvestigatorKey,ir.AuthUserId,ir.IsActive
  FROM TahghighatV2.InvestigatorRegistry ir
  WHERE ir.PersonId=p.PersonId AND ir.ProvinceCityId=c.PCityId
  ORDER BY ir.IsActive DESC,ir.InvestigatorKey) reg
 WHERE ISNULL(p.IsDelete,0)=0 ORDER BY FullName,p.PersonId;
END;
GO
