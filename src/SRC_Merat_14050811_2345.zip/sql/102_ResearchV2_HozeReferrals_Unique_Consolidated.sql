﻿/* Merat V2 - consolidated for user final source (phase 97), plus no duplicate county/person referrals (phase 102). Run this SQL only. */
USE [MeratDB];
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
/* Phase 88: scoped HOZE workflow. Existing county and province assignments are not modified. */
IF OBJECT_ID(N'TahghighatV2.Referral',N'U') IS NULL
 OR OBJECT_ID(N'TahghighatV2.ResearchAssignment',N'U') IS NULL
 OR OBJECT_ID(N'TahghighatV2.InvestigatorRegistry',N'U') IS NULL
 OR OBJECT_ID(N'TahghighatV2.CountyInvestigator',N'U') IS NULL
 THROW 54880,N'جداول پایه V2 یافت نشدند؛ ابتدا دیتابیس را کنترل کنید.',1;
GO
/* Register new audit actions before inserting events (FK_MRV2_Event_Action). */
INSERT TahghighatV2.WorkflowAction(ActionCode,TitleFa)
SELECT v.ActionCode,v.TitleFa
FROM (VALUES
 ('HOZE_REFER_COUNTY',N'ارجاع به شهرستان فرعی'),
 ('HOZE_ASSIGN_INVESTIGATOR',N'انتساب محقق توسط حوزه انتخابیه'),
 ('HOZE_CANCEL_ASSIGNMENT',N'بازپسگیری محقق حوزه'),
 ('HOZE_INVESTIGATOR_START',N'شروع تحقیق محقق حوزه'),
 ('HOZE_INVESTIGATOR_DONE',N'تکمیل تحقیق محقق حوزه'),
 ('HOZE_SAVE_WORKSHEET',N'ثبت کاربرگ محقق حوزه')
) v(ActionCode,TitleFa)
WHERE NOT EXISTS(SELECT 1 FROM TahghighatV2.WorkflowAction a WHERE a.ActionCode=v.ActionCode);
GO
/* Permit the default HOZE officer to refer counties only if no explicit policy exists.
   Explicitly denied permissions (IsAllowed=0) are not overwritten. */
IF EXISTS(SELECT 1 FROM TahghighatV2.WorkflowAction WHERE ActionCode='HOZE_REFER_COUNTY')
 AND NOT EXISTS(SELECT 1 FROM TahghighatV2.PostActionPermission WHERE PostId=61 AND ActionCode='HOZE_REFER_COUNTY')
 INSERT TahghighatV2.PostActionPermission(PostId,ActionCode,IsAllowed) VALUES(61,'HOZE_REFER_COUNTY',1);
GO
/* Phase 92: grant the county-referral deletion action separately from creation. */
IF NOT EXISTS (SELECT 1 FROM TahghighatV2.WorkflowAction WHERE ActionCode='HOZE_DELETE_COUNTY_REFERRAL')
 INSERT TahghighatV2.WorkflowAction(ActionCode,TitleFa)
 VALUES ('HOZE_DELETE_COUNTY_REFERRAL',N'حذف ارجاع شهرستان فرعی قبل از اقدام مقصد');
GO
IF NOT EXISTS (SELECT 1 FROM TahghighatV2.PostActionPermission WHERE PostId=61 AND ActionCode='HOZE_DELETE_COUNTY_REFERRAL')
 INSERT TahghighatV2.PostActionPermission(PostId,ActionCode,IsAllowed)
 VALUES (61,'HOZE_DELETE_COUNTY_REFERRAL',1);
GO
/* Display-only operations must not depend on the permission for *creating* county referrals. */
CREATE OR ALTER PROCEDURE TahghighatV2.SP_GetHozeCountyChoices
 @HozeReferralId bigint,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @Hoze int,@Post int;
 SELECT @Hoze=u.Mahal,@Post=u.PostId FROM dbo.Users u WHERE u.UserId=@UserId AND u.IsActive=1;
 IF ISNULL(@Post,0) NOT IN(60,61) OR NOT EXISTS(
  SELECT 1 FROM TahghighatV2.Referral h JOIN dbo.Citys center ON center.CityId=h.ToMahal
  WHERE h.ReferralId=@HozeReferralId AND h.ReceiverLevel='HOZE' AND h.ToMahal=@Hoze
    AND h.IsDeleted=0 AND center.IsHoze=1 AND center.IsActive=1)
  THROW 54881,N'ارجاع حوزه در محدوده دسترسی شما نیست.',1;
 SELECT c.CityId CountyCityId,c.Name CountyName,c.CityIdHozeh HozeCityId,
  (SELECT COUNT_BIG(*) FROM TahghighatV2.CountyRepresentative cr
    JOIN dbo.Users u ON u.UserId=cr.AuthUserId AND u.IsActive=1 AND u.Mahal=c.CityId
    WHERE cr.CountyCityId=c.CityId AND cr.HozeCityId=@Hoze AND cr.IsActive=1) ActiveRepresentatives
 FROM dbo.Citys c JOIN dbo.Citys center ON center.CityId=@Hoze
 WHERE c.IsHoze=0 AND c.IsActive=1 AND c.CityIdHozeh=@Hoze AND c.PCityId=center.PCityId
  AND NOT EXISTS (
    SELECT 1 FROM TahghighatV2.Referral prev
    WHERE prev.ParentReferralId=@HozeReferralId AND prev.ToMahal=c.CityId
      AND prev.ReceiverLevel='SHAHR' AND prev.IsDeleted=0
  )
 ORDER BY c.Name,c.CityId;
END;
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_GetHozeCountyReferrals
 @HozeReferralId bigint,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @Hoze int,@Post int;
 SELECT @Hoze=u.Mahal,@Post=u.PostId FROM dbo.Users u WHERE u.UserId=@UserId AND u.IsActive=1;
 IF ISNULL(@Post,0) NOT IN(60,61) OR NOT EXISTS(
  SELECT 1 FROM TahghighatV2.Referral h WHERE h.ReferralId=@HozeReferralId
  AND h.ToMahal=@Hoze AND h.ReceiverLevel='HOZE' AND h.IsDeleted=0)
  THROW 54882,N'فهرست ارجاعات شهرستان در محدوده دسترسی شما نیست.',1;
 SELECT r.ReferralId CountyReferralId,r.ToMahal CountyCityId,city.Name CountyName,
  r.StateCode,r.IsClosed,r.Description,r.CreatedAtUtc,r.UpdatedAtUtc,
  s.SummaryText CountySummaryText,
  (SELECT COUNT_BIG(*) FROM TahghighatV2.ResearchAssignment a
    WHERE a.ReferralId=r.ReferralId AND a.StatusCode IN('PENDING','IN_PROGRESS')) OpenAssignments,
  CONVERT(bit,CASE WHEN @Post=61
    AND EXISTS (SELECT 1 FROM TahghighatV2.PostActionPermission ap
      WHERE ap.PostId=@Post AND ap.ActionCode='HOZE_DELETE_COUNTY_REFERRAL' AND ap.IsAllowed=1)
    AND h.StateCode='CHILD_WORKING' AND h.IsClosed=0 AND h.IsDeleted=0
    AND root.StateCode='PENDING_CHILD_RESULTS' AND root.IsClosed=0 AND root.IsDeleted=0
    AND r.ReceiverLevel='SHAHR' AND r.StateCode='CHILD_INBOX' AND r.IsClosed=0
    AND EXISTS (SELECT 1 FROM TahghighatV2.WorkflowEvent e
      WHERE e.ReferralId=r.ReferralId AND e.ActionCode='CHILD_CREATED')
    AND NOT EXISTS (SELECT 1 FROM TahghighatV2.WorkflowEvent e
      WHERE e.ReferralId=r.ReferralId AND e.ActionCode<>'CHILD_CREATED')
    AND NOT EXISTS (SELECT 1 FROM TahghighatV2.Referral descendants WHERE descendants.ParentReferralId=r.ReferralId)
    AND NOT EXISTS (SELECT 1 FROM TahghighatV2.ResearchAssignment a WHERE a.ReferralId=r.ReferralId)
    AND NOT EXISTS (SELECT 1 FROM TahghighatV2.CountySummary cs WHERE cs.ReferralId=r.ReferralId)
    AND NOT EXISTS (SELECT 1 FROM TahghighatV2.NoResearchDecision nr WHERE nr.ReferralId=r.ReferralId)
    THEN 1 ELSE 0 END) CanDelete
 FROM TahghighatV2.Referral r LEFT JOIN dbo.Citys city ON city.CityId=r.ToMahal
 LEFT JOIN TahghighatV2.CountySummary s ON s.ReferralId=r.ReferralId
 LEFT JOIN TahghighatV2.Referral h ON h.ReferralId=r.ParentReferralId
 LEFT JOIN TahghighatV2.Referral root ON root.ReferralId=h.ParentReferralId
 WHERE r.ParentReferralId=@HozeReferralId AND r.ReceiverLevel='SHAHR' AND r.IsDeleted=0
 ORDER BY r.ReferralId DESC;
END;
GO
/* The chair of the constituency (post 60) can read completed work; only post 61 edits. */
CREATE OR ALTER PROCEDURE TahghighatV2.SP_GetHozeConsolidation
 @HozeReferralId bigint,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @Mahal int,@Post int;
 SELECT @Mahal=u.Mahal,@Post=u.PostId FROM dbo.Users u WHERE u.UserId=@UserId AND u.IsActive=1;
 IF ISNULL(@Post,0) NOT IN(60,61) OR NOT EXISTS(
   SELECT 1 FROM TahghighatV2.Referral h
   WHERE h.ReferralId=@HozeReferralId AND h.ToMahal=@Mahal AND h.ReceiverLevel='HOZE' AND h.IsDeleted=0)
  THROW 54910,N'دسترسی به جمع‌بندی حوزه مجاز نیست.',1;
 SELECT h.ReferralId HozeReferralId,h.StateCode HozeState,hs.SummaryId HozeSummaryId,
  hs.SummaryText HozeSummaryText,c.ReferralId CountyReferralId,c.ToMahal CountyCityId,
  city.Name CountyName,c.StateCode CountyState,c.IsClosed CountyIsClosed,
  cs.SummaryId CountySummaryId,cs.SummaryText CountySummaryText,
  (SELECT COUNT_BIG(*) FROM TahghighatV2.ResearchAssignment a WHERE a.ReferralId=c.ReferralId) InvestigatorCount,
  (SELECT COUNT_BIG(*) FROM TahghighatV2.ResearchAssignment a
   WHERE a.ReferralId=c.ReferralId AND a.StatusCode IN('PENDING','IN_PROGRESS')) OpenAssignments
 FROM TahghighatV2.Referral h LEFT JOIN TahghighatV2.HozeSummary hs ON hs.ReferralId=h.ReferralId
 LEFT JOIN TahghighatV2.Referral c ON c.ParentReferralId=h.ReferralId
  AND c.ReceiverLevel='SHAHR' AND c.IsDeleted=0
 LEFT JOIN dbo.Citys city ON city.CityId=c.ToMahal
 LEFT JOIN TahghighatV2.CountySummary cs ON cs.ReferralId=c.ReferralId
 WHERE h.ReferralId=@HozeReferralId AND h.ToMahal=@Mahal AND h.ReceiverLevel='HOZE' AND h.IsDeleted=0
 ORDER BY c.ReferralId;
END;
GO
/* Single source of truth for header buttons and case identity. */
CREATE OR ALTER PROCEDURE TahghighatV2.SP_GetHozeCaseDetail
 @HozeReferralId bigint,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @Mahal int,@Post int;
 SELECT @Mahal=Mahal,@Post=PostId FROM dbo.Users WHERE UserId=@UserId AND IsActive=1;
 IF ISNULL(@Post,0) NOT IN(60,61) THROW 54883,N'سمت کاربر مجاز حوزه نیست.',1;
 SELECT h.ReferralId,h.ParentReferralId,h.StateCode,h.Description,h.CreatedAtUtc,h.IsClosed,
  cf.ShomarehParvandeh,cf.CodeHozeh,cf.CodeEntekhabat,city.Name HozeName,
  applicant.FirstName,applicant.LastName,applicant.NamePedar,
  NULLIF(LEFT(LTRIM(RTRIM(applicant.TarikhTavalod)),4),N'') SalTavalod,
  CONVERT(bit,CASE WHEN @Post=61 AND h.StateCode='CHILD_INBOX' AND h.IsClosed=0
   AND parent.StateCode='PENDING_CHILD_RESULTS' AND parent.IsClosed=0 THEN 1 ELSE 0 END) CanStart,
  CONVERT(bit,CASE WHEN @Post=61 AND h.StateCode='CHILD_WORKING' AND h.IsClosed=0
   AND parent.StateCode='PENDING_CHILD_RESULTS' AND parent.IsClosed=0
   AND EXISTS(SELECT 1 FROM TahghighatV2.PostActionPermission perm WHERE perm.PostId=61
    AND perm.ActionCode='HOZE_REFER_COUNTY' AND perm.IsAllowed=1)
   THEN 1 ELSE 0 END) CanReferCounty,
  CONVERT(bit,CASE WHEN @Post=61 AND h.StateCode='CHILD_WORKING' AND h.IsClosed=0
   AND parent.StateCode='PENDING_CHILD_RESULTS' AND parent.IsClosed=0 THEN 1 ELSE 0 END) CanWork,
  (SELECT COUNT_BIG(*) FROM TahghighatV2.Referral c
   WHERE c.ParentReferralId=h.ReferralId AND c.IsDeleted=0 AND c.IsClosed=0) OpenCounties,
  (SELECT COUNT_BIG(*) FROM TahghighatV2.ResearchAssignment a
   WHERE a.ReferralId=h.ReferralId AND a.StatusCode IN('PENDING','IN_PROGRESS')) OpenInvestigators,
  hs.SummaryText HozeSummaryText
 FROM TahghighatV2.Referral h JOIN TahghighatV2.Referral parent ON parent.ReferralId=h.ParentReferralId
 JOIN TahghighatV2.CaseFile cf ON cf.CaseId=h.CaseId
 JOIN dbo.Citys city ON city.CityId=h.ToMahal AND city.IsHoze=1 AND city.IsActive=1
 OUTER APPLY(SELECT TOP(1) a.FirstName,a.LastName,a.NamePedar,a.TarikhTavalod
   FROM Davtalab.Ashkhas a WHERE a.ShomarehParvandeh=cf.ShomarehParvandeh
    AND ISNULL(a.IsDelete,0)=0) applicant
 LEFT JOIN TahghighatV2.HozeSummary hs ON hs.ReferralId=h.ReferralId
 WHERE h.ReferralId=@HozeReferralId AND h.ToMahal=@Mahal AND h.ReceiverLevel='HOZE' AND h.IsDeleted=0;
END;
GO
/* Investigator candidates are approved county investigators inside the current HOZE. */
CREATE OR ALTER PROCEDURE TahghighatV2.SP_GetHozeInvestigatorCandidates
 @HozeReferralId bigint,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @Mahal int,@Post int;
 SELECT @Mahal=u.Mahal,@Post=u.PostId FROM dbo.Users u WHERE u.UserId=@UserId AND u.IsActive=1;
 IF ISNULL(@Post,0)<>61 OR NOT EXISTS(SELECT 1 FROM TahghighatV2.Referral r
   WHERE r.ReferralId=@HozeReferralId AND r.ToMahal=@Mahal AND r.ReceiverLevel='HOZE'
   AND r.StateCode='CHILD_WORKING' AND r.IsClosed=0 AND r.IsDeleted=0)
  THROW 54884,N'این پرونده در مرحله انتساب محقق حوزه نیست.',1;
 SELECT DISTINCT ci.InvestigatorKey,ir.AuthUserId,ci.CountyCityId,city.Name CountyName,
  LTRIM(RTRIM(CONCAT(ISNULL(p.FirstName,N''),N' ',ISNULL(p.LastName,N'')))) FullName
 FROM TahghighatV2.CountyInvestigator ci
 JOIN dbo.Citys city ON city.CityId=ci.CountyCityId AND city.IsActive=1
  AND (city.CityIdHozeh=@Mahal OR city.CityId=@Mahal)
 JOIN TahghighatV2.InvestigatorRegistry ir ON ir.InvestigatorKey=ci.InvestigatorKey
  AND ir.IsActive=1 AND ir.AuthUserId IS NOT NULL
 JOIN dbo.Users u ON u.UserId=ir.AuthUserId AND u.IsActive=1 AND u.Mahal=ci.CountyCityId
 LEFT JOIN dbo.Person p ON p.PersonId=ir.PersonId
 WHERE ci.IsActive=1 AND ir.ProvinceCityId=city.PCityId
 ORDER BY FullName,ci.InvestigatorKey;
END;
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_GetHozeAssignments
 @HozeReferralId bigint,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @Mahal int,@Post int;
 SELECT @Mahal=u.Mahal,@Post=u.PostId FROM dbo.Users u WHERE u.UserId=@UserId AND u.IsActive=1;
 IF ISNULL(@Post,0) NOT IN(60,61) OR NOT EXISTS(SELECT 1 FROM TahghighatV2.Referral r
  WHERE r.ReferralId=@HozeReferralId AND r.ToMahal=@Mahal AND r.ReceiverLevel='HOZE' AND r.IsDeleted=0)
  THROW 54885,N'مجوز مشاهده محققان حوزه وجود ندارد.',1;
 SELECT a.AssignmentId,a.InvestigatorId InvestigatorKey,ir.PersonId,a.StatusCode,a.Instruction,a.Summary,
  a.DueDatePersian,a.CreatedAtUtc,a.FinishedAtUtc,
  LTRIM(RTRIM(CONCAT(ISNULL(p.FirstName,N''),N' ',ISNULL(p.LastName,N'')))) FullName,
  (SELECT COUNT_BIG(*) FROM TahghighatV2.ResearchWorksheet w WHERE w.AssignmentId=a.AssignmentId) WorksheetCount
 FROM TahghighatV2.ResearchAssignment a
 JOIN TahghighatV2.InvestigatorRegistry ir ON ir.InvestigatorKey=a.InvestigatorId
 LEFT JOIN dbo.Person p ON p.PersonId=ir.PersonId
 WHERE a.ReferralId=@HozeReferralId ORDER BY a.AssignmentId DESC;
END;
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_HozeAssignInvestigator
 @HozeReferralId bigint,@InvestigatorKey bigint,@Instruction nvarchar(max),
 @DueDatePersian char(10)=NULL,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 IF @HozeReferralId<=0 OR @InvestigatorKey<=0 OR @UserId<=0
  OR NULLIF(LTRIM(RTRIM(@Instruction)),N'') IS NULL OR LEN(@Instruction)>6000
  THROW 54886,N'اطلاعات انتساب کامل نیست.',1;
 DECLARE @Mahal int,@Post int,@Root bigint,@State varchar(40),@Lock int,@NewId bigint;
 SELECT @Mahal=Mahal,@Post=PostId FROM dbo.Users WHERE UserId=@UserId AND IsActive=1;
 IF ISNULL(@Post,0)<>61 OR NOT EXISTS(SELECT 1 FROM dbo.Citys c WHERE c.CityId=@Mahal AND c.IsHoze=1 AND c.IsActive=1)
  THROW 54887,N'کاربر مجاز حوزه انتخابیه نیست.',1;
 IF NOT EXISTS(SELECT 1 FROM TahghighatV2.CountyInvestigator ci
  JOIN dbo.Citys c ON c.CityId=ci.CountyCityId AND c.IsActive=1
   AND c.CityIdHozeh=@Mahal
  JOIN TahghighatV2.InvestigatorRegistry ir ON ir.InvestigatorKey=ci.InvestigatorKey
   AND ir.IsActive=1 AND ir.AuthUserId IS NOT NULL AND ir.ProvinceCityId=c.PCityId
  JOIN dbo.Users u ON u.UserId=ir.AuthUserId AND u.IsActive=1 AND u.Mahal=ci.CountyCityId
  WHERE ci.InvestigatorKey=@InvestigatorKey AND ci.IsActive=1)
  THROW 54888,N'محقق فعال و تأییدشده در حوزه انتخابیه یافت نشد.',1;
 SELECT @Root=r.ParentReferralId FROM TahghighatV2.Referral r WHERE r.ReferralId=@HozeReferralId
  AND r.ToMahal=@Mahal AND r.ReceiverLevel='HOZE' AND r.IsDeleted=0;
 IF @Root IS NULL THROW 54889,N'ارجاع حوزه معتبر نیست.',1;
 BEGIN TRY
 BEGIN TRANSACTION;
 DECLARE @LockName nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(20),@Root);
 EXEC @Lock=sys.sp_getapplock @Resource=@LockName,
  @LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @Lock<0 THROW 54890,N'پرونده در حال پردازش است.',1;
 SELECT @State=r.StateCode FROM TahghighatV2.Referral r WITH(UPDLOCK,HOLDLOCK)
 JOIN TahghighatV2.Referral p ON p.ReferralId=r.ParentReferralId
 WHERE r.ReferralId=@HozeReferralId AND r.ToMahal=@Mahal AND r.IsClosed=0 AND r.IsDeleted=0
 AND p.ReferralId=@Root AND p.StateCode='PENDING_CHILD_RESULTS' AND p.IsClosed=0 AND p.IsDeleted=0;
 IF @State<>'CHILD_WORKING' OR @State IS NULL THROW 54891,N'ارجاع حوزه در مرحله بررسی فعال نیست.',1;
 IF EXISTS(SELECT 1 FROM TahghighatV2.ResearchAssignment a WITH(UPDLOCK,HOLDLOCK)
  WHERE a.ReferralId=@HozeReferralId AND a.InvestigatorId=@InvestigatorKey AND a.StatusCode IN('PENDING','IN_PROGRESS'))
  THROW 54892,N'برای همین محقق انتساب باز وجود دارد.',1;
 INSERT TahghighatV2.ResearchAssignment(ReferralId,InvestigatorId,DueDatePersian,Instruction,StatusCode,CreatedByUserId)
 VALUES(@HozeReferralId,@InvestigatorKey,@DueDatePersian,@Instruction,'PENDING',@UserId);
 SET @NewId=CONVERT(bigint,SCOPE_IDENTITY());
 INSERT TahghighatV2.ResearchAssignmentEvent(AssignmentId,ActionCode,BeforeStatus,AfterStatus,Description,ActorUserId)
 VALUES(@NewId,'HOZE_ASSIGN_INVESTIGATOR',NULL,'PENDING',@Instruction,@UserId);
 INSERT TahghighatV2.WorkflowEvent(ReferralId,ActionCode,PreviousStateCode,NewStateCode,Description,ActorUserId)
 VALUES(@HozeReferralId,'HOZE_ASSIGN_INVESTIGATOR',@State,@State,@Instruction,@UserId);
 COMMIT;
 SELECT CONVERT(bit,1) IsSuccess,@NewId AssignmentId;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK;THROW;END CATCH;
END;
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_HozeCancelAssignment
 @AssignmentId bigint,@Reason nvarchar(max),@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 IF @AssignmentId<=0 OR @UserId<=0 OR NULLIF(LTRIM(RTRIM(@Reason)),N'') IS NULL
 THROW 54893,N'انتساب و علت بازپسگیری الزامی است.',1;
 DECLARE @Root bigint,@Hoze bigint,@State varchar(40),@Status varchar(20),@Lock int;
 SELECT @Hoze=r.ReferralId,@Root=r.ParentReferralId FROM TahghighatV2.ResearchAssignment a
 JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId
 JOIN dbo.Users u ON u.UserId=@UserId AND u.IsActive=1 AND u.PostId=61 AND u.Mahal=r.ToMahal
 WHERE a.AssignmentId=@AssignmentId AND r.ReceiverLevel='HOZE' AND r.IsDeleted=0;
 IF @Root IS NULL THROW 54894,N'این محقق در حوزه دسترسی شما نیست.',1;
 BEGIN TRY BEGIN TRANSACTION;
 DECLARE @LockName nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(20),@Root);
 EXEC @Lock=sys.sp_getapplock @Resource=@LockName,
 @LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @Lock<0 THROW 54895,N'پرونده در حال پردازش است.',1;
 SELECT @State=r.StateCode,@Status=a.StatusCode FROM TahghighatV2.ResearchAssignment a WITH(UPDLOCK,HOLDLOCK)
 JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId
 JOIN TahghighatV2.Referral p ON p.ReferralId=r.ParentReferralId
 WHERE a.AssignmentId=@AssignmentId AND r.ReferralId=@Hoze AND r.IsClosed=0 AND r.IsDeleted=0
 AND p.StateCode='PENDING_CHILD_RESULTS' AND p.IsClosed=0 AND p.IsDeleted=0;
 IF @State<>'CHILD_WORKING' OR @Status NOT IN('PENDING','IN_PROGRESS')
 THROW 54896,N'بازپسگیری فقط برای انتساب فعال مجاز است.',1;
 UPDATE TahghighatV2.ResearchAssignment SET StatusCode='CANCELLED',FinishedAtUtc=SYSUTCDATETIME() WHERE AssignmentId=@AssignmentId;
 INSERT TahghighatV2.ResearchAssignmentEvent(AssignmentId,ActionCode,BeforeStatus,AfterStatus,Description,ActorUserId)
 VALUES(@AssignmentId,'HOZE_CANCEL_ASSIGNMENT',@Status,'CANCELLED',@Reason,@UserId);
 INSERT TahghighatV2.WorkflowEvent(ReferralId,ActionCode,PreviousStateCode,NewStateCode,Description,ActorUserId)
 VALUES(@Hoze,'HOZE_CANCEL_ASSIGNMENT','CHILD_WORKING','CHILD_WORKING',@Reason,@UserId);
 COMMIT; SELECT CONVERT(bit,1) IsSuccess;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK;THROW;END CATCH;
END;
GO
/* Authenticated investigator-only text worksheet lifecycle; does not reuse old V1 tables. */
CREATE OR ALTER PROCEDURE TahghighatV2.SP_GetHozeInvestigatorInbox
 @UserId bigint,@Page int=1,@PageSize int=25
AS
BEGIN
 SET NOCOUNT ON;
 IF @Page<1 OR @PageSize NOT BETWEEN 1 AND 100 THROW 54897,N'صفحه‌بندی نامعتبر است.',1;
 SELECT a.AssignmentId,a.ReferralId,a.StatusCode,a.Instruction,a.DueDatePersian,a.CreatedAtUtc,
  cf.ShomarehParvandeh,cf.CodeHozeh,r.ToMahal HozeCityId
 FROM TahghighatV2.ResearchAssignment a
 JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId AND r.ReceiverLevel='HOZE'
 JOIN TahghighatV2.CaseFile cf ON cf.CaseId=r.CaseId
 JOIN TahghighatV2.InvestigatorRegistry ir ON ir.InvestigatorKey=a.InvestigatorId AND ir.IsActive=1 AND ir.AuthUserId=@UserId
 JOIN dbo.Users u ON u.UserId=@UserId AND u.IsActive=1
 WHERE r.IsClosed=0 AND r.IsDeleted=0 AND a.StatusCode IN('PENDING','IN_PROGRESS')
 AND EXISTS (SELECT 1 FROM TahghighatV2.CountyInvestigator ci
   JOIN dbo.Citys city ON city.CityId=ci.CountyCityId AND city.IsActive=1 AND city.CityIdHozeh=r.ToMahal
   WHERE ci.InvestigatorKey=ir.InvestigatorKey AND ci.IsActive=1 AND u.Mahal=ci.CountyCityId)
 ORDER BY a.CreatedAtUtc DESC OFFSET (CONVERT(bigint,@Page)-1)*@PageSize ROWS FETCH NEXT @PageSize ROWS ONLY;
END;
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_GetHozeWorksheets
 @AssignmentId bigint,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 IF NOT EXISTS(SELECT 1 FROM TahghighatV2.ResearchAssignment a
 JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId AND r.ReceiverLevel='HOZE' AND r.IsDeleted=0
 JOIN dbo.Users u ON u.UserId=@UserId AND u.IsActive=1
 WHERE a.AssignmentId=@AssignmentId AND
  ((u.PostId IN(60,61) AND u.Mahal=r.ToMahal) OR
   EXISTS(SELECT 1 FROM TahghighatV2.InvestigatorRegistry ir
    JOIN TahghighatV2.CountyInvestigator ci ON ci.InvestigatorKey=ir.InvestigatorKey AND ci.IsActive=1
    JOIN dbo.Citys city ON city.CityId=ci.CountyCityId AND city.CityIdHozeh=r.ToMahal AND city.IsActive=1
    WHERE ir.InvestigatorKey=a.InvestigatorId AND ir.IsActive=1 AND ir.AuthUserId=@UserId AND u.Mahal=ci.CountyCityId)))
 THROW 54898,N'دسترسی به کاربرگ محقق حوزه مجاز نیست.',1;
 SELECT WorksheetId,AssignmentId,ReportText,CreatedAtUtc,CreatedByUserId
 FROM TahghighatV2.ResearchWorksheet WHERE AssignmentId=@AssignmentId ORDER BY WorksheetId;
END;
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_HozeInvestigatorAction
 @AssignmentId bigint,@ActionCode varchar(40),@Summary nvarchar(max)=NULL,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 IF @AssignmentId<=0 OR @UserId<=0 OR @ActionCode NOT IN('HOZE_INVESTIGATOR_START','HOZE_INVESTIGATOR_DONE')
 THROW 54899,N'اقدام محقق حوزه نامعتبر است.',1;
 IF @ActionCode='HOZE_INVESTIGATOR_DONE' AND NULLIF(LTRIM(RTRIM(@Summary)),N'') IS NULL
 THROW 54900,N'جمع‌بندی محقق برای تکمیل اجباری است.',1;
 DECLARE @Hoze bigint,@Root bigint,@Status varchar(20),@Key bigint,@Lock int;
 SELECT @Hoze=r.ReferralId,@Root=r.ParentReferralId FROM TahghighatV2.ResearchAssignment a
 JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId AND r.ReceiverLevel='HOZE'
 WHERE a.AssignmentId=@AssignmentId;
 IF @Root IS NULL THROW 54901,N'انتساب حوزه نامعتبر است.',1;
 BEGIN TRY BEGIN TRANSACTION;
 DECLARE @LockName nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(20),@Root);
 EXEC @Lock=sys.sp_getapplock @Resource=@LockName,
 @LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @Lock<0 THROW 54902,N'پرونده در حال پردازش است.',1;
 SELECT @Status=a.StatusCode,@Key=a.InvestigatorId FROM TahghighatV2.ResearchAssignment a WITH(UPDLOCK,HOLDLOCK)
 JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId
 JOIN TahghighatV2.Referral p ON p.ReferralId=r.ParentReferralId
 WHERE a.AssignmentId=@AssignmentId AND r.ReferralId=@Hoze AND r.StateCode='CHILD_WORKING'
 AND r.IsClosed=0 AND r.IsDeleted=0 AND p.StateCode='PENDING_CHILD_RESULTS' AND p.IsClosed=0 AND p.IsDeleted=0;
 IF @Status IS NULL OR NOT EXISTS(SELECT 1 FROM TahghighatV2.InvestigatorRegistry ir
 JOIN TahghighatV2.CountyInvestigator ci ON ci.InvestigatorKey=ir.InvestigatorKey AND ci.IsActive=1
 JOIN dbo.Citys city ON city.CityId=ci.CountyCityId AND city.CityIdHozeh=(SELECT ToMahal FROM TahghighatV2.Referral WHERE ReferralId=@Hoze)
 JOIN dbo.Users u ON u.UserId=@UserId AND u.IsActive=1 AND u.Mahal=ci.CountyCityId
 WHERE ir.InvestigatorKey=@Key AND ir.IsActive=1 AND ir.AuthUserId=@UserId)
 THROW 54903,N'محقق مجاز این انتساب نیستید.',1;
 IF (@ActionCode='HOZE_INVESTIGATOR_START' AND @Status<>'PENDING') OR
 (@ActionCode='HOZE_INVESTIGATOR_DONE' AND @Status<>'IN_PROGRESS')
 THROW 54904,N'وضعیت انتساب برای اقدام مجاز نیست.',1;
 IF @ActionCode='HOZE_INVESTIGATOR_DONE' AND NOT EXISTS(SELECT 1 FROM TahghighatV2.ResearchWorksheet
 WHERE AssignmentId=@AssignmentId) THROW 54905,N'حداقل یک کاربرگ تحقیق الزامی است.',1;
 DECLARE @New varchar(20)=CASE WHEN @ActionCode='HOZE_INVESTIGATOR_START' THEN 'IN_PROGRESS' ELSE 'DONE' END;
 UPDATE TahghighatV2.ResearchAssignment SET StatusCode=@New,
 Summary=CASE WHEN @New='DONE' THEN @Summary ELSE Summary END,
 FinishedAtUtc=CASE WHEN @New='DONE' THEN SYSUTCDATETIME() ELSE FinishedAtUtc END WHERE AssignmentId=@AssignmentId;
 INSERT TahghighatV2.ResearchAssignmentEvent(AssignmentId,ActionCode,BeforeStatus,AfterStatus,Description,ActorUserId)
 VALUES(@AssignmentId,@ActionCode,@Status,@New,@Summary,@UserId);
 INSERT TahghighatV2.WorkflowEvent(ReferralId,ActionCode,PreviousStateCode,NewStateCode,Description,ActorUserId)
 VALUES(@Hoze,@ActionCode,'CHILD_WORKING','CHILD_WORKING',@Summary,@UserId);
 COMMIT; SELECT CONVERT(bit,1) IsSuccess;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK;THROW;END CATCH;
END;
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_HozeSaveWorksheet
 @AssignmentId bigint,@ReportText nvarchar(max),@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;SET XACT_ABORT ON;
 IF @AssignmentId<=0 OR @UserId<=0 OR NULLIF(LTRIM(RTRIM(@ReportText)),N'') IS NULL OR LEN(@ReportText)>12000
 THROW 54906,N'گزارش کاربرگ نامعتبر است.',1;
 DECLARE @Hoze bigint,@Root bigint,@Status varchar(20),@Lock int,@Id bigint;
 SELECT @Hoze=r.ReferralId,@Root=r.ParentReferralId FROM TahghighatV2.ResearchAssignment a
 JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId AND r.ReceiverLevel='HOZE'
 WHERE a.AssignmentId=@AssignmentId;
 IF @Root IS NULL THROW 54907,N'ارجاع محقق یافت نشد.',1;
 BEGIN TRY BEGIN TRANSACTION;
 DECLARE @LockName nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(20),@Root);
 EXEC @Lock=sys.sp_getapplock @Resource=@LockName,
 @LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
 IF @Lock<0 THROW 54908,N'پرونده در حال پردازش است.',1;
 SELECT @Status=a.StatusCode FROM TahghighatV2.ResearchAssignment a WITH(UPDLOCK,HOLDLOCK)
 JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId
 JOIN TahghighatV2.Referral p ON p.ReferralId=r.ParentReferralId
 JOIN TahghighatV2.InvestigatorRegistry ir ON ir.InvestigatorKey=a.InvestigatorId AND ir.AuthUserId=@UserId AND ir.IsActive=1
 JOIN TahghighatV2.CountyInvestigator ci ON ci.InvestigatorKey=ir.InvestigatorKey AND ci.IsActive=1
 JOIN dbo.Citys city ON city.CityId=ci.CountyCityId AND city.CityIdHozeh=r.ToMahal AND city.IsActive=1
 JOIN dbo.Users u ON u.UserId=@UserId AND u.IsActive=1 AND u.Mahal=ci.CountyCityId
 WHERE a.AssignmentId=@AssignmentId AND r.ReferralId=@Hoze AND r.StateCode='CHILD_WORKING'
 AND r.IsClosed=0 AND r.IsDeleted=0 AND p.StateCode='PENDING_CHILD_RESULTS' AND p.IsClosed=0 AND p.IsDeleted=0;
 IF @Status<>'IN_PROGRESS' OR @Status IS NULL THROW 54909,N'کاربرگ فقط برای محقق فعال قابل ثبت است.',1;
 INSERT TahghighatV2.ResearchWorksheet(AssignmentId,ReportText,CreatedByUserId)
 VALUES(@AssignmentId,@ReportText,@UserId);
 SET @Id=CONVERT(bigint,SCOPE_IDENTITY());
 INSERT TahghighatV2.ResearchAssignmentEvent(AssignmentId,ActionCode,BeforeStatus,AfterStatus,Description,ActorUserId)
 VALUES(@AssignmentId,'HOZE_SAVE_WORKSHEET',@Status,@Status,N'ثبت کاربرگ '+CONVERT(nvarchar(20),@Id),@UserId);
 COMMIT; SELECT CONVERT(bit,1) IsSuccess,@Id WorksheetId;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK;THROW;END CATCH;
END;
GO


/* Phase 89: align read-only HOZE inbox visibility with the province workflow UI.
   Roles 60 and 61 may READ only their own active HOZE referrals.
   Roles 51 and 52 retain their original permission requirement and province scope.
   No action/approval privilege is granted by this procedure. */
CREATE OR ALTER PROCEDURE TahghighatV2.SP_GetChildInbox
 @UserId bigint, @Page int=1, @PageSize int=25
AS
BEGIN
 SET NOCOUNT ON;
 IF @UserId IS NULL OR @UserId<=0 OR @Page IS NULL OR @Page<1 OR @PageSize NOT BETWEEN 1 AND 100
  THROW 53441,N'ورودی کارتابل ارجاعات فرعی نامعتبر است.',1;
 DECLARE @Mahal int,@PostId int;
 SELECT @Mahal=u.Mahal,@PostId=u.PostId FROM dbo.Users u WHERE u.UserId=@UserId AND u.IsActive=1;
 IF @Mahal IS NULL OR ISNULL(@PostId,0) NOT IN(51,52,60,61)
  THROW 53442,N'دسترسی به کارتابل ارجاعات فرعی مجاز نیست.',1;
 IF @PostId IN(51,52) AND NOT EXISTS(
  SELECT 1 FROM TahghighatV2.PostActionPermission p
  WHERE p.PostId=@PostId AND p.ActionCode='CHILD_REPLY' AND p.IsAllowed=1)
  THROW 53442,N'دسترسی به کارتابل ارجاعات فرعی مجاز نیست.',1;
 IF @PostId IN(60,61) AND NOT EXISTS(
  SELECT 1 FROM dbo.Citys center WHERE center.CityId=@Mahal AND center.IsActive=1 AND center.IsHoze=1)
  THROW 53442,N'محل خدمت با مرکز حوزه انتخابیه مطابقت ندارد.',1;
 SELECT r.ReferralId,r.ParentReferralId,r.FromMahal,r.ToMahal,r.ReceiverLevel,
  r.StateCode,r.Description,c.CaseId,c.CodeEntekhabat,c.CodeHozeh,
  c.ShomarehParvandeh,r.CreatedAtUtc,COUNT_BIG(*) OVER() TotalCount
 FROM TahghighatV2.Referral r JOIN TahghighatV2.CaseFile c ON c.CaseId=r.CaseId
 WHERE r.ParentReferralId IS NOT NULL AND r.ToMahal=@Mahal
   AND r.IsDeleted=0 AND r.IsClosed=0
   AND r.StateCode IN('CHILD_INBOX','CHILD_WORKING')
   AND ((r.ReceiverLevel='OSTAN' AND @PostId IN(51,52) AND EXISTS(
          SELECT 1 FROM dbo.Citys city WHERE city.CityId=@Mahal AND city.IsActive=1 AND city.PCityId=1))
     OR (r.ReceiverLevel='HOZE' AND @PostId IN(60,61)))
 ORDER BY r.CreatedAtUtc DESC,r.ReferralId DESC
 OFFSET (CONVERT(bigint,@Page)-1)*@PageSize ROWS FETCH NEXT @PageSize ROWS ONLY;
END;
GO

/* Phase 90: subordinate counties are valid referral destinations regardless of
   whether an active representative exists today. This does not grant anyone
   county read/action permission. A referral stays in CHILD_INBOX until an
   authorized representative is activated for the destination county.
   Keep all scope, role, state, duplicate-open and audit checks unchanged. */
CREATE OR ALTER PROCEDURE TahghighatV2.SP_HozeReferCounty
 @HozeReferralId bigint,@CountyCityId int,@Description nvarchar(max),@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 SET XACT_ABORT ON;
 IF @HozeReferralId IS NULL OR @HozeReferralId<=0 OR @CountyCityId IS NULL
  OR @CountyCityId<=0 OR @UserId IS NULL OR @UserId<=0
  OR NULLIF(LTRIM(RTRIM(@Description)),N'') IS NULL
  THROW 54010,N'حوزه، شهرستان، شرح ارجاع و کاربر الزامی‌اند.',1;
 DECLARE @Hoze int,@Post int,@RootId bigint,@CaseId bigint,@State varchar(40),@Lock int,@NewId bigint;
 SELECT @Hoze=u.Mahal,@Post=u.PostId FROM dbo.Users u WHERE u.UserId=@UserId AND u.IsActive=1;
 IF @Post<>61 OR NOT EXISTS(
   SELECT 1 FROM dbo.Citys c WHERE c.CityId=@Hoze AND c.IsHoze=1 AND c.IsActive=1)
  OR NOT EXISTS(
   SELECT 1 FROM TahghighatV2.PostActionPermission p
   WHERE p.PostId=@Post AND p.ActionCode='HOZE_REFER_COUNTY' AND p.IsAllowed=1)
  THROW 54011,N'کاربر مجاز حوزه اصلی نیست.',1;
 IF NOT EXISTS(
   SELECT 1 FROM dbo.Citys c JOIN dbo.Citys h ON h.CityId=@Hoze
   WHERE c.CityId=@CountyCityId AND c.IsActive=1 AND c.IsHoze=0
     AND c.CityIdHozeh=@Hoze AND c.PCityId=h.PCityId)
  THROW 54012,N'شهرستان انتخابی تابع حوزه اصلی نیست.',1;
 -- Deliberately no CountyRepresentative/Users requirement at referral creation.
 SELECT @RootId=ParentReferralId FROM TahghighatV2.Referral
  WHERE ReferralId=@HozeReferralId;
 IF @RootId IS NULL THROW 54014,N'ارجاع حوزه اصلی یافت نشد.',1;
 BEGIN TRY
  BEGIN TRANSACTION;
  DECLARE @LockName nvarchar(200)=N'MRV2:REF:'+CONVERT(nvarchar(20),@RootId);
  EXEC @Lock=sys.sp_getapplock @Resource=@LockName,@LockMode=N'Exclusive',
   @LockOwner=N'Transaction',@LockTimeout=10000;
  IF @Lock<0 THROW 54015,N'پرونده در حال پردازش است.',1;
  SELECT @CaseId=r.CaseId,@State=r.StateCode
  FROM TahghighatV2.Referral r WITH(UPDLOCK,HOLDLOCK)
  JOIN TahghighatV2.Referral p ON p.ReferralId=r.ParentReferralId
  WHERE r.ReferralId=@HozeReferralId AND r.ParentReferralId=@RootId
   AND r.ReceiverLevel='HOZE' AND r.ToMahal=@Hoze
   AND r.IsClosed=0 AND r.IsDeleted=0
   AND p.ParentReferralId IS NULL AND p.StateCode='PENDING_CHILD_RESULTS'
   AND p.IsClosed=0 AND p.IsDeleted=0;
  IF @State<>'CHILD_WORKING' OR @State IS NULL
   THROW 54016,N'حوزه باید در وضعیت بررسی فعال باشد.',1;
  IF EXISTS(
   SELECT 1 FROM TahghighatV2.Referral c WITH(UPDLOCK,HOLDLOCK)
   WHERE c.ParentReferralId=@HozeReferralId AND c.ToMahal=@CountyCityId
    AND c.ReceiverLevel='SHAHR' AND c.IsDeleted=0)
   THROW 54017,N'برای این شهرستان در همین پرونده قبلاً ارجاع ثبت شده است.',1;
  INSERT TahghighatV2.Referral
   (CaseId,ParentReferralId,FromMahal,ToMahal,ReceiverLevel,StateCode,Description,CreatedByUserId)
  VALUES(@CaseId,@HozeReferralId,@Hoze,@CountyCityId,'SHAHR','CHILD_INBOX',@Description,@UserId);
  SET @NewId=CONVERT(bigint,SCOPE_IDENTITY());
  INSERT TahghighatV2.WorkflowEvent
   (ReferralId,ActionCode,PreviousStateCode,NewStateCode,Description,ActorUserId)
  VALUES(@HozeReferralId,'HOZE_REFER_COUNTY',@State,@State,@Description,@UserId),
        (@NewId,'CHILD_CREATED',NULL,'CHILD_INBOX',@Description,@UserId);
  COMMIT;
  SELECT CONVERT(bit,1) IsSuccess,@NewId CountyReferralId,@HozeReferralId HozeReferralId;
 END TRY
 BEGIN CATCH
  IF XACT_STATE()<>0 ROLLBACK;
  THROW;
 END CATCH;
END;
GO

/* Phase 92: soft-delete ONLY untouched subordinate county referrals issued by the current HOZE.
   Both the creation lock on root and the county-processing lock on HOZE parent
   are acquired. The child must have no destination action or downstream records.
   The operation leaves an immutable audit record, not a physical DELETE. */
CREATE OR ALTER PROCEDURE TahghighatV2.SP_HozeDeleteUntouchedCountyReferral
 @HozeReferralId bigint,@CountyReferralId bigint,@UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 SET XACT_ABORT ON;
 IF @HozeReferralId IS NULL OR @HozeReferralId<=0
   OR @CountyReferralId IS NULL OR @CountyReferralId<=0
   OR @UserId IS NULL OR @UserId<=0 OR @HozeReferralId=@CountyReferralId
   THROW 54920,N'شناسه ارجاع حوزه، شهرستان یا کاربر نامعتبر است.',1;
 DECLARE @Mahal int,@Post int,@RootId bigint,@HozeState varchar(40),
         @CountyState varchar(40),@Lock int;
 SELECT @Mahal=u.Mahal,@Post=u.PostId FROM dbo.Users u
 WHERE u.UserId=@UserId AND u.IsActive=1;
 IF @Post<>61 OR NOT EXISTS(SELECT 1 FROM dbo.Citys c
       WHERE c.CityId=@Mahal AND c.IsHoze=1 AND c.IsActive=1)
   OR NOT EXISTS(SELECT 1 FROM TahghighatV2.PostActionPermission p
       WHERE p.PostId=61 AND p.ActionCode='HOZE_DELETE_COUNTY_REFERRAL' AND p.IsAllowed=1)
   THROW 54921,N'مجوز حذف ارجاع شهرستان برای این کاربر وجود ندارد.',1;
 -- Only a hint before transaction; all scope/permissions and states are rechecked under locks.
 SELECT @RootId=h.ParentReferralId FROM TahghighatV2.Referral h
 WHERE h.ReferralId=@HozeReferralId AND h.ToMahal=@Mahal
   AND h.ReceiverLevel='HOZE' AND h.IsDeleted=0;
 IF @RootId IS NULL THROW 54922,N'ارجاع حوزه در محدوده دسترسی شما یافت نشد.',1;
 BEGIN TRY
  BEGIN TRANSACTION;
  DECLARE @RootResource nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(25),@RootId);
  DECLARE @HozeResource nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(25),@HozeReferralId);
  EXEC @Lock=sys.sp_getapplock @Resource=@RootResource,@LockMode=N'Exclusive',
       @LockOwner=N'Transaction',@LockTimeout=10000;
  IF @Lock<0 THROW 54923,N'پرونده در حال پردازش است؛ دوباره تلاش کنید.',1;
  EXEC @Lock=sys.sp_getapplock @Resource=@HozeResource,@LockMode=N'Exclusive',
       @LockOwner=N'Transaction',@LockTimeout=10000;
  IF @Lock<0 THROW 54924,N'پرونده در حال پردازش است؛ دوباره تلاش کنید.',1;
  SELECT @HozeState=h.StateCode
  FROM TahghighatV2.Referral h WITH(UPDLOCK,HOLDLOCK)
  JOIN TahghighatV2.Referral root WITH(UPDLOCK,HOLDLOCK) ON root.ReferralId=h.ParentReferralId
  WHERE h.ReferralId=@HozeReferralId AND h.ParentReferralId=@RootId
    AND h.ReceiverLevel='HOZE' AND h.ToMahal=@Mahal
    AND h.StateCode='CHILD_WORKING' AND h.IsClosed=0 AND h.IsDeleted=0
    AND root.ParentReferralId IS NULL AND root.StateCode='PENDING_CHILD_RESULTS'
    AND root.IsClosed=0 AND root.IsDeleted=0;
  IF @HozeState IS NULL THROW 54925,N'حوزه در وضعیت مجاز برای حذف ارجاع نیست.',1;
  SELECT @CountyState=c.StateCode
  FROM TahghighatV2.Referral c WITH(UPDLOCK,HOLDLOCK)
  JOIN dbo.Citys county ON county.CityId=c.ToMahal
  JOIN dbo.Citys hoze ON hoze.CityId=@Mahal
  WHERE c.ReferralId=@CountyReferralId AND c.ParentReferralId=@HozeReferralId
    AND c.ReceiverLevel='SHAHR' AND c.FromMahal=@Mahal
    AND county.IsHoze=0 AND county.CityIdHozeh=@Mahal AND county.PCityId=hoze.PCityId
    AND c.StateCode='CHILD_INBOX' AND c.IsClosed=0 AND c.IsDeleted=0;
  IF @CountyState IS NULL THROW 54926,N'ارجاع شهرستان رسیدگی شده یا قابل حذف نیست.',1;
  IF NOT EXISTS (SELECT 1 FROM TahghighatV2.WorkflowEvent e WITH(UPDLOCK,HOLDLOCK)
        WHERE e.ReferralId=@CountyReferralId AND e.ActionCode='CHILD_CREATED')
     OR EXISTS (SELECT 1 FROM TahghighatV2.WorkflowEvent e WITH(UPDLOCK,HOLDLOCK)
        WHERE e.ReferralId=@CountyReferralId AND e.ActionCode<>'CHILD_CREATED')
     OR EXISTS (SELECT 1 FROM TahghighatV2.Referral sub WITH(UPDLOCK,HOLDLOCK)
        WHERE sub.ParentReferralId=@CountyReferralId)
     OR EXISTS (SELECT 1 FROM TahghighatV2.ResearchAssignment a WITH(UPDLOCK,HOLDLOCK)
        WHERE a.ReferralId=@CountyReferralId)
     OR EXISTS (SELECT 1 FROM TahghighatV2.CountySummary cs WITH(UPDLOCK,HOLDLOCK)
        WHERE cs.ReferralId=@CountyReferralId)
     OR EXISTS (SELECT 1 FROM TahghighatV2.NoResearchDecision nr WITH(UPDLOCK,HOLDLOCK)
        WHERE nr.ReferralId=@CountyReferralId)
    THROW 54927,N'شهرستان اقدام، تحقیق یا جمع‌بندی ثبت کرده است؛ حذف مجاز نیست.',1;
  UPDATE TahghighatV2.Referral
    SET IsDeleted=1,UpdatedByUserId=@UserId,UpdatedAtUtc=SYSUTCDATETIME()
  WHERE ReferralId=@CountyReferralId AND ParentReferralId=@HozeReferralId
    AND StateCode='CHILD_INBOX' AND IsClosed=0 AND IsDeleted=0;
  IF @@ROWCOUNT<>1 THROW 54928,N'وضعیت ارجاع شهرستان تغییر کرده است؛ دوباره تلاش کنید.',1;
  DECLARE @Reason nvarchar(250)=N'حذف ارجاع شهرستان فرعی پیش از اقدام مقصد';
  INSERT TahghighatV2.WorkflowEvent
    (ReferralId,ActionCode,PreviousStateCode,NewStateCode,Description,ActorUserId)
  VALUES (@CountyReferralId,'HOZE_DELETE_COUNTY_REFERRAL','CHILD_INBOX','CHILD_INBOX',@Reason,@UserId),
    (@HozeReferralId,'HOZE_DELETE_COUNTY_REFERRAL',@HozeState,@HozeState,
      @Reason+N'؛ ارجاع شماره '+CONVERT(nvarchar(25),@CountyReferralId),@UserId);
  COMMIT TRANSACTION;
  SELECT CONVERT(bit,1) IsSuccess,@CountyReferralId CountyReferralId,@HozeReferralId HozeReferralId;
 END TRY
 BEGIN CATCH
  IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
  THROW;
 END CATCH;
END;
GO

/* Phase 93: restore the former system's person/cooperation-based investigator choices.
   Investigator employment/identity is separate from authentication; no dbo.Users row is required.
   This script only changes HOZE candidate and assignment procedures. */
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_GetHozeInvestigatorCandidates
 @HozeReferralId bigint,
 @UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @Hoze bigint,@Post int;
 SELECT @Hoze=u.Mahal,@Post=u.PostId
 FROM dbo.Users u WHERE u.UserId=@UserId AND u.IsActive=1;
 IF ISNULL(@Post,0)<>61 OR NOT EXISTS
 ( SELECT 1 FROM TahghighatV2.Referral r
   JOIN dbo.Citys h ON h.CityId=r.ToMahal AND h.IsHoze=1 AND h.IsActive=1
   WHERE r.ReferralId=@HozeReferralId AND r.ToMahal=@Hoze
   AND r.ReceiverLevel='HOZE' AND r.StateCode='CHILD_WORKING'
   AND r.IsClosed=0 AND r.IsDeleted=0 )
  THROW 54884,N'این پرونده در مرحله انتساب محقق حوزه نیست.',1;

 /* One row per PersonId, even when one researcher has several active Hamkari
    records in this constituency. Choose the same preferred county as the
    assignment procedure: constituency center first, then the lowest CityId.
    Account creation and AuthUserId are NOT required for selection. */
 SELECT p.PersonId,ir.InvestigatorKey,ir.AuthUserId,
  selected.CountyCityId,selected.CountyName,
  LTRIM(RTRIM(CONCAT(ISNULL(p.FirstName,N''),N' ',ISNULL(p.LastName,N'')))) FullName,
  CONVERT(bit,CASE WHEN ir.InvestigatorKey IS NULL OR ir.IsActive=1 THEN 1 ELSE 0 END) IsAssignable
 FROM dbo.Person p
 JOIN dbo.Citys center ON center.CityId=@Hoze AND center.IsHoze=1 AND center.IsActive=1
 CROSS APPLY
 ( SELECT TOP (1) c.CityId CountyCityId,c.Name CountyName
   FROM Hamkari.PersonHamkari h
   JOIN dbo.Citys c ON c.CityId=h.MahalHamkari AND c.IsActive=1
   WHERE h.PersonId=p.PersonId AND h.NoeHamkari=2
    AND ISNULL(h.IsActive,0)=1 AND ISNULL(h.IsDeleted,0)=0
    AND c.PCityId=center.PCityId
    AND (c.CityIdHozeh=@Hoze OR c.CityId=@Hoze)
   ORDER BY CASE WHEN c.CityId=@Hoze THEN 0 ELSE 1 END,c.CityId
 ) selected
 OUTER APPLY
 ( SELECT TOP (1) r.InvestigatorKey,r.AuthUserId,r.IsActive
   FROM TahghighatV2.InvestigatorRegistry r
   WHERE r.PersonId=p.PersonId AND r.ProvinceCityId=center.PCityId
   ORDER BY r.IsActive DESC,r.InvestigatorKey
 ) ir
 WHERE ISNULL(p.IsDelete,0)=0
  AND NOT EXISTS (
    SELECT 1 FROM TahghighatV2.ResearchAssignment a
    JOIN TahghighatV2.InvestigatorRegistry already ON already.InvestigatorKey=a.InvestigatorId
    WHERE a.ReferralId=@HozeReferralId AND already.PersonId=p.PersonId
      AND a.StatusCode<>'CANCELLED'
  )
 ORDER BY FullName,selected.CountyName,p.PersonId;
END;
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_HozeAssignInvestigator
 @HozeReferralId bigint,
 @Instruction nvarchar(max),
 @UserId bigint,
 @InvestigatorKey bigint=NULL,
 @DueDatePersian char(10)=NULL,
 @PersonId bigint=NULL
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 IF @HozeReferralId IS NULL OR @HozeReferralId<=0 OR @UserId IS NULL OR @UserId<=0
    OR NULLIF(LTRIM(RTRIM(@Instruction)),N'') IS NULL OR LEN(@Instruction)>6000
    OR (@PersonId IS NULL AND @InvestigatorKey IS NULL)
  THROW 54886,N'اطلاعات انتساب کامل نیست.',1;
 IF @PersonId IS NULL AND @InvestigatorKey IS NOT NULL
  SELECT @PersonId=PersonId FROM TahghighatV2.InvestigatorRegistry
  WHERE InvestigatorKey=@InvestigatorKey AND IsActive=1;
 IF @PersonId IS NULL OR @PersonId<=0
  THROW 54888,N'هویت محقق انتخاب‌شده معتبر نیست.',1;

 DECLARE @Hoze bigint,@Post int,@Root bigint,@State varchar(40),@Lock int,
  @InvLock int,@NewId bigint,@Province int,@County int,@EffectiveKey bigint,@RegActive bit;
 SELECT @Hoze=u.Mahal,@Post=u.PostId
 FROM dbo.Users u WHERE u.UserId=@UserId AND u.IsActive=1;
 IF ISNULL(@Post,0)<>61 OR NOT EXISTS
 (SELECT 1 FROM dbo.Citys c WHERE c.CityId=@Hoze AND c.IsHoze=1 AND c.IsActive=1)
  THROW 54887,N'کاربر مجاز حوزه انتخابیه نیست.',1;
 SELECT @Root=r.ParentReferralId
 FROM TahghighatV2.Referral r WHERE r.ReferralId=@HozeReferralId
  AND r.ToMahal=@Hoze AND r.ReceiverLevel='HOZE' AND r.IsDeleted=0;
 IF @Root IS NULL THROW 54889,N'ارجاع حوزه معتبر نیست.',1;

 BEGIN TRY
  BEGIN TRANSACTION;
  DECLARE @LockName nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(20),@Root);
  EXEC @Lock=sys.sp_getapplock @Resource=@LockName,
   @LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
  IF @Lock<0 THROW 54890,N'پرونده در حال پردازش است.',1;

  SELECT @State=r.StateCode FROM TahghighatV2.Referral r WITH(UPDLOCK,HOLDLOCK)
  JOIN TahghighatV2.Referral parent ON parent.ReferralId=r.ParentReferralId
  WHERE r.ReferralId=@HozeReferralId AND r.ToMahal=@Hoze
   AND r.ReceiverLevel='HOZE' AND r.IsClosed=0 AND r.IsDeleted=0
   AND parent.ReferralId=@Root AND parent.StateCode='PENDING_CHILD_RESULTS'
   AND parent.IsClosed=0 AND parent.IsDeleted=0;
  IF ISNULL(@State,'')<>'CHILD_WORKING'
   THROW 54891,N'ارجاع حوزه در مرحله بررسی فعال نیست.',1;

  /* Resolve and validate actual person+cooperation in this constituency.
     It never requires a login or attempts to create one. */
  SELECT TOP(1) @County=CONVERT(int,c.CityId),@Province=CONVERT(int,center.PCityId)
  FROM Hamkari.PersonHamkari h
  JOIN dbo.Person p ON p.PersonId=h.PersonId AND ISNULL(p.IsDelete,0)=0
  JOIN dbo.Citys c ON c.CityId=h.MahalHamkari AND c.IsActive=1
  JOIN dbo.Citys center ON center.CityId=@Hoze AND center.IsActive=1 AND center.IsHoze=1
    AND c.PCityId=center.PCityId AND (c.CityIdHozeh=@Hoze OR c.CityId=@Hoze)
  WHERE h.PersonId=@PersonId AND h.NoeHamkari=2
    AND ISNULL(h.IsActive,0)=1 AND ISNULL(h.IsDeleted,0)=0
  ORDER BY CASE WHEN c.CityId=@Hoze THEN 0 ELSE 1 END,c.CityId;
  IF @County IS NULL OR @Province IS NULL
   THROW 54888,N'محقق فاقد همکاری فعال در این حوزه انتخابیه است.',1;

  /* The registry is an identity mapping, not a login. Create on the first
     assignment only; respect an explicitly deactivated existing identity. */
  DECLARE @InvestigatorLockName nvarchar(255)=N'MRV2:INV:'+CONVERT(nvarchar(20),@Province)
    +N':'+CONVERT(nvarchar(20),@PersonId);
  EXEC @InvLock=sys.sp_getapplock @Resource=@InvestigatorLockName,
   @LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
  IF @InvLock<0 THROW 54890,N'اطلاعات محقق در حال پردازش است.',1;
  SELECT TOP(1) @EffectiveKey=r.InvestigatorKey,@RegActive=r.IsActive
  FROM TahghighatV2.InvestigatorRegistry r WITH(UPDLOCK,HOLDLOCK)
  WHERE r.PersonId=@PersonId AND r.ProvinceCityId=@Province
  ORDER BY r.IsActive DESC,r.InvestigatorKey;
  IF @EffectiveKey IS NOT NULL AND @RegActive=0
   THROW 54888,N'ثبت محقق در رجیستری غیرفعال شده است.',1;
  IF @EffectiveKey IS NULL
  BEGIN
   INSERT TahghighatV2.InvestigatorRegistry
    (PersonId,ProvinceCityId,LegacyCodeMohaghegh,AuthUserId,IsActive,RegisteredBySqlLogin)
   SELECT p.PersonId,@Province,p.ShomarehParvandeh,NULL,1,ORIGINAL_LOGIN()
   FROM dbo.Person p WHERE p.PersonId=@PersonId;
   SET @EffectiveKey=CONVERT(bigint,SCOPE_IDENTITY());
  END;

  /* An existing inactive CountyInvestigator link is an explicit revocation. */
  IF EXISTS(SELECT 1 FROM TahghighatV2.CountyInvestigator ci
   WHERE ci.InvestigatorKey=@EffectiveKey AND ci.CountyCityId=@County AND ci.IsActive=0)
   THROW 54888,N'مجوز همکاری شهرستانی این محقق غیرفعال است.',1;
  IF NOT EXISTS(SELECT 1 FROM TahghighatV2.CountyInvestigator ci WITH(UPDLOCK,HOLDLOCK)
   WHERE ci.InvestigatorKey=@EffectiveKey AND ci.CountyCityId=@County)
   INSERT TahghighatV2.CountyInvestigator
    (InvestigatorKey,CountyCityId,IsActive,RegisteredBySqlLogin)
   VALUES(@EffectiveKey,@County,1,ORIGINAL_LOGIN());

  IF EXISTS(SELECT 1 FROM TahghighatV2.ResearchAssignment a WITH(UPDLOCK,HOLDLOCK)
   JOIN TahghighatV2.InvestigatorRegistry already ON already.InvestigatorKey=a.InvestigatorId
   WHERE a.ReferralId=@HozeReferralId AND already.PersonId=@PersonId
   AND a.StatusCode<>'CANCELLED')
   THROW 54892,N'برای همین محقق در این پرونده قبلاً انتساب ثبت شده است.',1;

  INSERT TahghighatV2.ResearchAssignment
   (ReferralId,InvestigatorId,DueDatePersian,Instruction,StatusCode,CreatedByUserId)
  VALUES(@HozeReferralId,@EffectiveKey,@DueDatePersian,@Instruction,'PENDING',@UserId);
  SET @NewId=CONVERT(bigint,SCOPE_IDENTITY());
  INSERT TahghighatV2.ResearchAssignmentEvent
   (AssignmentId,ActionCode,BeforeStatus,AfterStatus,Description,ActorUserId)
  VALUES(@NewId,'HOZE_ASSIGN_INVESTIGATOR',NULL,'PENDING',@Instruction,@UserId);
  INSERT TahghighatV2.WorkflowEvent
   (ReferralId,ActionCode,PreviousStateCode,NewStateCode,Description,ActorUserId)
  VALUES(@HozeReferralId,'HOZE_ASSIGN_INVESTIGATOR',@State,@State,@Instruction,@UserId);
  COMMIT;
  SELECT CONVERT(bit,1) IsSuccess,@NewId AssignmentId,@EffectiveKey InvestigatorKey;
 END TRY
 BEGIN CATCH
  IF XACT_STATE()<>0 ROLLBACK;
  THROW;
 END CATCH;
END;
GO


/* Phase 97: authorized HOZE officer may document a worksheet for a registry-only
   investigator, without creating or assuming any dbo.Users account for them.
   The actor and investigator remain distinct and fully auditable. */
IF NOT EXISTS (SELECT 1 FROM TahghighatV2.WorkflowAction WHERE ActionCode='HOZE_OFFICER_SAVE_WORKSHEET')
  INSERT TahghighatV2.WorkflowAction(ActionCode,TitleFa)
  VALUES('HOZE_OFFICER_SAVE_WORKSHEET',N'ثبت کاربرگ محقق توسط مسئول حوزه');
GO
IF NOT EXISTS (SELECT 1 FROM TahghighatV2.WorkflowAction WHERE ActionCode='HOZE_OFFICER_START')
  INSERT TahghighatV2.WorkflowAction(ActionCode,TitleFa)
  VALUES('HOZE_OFFICER_START',N'شروع تحقیق با ثبت کاربرگ توسط مسئول حوزه');
GO
IF NOT EXISTS (SELECT 1 FROM TahghighatV2.PostActionPermission WHERE PostId=61 AND ActionCode='HOZE_OFFICER_SAVE_WORKSHEET')
  INSERT TahghighatV2.PostActionPermission(PostId,ActionCode,IsAllowed)
  VALUES(61,'HOZE_OFFICER_SAVE_WORKSHEET',1);
GO
CREATE OR ALTER PROCEDURE TahghighatV2.SP_HozeOfficerSaveWorksheet
 @AssignmentId bigint,@ReportText nvarchar(max),@UserId bigint
AS
BEGIN
  SET NOCOUNT ON; SET XACT_ABORT ON;
  IF @AssignmentId IS NULL OR @AssignmentId<=0 OR @UserId IS NULL OR @UserId<=0
    OR NULLIF(LTRIM(RTRIM(@ReportText)),N'') IS NULL OR LEN(@ReportText)>12000
    THROW 54950,N'اطلاعات کاربرگ معتبر نیست.',1;

  DECLARE @Root bigint,@Hoze bigint,@OldStatus varchar(20),@HozeState varchar(40),
          @Lock int,@Id bigint;
  -- Scope is tied to the officer's *actual* active role and assigned HOZE.
  SELECT @Hoze=r.ReferralId,@Root=r.ParentReferralId
  FROM TahghighatV2.ResearchAssignment a
  JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId AND r.ReceiverLevel='HOZE'
  JOIN dbo.Users u ON u.UserId=@UserId AND u.IsActive=1 AND u.PostId=61 AND u.Mahal=r.ToMahal
  JOIN TahghighatV2.PostActionPermission perm ON perm.PostId=u.PostId
    AND perm.ActionCode='HOZE_OFFICER_SAVE_WORKSHEET' AND perm.IsAllowed=1
  WHERE a.AssignmentId=@AssignmentId AND r.IsDeleted=0 AND r.IsClosed=0;
  IF @Root IS NULL THROW 54951,N'برای ثبت کاربرگ این انتساب مجوز ندارید.',1;

  BEGIN TRY
    BEGIN TRANSACTION;
    DECLARE @LockName nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(20),@Root);
    EXEC @Lock=sys.sp_getapplock @Resource=@LockName,@LockMode='Exclusive',
      @LockOwner='Transaction',@LockTimeout=10000;
    IF @Lock<0 THROW 54952,N'پرونده در حال پردازش است.',1;

    SELECT @OldStatus=a.StatusCode,@HozeState=r.StateCode
    FROM TahghighatV2.ResearchAssignment a WITH(UPDLOCK,HOLDLOCK)
    JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId
    JOIN TahghighatV2.Referral p ON p.ReferralId=r.ParentReferralId
    WHERE a.AssignmentId=@AssignmentId AND r.ReferralId=@Hoze AND r.IsDeleted=0
      AND r.IsClosed=0 AND p.ReferralId=@Root AND p.IsDeleted=0 AND p.IsClosed=0
      AND p.StateCode='PENDING_CHILD_RESULTS' AND r.StateCode='CHILD_WORKING';
    IF @OldStatus NOT IN('PENDING','IN_PROGRESS') OR @HozeState<>'CHILD_WORKING'
      OR @OldStatus IS NULL THROW 54953,N'این انتساب در وضعیت مجاز ثبت کاربرگ نیست.',1;

    IF @OldStatus='PENDING'
    BEGIN
      UPDATE TahghighatV2.ResearchAssignment SET StatusCode='IN_PROGRESS'
      WHERE AssignmentId=@AssignmentId;
      INSERT TahghighatV2.ResearchAssignmentEvent
        (AssignmentId,ActionCode,BeforeStatus,AfterStatus,Description,ActorUserId)
      VALUES(@AssignmentId,'HOZE_OFFICER_START','PENDING','IN_PROGRESS',
             N'آغاز تحقیق با ثبت اولین کاربرگ توسط مسئول مجاز حوزه',@UserId);
    END;
    INSERT TahghighatV2.ResearchWorksheet(AssignmentId,ReportText,CreatedByUserId)
    VALUES(@AssignmentId,LTRIM(RTRIM(@ReportText)),@UserId);
    SET @Id=CONVERT(bigint,SCOPE_IDENTITY());
    INSERT TahghighatV2.ResearchAssignmentEvent
      (AssignmentId,ActionCode,BeforeStatus,AfterStatus,Description,ActorUserId)
    VALUES(@AssignmentId,'HOZE_OFFICER_SAVE_WORKSHEET',
           'IN_PROGRESS','IN_PROGRESS',N'ثبت کاربرگ توسط مسئول حوزه؛ شناسه '+CONVERT(nvarchar(20),@Id),@UserId);
    INSERT TahghighatV2.WorkflowEvent
      (ReferralId,ActionCode,PreviousStateCode,NewStateCode,Description,ActorUserId)
    VALUES(@Hoze,'HOZE_OFFICER_SAVE_WORKSHEET','CHILD_WORKING','CHILD_WORKING',
           N'ثبت کاربرگ محقق؛ شناسه '+CONVERT(nvarchar(20),@Id),@UserId);
    COMMIT;
    SELECT CONVERT(bit,1) IsSuccess,@Id WorksheetId;
  END TRY
  BEGIN CATCH
    IF XACT_STATE()<>0 ROLLBACK;
    THROW;
  END CATCH;
END;
GO
