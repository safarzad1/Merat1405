"use client";
import {useEffect,useState} from "react";
import { WorkflowHero, StateChip, EmptyMessage, AppNotice, SectionTitle, workflowStyles as u } from "@/app/(Dashboard)/(Tahghighat)/v2/components/MeratWorkflowUI";

import {meratV2Request,type V2Row} from "@/app/lib/meratV2/client";
import CountySummaryEditor from "@/app/(Dashboard)/(Tahghighat)/v2/components/CountySummaryEditor";
import CountyWorksheetAttachmentsPanel from "@/app/(Dashboard)/(Tahghighat)/v2/components/CountyWorksheetAttachmentsPanel";
const number=(x:unknown)=>Number(x||0),text=(x:unknown)=>x==null?"—":String(x);
export default function CountyRepresentativePage(){
 const [inbox,setInbox]=useState<V2Row[]>([]),[candidates,setCandidates]=useState<V2Row[]>([]),[assignments,setAssignments]=useState<V2Row[]>([]),[worksheets,setWorksheets]=useState<V2Row[]>([]);
 const [ref,setRef]=useState<number|null>(null),[selected,setSelected]=useState<number|null>(null),[investigator,setInvestigator]=useState(""),[instruction,setInstruction]=useState(""),[dueDate,setDueDate]=useState(""),[reason,setReason]=useState("");
 const [summaryReady,setSummaryReady]=useState(false);
 const [busy,setBusy]=useState(false),[error,setError]=useState(""),[notice,setNotice]=useState("");
 async function reload(){setInbox(await meratV2Request("/Api/TahghighV2/CountyInbox?page=1&pageSize=100"));}
 async function detail(id:number){const [a,b]=await Promise.all([
  meratV2Request(`/Api/TahghighV2/CountyCandidates?countyReferralId=${id}`),
  meratV2Request(`/Api/TahghighV2/CountyAssignments?countyReferralId=${id}`)]);setCandidates(a);setAssignments(b);}
 useEffect(()=>{
   const requested = Number(new URLSearchParams(window.location.search).get("referralId"));
   if(Number.isSafeInteger(requested) && requested>0) setRef(requested);
   void reload().catch(e=>setError(String(e)));
 },[]);
 useEffect(()=>{setCandidates([]);setAssignments([]);setSelected(null);if(ref!==null)void detail(ref).catch(e=>setError(String(e)));},[ref]);
 useEffect(()=>{setWorksheets([]);if(selected!==null)void meratV2Request(`/Api/TahghighV2/CountyWorksheets?assignmentId=${selected}`).then(setWorksheets).catch(e=>setError(String(e)));},[selected]);
 const row=inbox.find(x=>number(x.CountyReferralId)===ref),working=row?.StateCode==="CHILD_WORKING";
 const open=assignments.some(x=>["PENDING","IN_PROGRESS"].includes(text(x.StatusCode)));
 async function act(url:string,body:Record<string,unknown>,msg:string){setBusy(true);setError("");setNotice("");try{
  await meratV2Request(url,body);setNotice(msg);await reload();if(ref!==null)await detail(ref);setSelected(null);
 }catch(e){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false);}}
 return <main dir="rtl" className={u.workspace}>
 <WorkflowHero eyebrow="تحقیقات مرآت · فاز ۲C" title="کارتابل نماینده شهرستان"
 description="ارجاع به چند محقق تأییدشده، پایش کاربرگ‌ها و ارسال پاسخ نهایی پس از تعیین‌تکلیف همه مأموریت‌ها."
 stats={[{label:"ارجاعات شهرستان",value:inbox.length},{label:"محققان دارای مأموریت",value:assignments.length},{label:"تحقیقات باز",value:assignments.filter(x=>["PENDING","IN_PROGRESS"].includes(String(x.StatusCode))).length}]}/>
 <SectionTitle kicker="صندوق شهرستان" title="ارجاعات دریافتی" description="پرونده موردنظر را از فهرست انتخاب کنید."/>
 {error&&<AppNotice kind="error">{error}</AppNotice>}{notice&&<AppNotice kind="success">{notice}</AppNotice>}
 <button type="button" onClick={()=>void reload().catch(e=>setError(String(e)))}>بازخوانی</button>
 <ul>{inbox.map(x=><li key={text(x.CountyReferralId)}><button type="button" onClick={()=>{setSummaryReady(false);setRef(number(x.CountyReferralId));}}>ارجاع {text(x.CountyReferralId)} — پرونده {text(x.ShomarehParvandeh)} — {text(x.StateCode)}</button></li>)}</ul>{inbox.length===0&&<EmptyMessage title="ارجاعی در کارتابل وجود ندارد"/>}
 {ref!==null&&row&&<section className={u.selectionPanel}>
 <SectionTitle kicker="پرونده انتخابی" title={`ارجاع شهرستان ${ref}`}/><p>{text(row.Description)}</p>
 <label>توضیح اقدام/علت لغو<textarea rows={3} maxLength={6000} value={reason} style={{display:"block",width:"100%"}} onChange={e=>setReason(e.target.value)}/></label>
 {row.StateCode==="CHILD_INBOX"&&<button type="button" disabled={busy||!reason.trim()} onClick={()=>void act("/Api/TahghighV2/CountyAction",{countyReferralId:ref,actionCode:"COUNTY_START",description:reason.trim()},"بررسی شروع شد.")}>شروع بررسی شهرستان</button>}
 {working&&<section><SectionTitle kicker="توزیع مأموریت" title="ارجاع به محقق جدید"/><label>محقق<select value={investigator} onChange={e=>setInvestigator(e.target.value)}><option value="">انتخاب</option>{candidates.map(x=><option key={text(x.InvestigatorKey)} value={text(x.InvestigatorKey)}>محقق {text(x.InvestigatorKey)} / کاربر {text(x.AuthUserId)}</option>)}</select></label>
 <label>مهلت شمسی<input value={dueDate} maxLength={10} placeholder="1405/08/15" onChange={e=>setDueDate(e.target.value)}/></label>
 <label>شرح مأموریت<textarea rows={3} value={instruction} maxLength={6000} style={{display:"block",width:"100%"}} onChange={e=>setInstruction(e.target.value)}/></label>
 <button type="button" className={u.primary} disabled={busy||!investigator||!instruction.trim()} onClick={()=>void act("/Api/TahghighV2/CountyAssignInvestigator",{countyReferralId:ref,investigatorKey:Number(investigator),instruction:instruction.trim(),dueDatePersian:dueDate||null},"انتساب محقق ثبت شد.")}>ثبت انتساب</button>
 </section>}
 <SectionTitle kicker="پیگیری" title="محققان و نتایج"/><div className={u.tableScroll}><table style={{width:"100%",textAlign:"right"}}><thead><tr><th>انتساب</th><th>وضعیت</th><th>جمع‌بندی</th><th>عملیات</th></tr></thead><tbody>{assignments.map(x=><tr key={text(x.AssignmentId)}><td>{text(x.AssignmentId)}</td><td><StateChip value={x.StatusCode}/></td><td>{text(x.Summary)}</td><td>
 <button type="button" onClick={()=>setSelected(number(x.AssignmentId))}>کاربرگ‌ها</button>
 {working&&["PENDING","IN_PROGRESS"].includes(text(x.StatusCode))&&<button type="button" disabled={busy||!reason.trim()} onClick={()=>void act("/Api/TahghighV2/CountyCancelAssignment",{assignmentId:number(x.AssignmentId),reason:reason.trim()},"انتساب لغو شد.")}>لغو مستند</button>}
 </td></tr>)}</tbody></table></div>
 {selected!==null&&<section><SectionTitle kicker="اسناد" title={`کاربرگ‌های انتساب ${selected}`}/>{worksheets.map(x=><article key={text(x.WorksheetId)} style={{padding:12,border:"1px solid #ddd"}}><p style={{whiteSpace:"pre-wrap"}}>{text(x.ReportText)}</p><CountyWorksheetAttachmentsPanel worksheetId={number(x.WorksheetId)} readOnly/></article>)}</section>}
 <CountySummaryEditor key={ref} referralId={ref} working={working} onReadyChange={setSummaryReady}/>
 {working&&<button type="button" className={u.primary} disabled={busy||open||!summaryReady||!reason.trim()} onClick={()=>void act("/Api/TahghighV2/CountyAction",{countyReferralId:ref,actionCode:"COUNTY_REPLY",description:reason.trim()},"پاسخ شهرستان به حوزه ارسال شد.")}>ارسال پاسخ شهرستان به حوزه</button>}
 {open&&<AppNotice kind="info">تا پایان یا لغو مستند همه تحقیقات، پاسخ شهرستان مسدود است.</AppNotice>}
 </section>}</main>;
}
