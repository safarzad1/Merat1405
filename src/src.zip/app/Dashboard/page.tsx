import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import AppTopbar from "@/component/AppTopbar";
import { verifyToken } from "@/lib/auth";
import styles from "./Dashboard.module.css";

export const dynamic = "force-dynamic";

type SessionPayload = {
  username?: string;
  fullName?: string;
};

export default async function DashboardPage() {
  const cookieStore = await cookies();
  const token = cookieStore.get("token")?.value;
  const hasSession = cookieStore.get("merat-new-session")?.value === "1";

  if (!token || !hasSession) {
    redirect("/Login");
  }

  let session: SessionPayload;
  try {
    session = verifyToken(token) as SessionPayload;
  } catch {
    redirect("/Api/Auth/Logout");
  }

  return (
    <div className={styles.page} dir="rtl">
      <AppTopbar fullName={session.fullName || session.username} />
      <main className={styles.content} />
    </div>
  );
}
