"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import styles from "./AppTopbar.module.css";

type AppTopbarProps = {
  fullName?: string;
};

function DashboardIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <rect x="3.5" y="3.5" width="6.5" height="6.5" rx="1.6" />
      <rect x="14" y="3.5" width="6.5" height="6.5" rx="1.6" />
      <rect x="3.5" y="14" width="6.5" height="6.5" rx="1.6" />
      <rect x="14" y="14" width="6.5" height="6.5" rx="1.6" />
    </svg>
  );
}

function LogoutIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M10 5H5v14h5M14 8l4 4-4 4M18 12H9" />
    </svg>
  );
}

function UserIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <circle cx="12" cy="8" r="3.5" />
      <path d="M5.5 20a6.5 6.5 0 0 1 13 0" />
    </svg>
  );
}

export default function AppTopbar({ fullName }: AppTopbarProps) {
  const pathname = usePathname();
  const router = useRouter();
  const [loggingOut, setLoggingOut] = useState(false);

  async function logout() {
    if (loggingOut) return;
    setLoggingOut(true);

    try {
      await fetch("/Api/Auth/Logout", {
        method: "POST",
        cache: "no-store",
      });
    } finally {
      try {
        localStorage.removeItem("merat-user");
      } catch {
        // Ignore storage errors.
      }
      router.replace("/Login");
      router.refresh();
    }
  }

  return (
    <header className={styles.topbar} dir="rtl">
      <div className={styles.inner}>
        <div className={styles.brandArea}>
          <Link className={styles.brand} href="/Dashboard" aria-label="مرآت">
            <span className={styles.brandMark}>م</span>
            <span className={styles.brandText}>
              <strong>مرآت</strong>
              <small>سامانه جامع مدیریت و تحقیقات</small>
            </span>
          </Link>

          <nav className={styles.navigation} aria-label="منوی اصلی">
            <Link
              href="/Dashboard"
              className={`${styles.navItem} ${pathname === "/Dashboard" ? styles.navItemActive : ""}`}
              aria-current={pathname === "/Dashboard" ? "page" : undefined}
            >
              <span className={styles.navIcon}><DashboardIcon /></span>
              داشبورد
            </Link>
          </nav>
        </div>

        <div className={styles.actions}>
          <div className={styles.userBox} title={fullName || "کاربر سامانه"}>
            <span className={styles.userIcon}><UserIcon /></span>
            <span className={styles.userName}>{fullName || "کاربر سامانه"}</span>
          </div>

          <button
            type="button"
            className={styles.logoutButton}
            onClick={logout}
            disabled={loggingOut}
          >
            <span className={styles.logoutIcon}><LogoutIcon /></span>
            <span>{loggingOut ? "در حال خروج..." : "خروج"}</span>
          </button>
        </div>
      </div>
    </header>
  );
}
