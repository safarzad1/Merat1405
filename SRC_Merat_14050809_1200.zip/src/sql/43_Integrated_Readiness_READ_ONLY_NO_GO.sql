/*
 MERAT V2 / 43 — Integrated staging readiness gate (READ ONLY; NO GO).
 Run in SSMS on the SAME TEST SQL Server where MeratDB & MeratFilesDB exist.
 No CREATE/ALTER/UPDATE/DELETE/DDL or transaction; does not read the FileData blob.
 Outputs checks and counts. REVIEW is not PASS.
*/
USE [MeratDB];
SET NOCOUNT ON;

DECLARE @Checks TABLE(
  GroupName nvarchar(70) NOT NULL,
  CheckName nvarchar(150) NOT NULL,
  Result varchar(8) NOT NULL,
  Detail nvarchar(500) NULL
);

INSERT @Checks VALUES(N'Database',N'Current database',
 CASE WHEN DB_NAME()=N'MeratDB' THEN 'PASS' ELSE 'FAIL' END,
 DB_NAME());
INSERT @Checks VALUES(N'Database',N'Files database on same SQL instance',
 CASE WHEN DB_ID(N'MeratFilesDB') IS NOT NULL THEN 'PASS' ELSE 'FAIL' END,
 N'MeratFilesDB');

DECLARE @DocId int=OBJECT_ID(N'MeratFilesDB.dbo.TahghighatDocument',N'U');
INSERT @Checks VALUES(N'Attachments',N'Unified dbo.TahghighatDocument',
 CASE WHEN @DocId IS NOT NULL THEN 'PASS' ELSE 'FAIL' END,
 CASE WHEN @DocId IS NULL THEN N'جدول وجود ندارد یا مجوز مشاهده متادیتای آن صادر نشده است.'
 ELSE N'جدول جدید مشاهده شد؛ صحت محتوا جداگانه باید تست شود.' END);

IF @DocId IS NOT NULL
BEGIN
  DECLARE @VarbinaryOk bit=0;
  SELECT @VarbinaryOk=1
  FROM MeratFilesDB.sys.columns c
  JOIN MeratFilesDB.sys.types t ON t.user_type_id=c.user_type_id
  WHERE c.object_id=@DocId AND c.name=N'FileData'
    AND t.name=N'varbinary' AND c.max_length=-1;
  INSERT @Checks VALUES(N'Attachments',N'FileData = VARBINARY(MAX)',
   CASE WHEN @VarbinaryOk=1 THEN 'PASS' ELSE 'FAIL' END,N'MeratFilesDB.dbo.TahghighatDocument.FileData');
  DECLARE @Cols TABLE(Name sysname NOT NULL);
  INSERT @Cols VALUES
   (N'AttachmentId'),(N'CaseId'),(N'ShomarehParvandeh'),(N'PersonId'),
   (N'ReferralId'),(N'AssignmentId'),(N'AttachmentKind'),(N'SummaryLevel'),
   (N'TargetEntity'),(N'TargetRecordId'),(N'OriginalFileName'),(N'MimeType'),
   (N'FileSizeBytes'),(N'Sha256'),(N'FileData'),(N'CreatedByUserId'),
   (N'CreatedAtUtc'),(N'IsDeleted'),(N'DeletedByUserId'),(N'DeleteReason');
  INSERT @Checks
  SELECT N'Attachments',N'Required column: '+col.Name,
   CASE WHEN c.column_id IS NULL THEN 'FAIL' ELSE 'PASS' END,
   N'جدول واحد پیوست‌ها'
  FROM @Cols col
  LEFT JOIN MeratFilesDB.sys.columns c
    ON c.object_id=@DocId AND c.name=col.Name;
END;

DECLARE @NeededTables TABLE(Name sysname NOT NULL);
INSERT @NeededTables VALUES
(N'CaseFile'),(N'Referral'),(N'ResearchAssignment'),(N'ResearchWorksheet'),
(N'ProvinceSummary'),(N'WorkflowEvent'),(N'PostActionPermission'),
(N'InvestigatorRegistry'),(N'CountyRepresentative'),(N'CountyInvestigator');
INSERT @Checks
SELECT N'Workflow',N'Expected table: '+Name,
 CASE WHEN OBJECT_ID(N'TahghighatV2.'+Name,N'U') IS NOT NULL THEN 'PASS' ELSE 'FAIL' END,
 N'MeratDB.TahghighatV2'
FROM @NeededTables;

DECLARE @NeededProcedures TABLE(Name sysname NOT NULL);
INSERT @NeededProcedures VALUES
 (N'SP_CreateInitialFromSetad'),(N'SP_ProvinceAction'),(N'SP_GetProvinceInbox'),
 (N'SP_GetDirectorInbox'),(N'SP_DirectorAction'),(N'SP_SaveProvinceSummary'),
 (N'SP_GetReferralDetail'),(N'SP_GetSetadInbox'),(N'SP_SetadAction'),
 (N'SP_AssignProvinceInvestigator'),(N'SP_GetInvestigatorInbox'),
 (N'SP_GetProvinceInvestigatorCandidates'),(N'SP_SaveResearchWorksheet'),
 (N'SP_HozeReferCounty'),(N'SP_GetCountyInbox'),(N'SP_CountyAssignInvestigator'),
 (N'SP_CountyInvestigatorAction'),(N'SP_CountySaveWorksheet'),(N'SP_CountyAction'),
 (N'SP_UnifiedAttachmentTargetAccess'),(N'SP_UploadDocumentAttachment'),
 (N'SP_ListDocumentAttachments'),(N'SP_DownloadDocumentAttachment'),(N'SP_DeleteDocumentAttachment');
INSERT @Checks
SELECT N'Procedures',N'Expected procedure: '+Name,
 CASE WHEN OBJECT_ID(N'TahghighatV2.'+Name,N'P') IS NOT NULL THEN 'PASS' ELSE 'FAIL' END,
 N'نصب نشدن پروسیجر ممکن است به اجرای مرحله مربوطه نیاز داشته باشد.'
FROM @NeededProcedures;

IF OBJECT_ID(N'TahghighatV2.PostActionPermission',N'U') IS NOT NULL
BEGIN
  DECLARE @Required TABLE(PostId int,ActionCode varchar(40));
  INSERT @Required VALUES
  (5,'CREATE_INITIAL'),(50,'DIRECTOR_APPROVE'),(50,'RETURN_PROVINCE'),
  (51,'START_PROVINCE'),(51,'NO_RESEARCH'),(51,'SUBMIT_DIRECTOR'),(51,'SAVE_PROVINCE_SUMMARY'),
  (52,'START_PROVINCE'),(52,'NO_RESEARCH'),(52,'SUBMIT_DIRECTOR'),(52,'SAVE_PROVINCE_SUMMARY');
  INSERT @Checks
  SELECT N'Permissions',N'Phase 1 active: '+CONVERT(nvarchar(10),r.PostId)+N' / '+r.ActionCode,
   CASE WHEN p.PostId IS NULL THEN 'FAIL' ELSE 'PASS' END,
   N'این ۱۱ مجوز قبلاً تأیید شده بودند؛ اکنون نیز باید فعال باشند.'
  FROM @Required r
  LEFT JOIN TahghighatV2.PostActionPermission p
    ON p.PostId=r.PostId AND p.ActionCode=r.ActionCode AND p.IsAllowed=1;
  INSERT @Checks
  SELECT N'Permissions',N'Setad finalization: '+a.ActionCode,
    CASE WHEN p.PostId IS NULL THEN 'REVIEW' ELSE 'PASS' END,
    N'مجوز PostId 5 برای مرحله تصمیم نهایی ستاد'
  FROM (VALUES(CAST('SETAD_APPROVE' AS varchar(40))),('RETURN_PROVINCE')) a(ActionCode)
  LEFT JOIN TahghighatV2.PostActionPermission p
   ON p.PostId=5 AND p.ActionCode=a.ActionCode AND p.IsAllowed=1;
END;

/* Confirm the four document procedures refer to the actual renamed table. */
INSERT @Checks
SELECT N'Attachments',N'SQL target: '+p.name,
 CASE WHEN m.definition IS NULL THEN 'REVIEW'
  WHEN m.definition LIKE N'%MeratFilesDB.dbo.TahghighatDocument%' THEN 'PASS'
  ELSE 'FAIL' END,
 CASE WHEN m.definition IS NULL THEN N'متن تعریف پروسیجر قابل مشاهده نیست.'
  ELSE N'باید فقط جدول واحد را برای خواندن/نوشتن فایل به کار ببرد.' END
FROM sys.procedures p
JOIN sys.schemas s ON s.schema_id=p.schema_id
LEFT JOIN sys.sql_modules m ON m.object_id=p.object_id
WHERE s.name=N'TahghighatV2' AND p.name IN
 (N'SP_UploadDocumentAttachment',N'SP_ListDocumentAttachments',
  N'SP_DownloadDocumentAttachment',N'SP_DeleteDocumentAttachment');

/* Count only metadata; never read VARBINARY bytes in this gate. */
DECLARE @Stats TABLE(SourceName sysname,TotalRows bigint,ActiveRows bigint NULL);
IF @DocId IS NOT NULL
BEGIN TRY
 INSERT @Stats(SourceName,TotalRows,ActiveRows)
 EXEC(N'SELECT N''dbo.TahghighatDocument'',COUNT_BIG(*),
 COALESCE(SUM(CONVERT(bigint,CASE WHEN IsDeleted=0 THEN 1 ELSE 0 END)),0)
 FROM MeratFilesDB.dbo.TahghighatDocument;');
END TRY
BEGIN CATCH
 INSERT @Checks VALUES(N'Attachments',N'Unified file count', 'REVIEW', N'دسترسی شمارش فایل‌ها محدود است: '+ERROR_MESSAGE());
END CATCH;

IF OBJECT_ID(N'MeratFilesDB.ResearchAttachments.WorksheetAttachment',N'U') IS NOT NULL
BEGIN TRY
 INSERT @Stats(SourceName,TotalRows)
 EXEC(N'SELECT N''ResearchAttachments.WorksheetAttachment'',COUNT_BIG(*)
 FROM MeratFilesDB.ResearchAttachments.WorksheetAttachment;');
 DECLARE @Missing bigint=0;
 IF @DocId IS NOT NULL
 BEGIN
  EXEC sp_executesql N'SELECT @n=COUNT_BIG(*) FROM MeratFilesDB.ResearchAttachments.WorksheetAttachment src
    WHERE NOT EXISTS (SELECT 1 FROM MeratFilesDB.dbo.TahghighatDocument dst
     WHERE dst.AttachmentId=src.AttachmentId);',N'@n bigint OUTPUT',@n=@Missing OUTPUT;
  INSERT @Checks VALUES(N'Migration',N'Older V2 attachments copied by AttachmentId',
   CASE WHEN @Missing=0 THEN 'PASS' ELSE 'REVIEW' END,
   N'تعداد رکوردهای منتقل‌نشده: '+CONVERT(nvarchar(30),@Missing)+N'. پیش از حذف منبع، SQL 40 را اجرا کنید.');
 END;
END TRY
BEGIN CATCH
 INSERT @Checks VALUES(N'Migration',N'Older V2 attachment reconciliation','REVIEW',ERROR_MESSAGE());
END CATCH;

IF OBJECT_ID(N'MeratFilesDB.dbo.TahghighatPeyvast1',N'U') IS NOT NULL
BEGIN TRY
 INSERT @Stats(SourceName,TotalRows)
 EXEC(N'SELECT N''dbo.TahghighatPeyvast1'',COUNT_BIG(*) FROM MeratFilesDB.dbo.TahghighatPeyvast1;');
 INSERT @Checks VALUES(N'Migration',N'Legacy attachments separate mapping','REVIEW',
   N'جدول قدیمی محفوظ است. به علت اختلاف KarbargId با WorksheetId انتقال خودکار مجاز نیست.');
END TRY
BEGIN CATCH
 INSERT @Checks VALUES(N'Migration',N'Legacy attachments read permission','REVIEW',ERROR_MESSAGE());
END CATCH;

SELECT GroupName,CheckName,Result,Detail FROM @Checks
ORDER BY CASE Result WHEN 'FAIL' THEN 0 WHEN 'REVIEW' THEN 1 ELSE 2 END, GroupName,CheckName;
SELECT SourceName,TotalRows,ActiveRows FROM @Stats ORDER BY SourceName;
SELECT SUM(CASE WHEN Result='FAIL' THEN 1 ELSE 0 END) AS Failed,
       SUM(CASE WHEN Result='REVIEW' THEN 1 ELSE 0 END) AS NeedsReview,
       SUM(CASE WHEN Result='PASS' THEN 1 ELSE 0 END) AS Passed,
       CASE WHEN SUM(CASE WHEN Result='FAIL' THEN 1 ELSE 0 END)>0 THEN 'NOT_READY'
       WHEN SUM(CASE WHEN Result='REVIEW' THEN 1 ELSE 0 END)>0 THEN 'REQUIRES_REVIEW'
       ELSE 'METADATA_CHECKS_PASSED' END AS OverallMetadataStatus
FROM @Checks;
/* Even METADATA_CHECKS_PASSED is NOT a production acceptance test. */
