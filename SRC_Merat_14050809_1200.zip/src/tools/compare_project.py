#!/usr/bin/env python3
"""Read-only difference inventory between Merat V2 overlay and actual Next.js project.
Usage: python tools/compare_project.py 'D:/projects/merat' (or path on Windows).
No files written; no modifications; authBridge must NEVER be blindly overwritten.
"""
from pathlib import Path
import argparse, json, hashlib
parser=argparse.ArgumentParser();parser.add_argument('project',type=Path);args=parser.parse_args()
root=args.project.resolve()
overlay=Path(__file__).resolve().parents[1]/'overlay'/'app'
if not (root/'package.json').is_file():raise SystemExit('BLOCKED: package.json not found. Specify the real project root.')
appdir=root/'app' if (root/'app').is_dir() else root/'src'/'app'
if not appdir.is_dir():raise SystemExit('BLOCKED: Neither app/ nor src/app/ exists.')
rows=[];flags=[]
for src in overlay.rglob('*'):
 if not src.is_file():continue
 rel=src.relative_to(overlay);dest=appdir/rel
 status='NEW' if not dest.exists() else 'UNCHANGED' if src.read_bytes()==dest.read_bytes() else 'CONFLICT_REVIEW'
 rows.append({'file':str(rel).replace('\\','/'),'status':status})
 if status=='CONFLICT_REVIEW' and rel.as_posix() in ('lib/meratV2/authBridge.ts','lib/meratV2/db.ts'):
  flags.append('DO_NOT_OVERWRITE: '+str(rel))
bridge=appdir/'lib'/'meratV2'/'authBridge.ts'
if not bridge.exists():flags.append('BLOCKED: authBridge.ts absent in actual project')
elif 'MERAT_V2_AUTH_BRIDGE_NOT_CONFIGURED' in bridge.read_text(encoding='utf-8'):
 flags.append('BLOCKED: Real server-side auth bridge not wired')
print(json.dumps({'project':str(root),'target_app':str(appdir),
 'summary':{k:sum(x['status']==k for x in rows) for k in ('NEW','UNCHANGED','CONFLICT_REVIEW')},
 'flags':flags,'files':rows},ensure_ascii=False,indent=2))
print('READ ONLY: No source files were modified.')
