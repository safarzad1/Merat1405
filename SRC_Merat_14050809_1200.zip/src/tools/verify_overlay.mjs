/** Read-only static audit for the Merat V2 staging overlay; does not run Next.js. */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..', 'overlay', 'app');
function walk(d) { return fs.readdirSync(d,{withFileTypes:true}).flatMap(x=>x.isDirectory()?walk(path.join(d,x.name)):[path.join(d,x.name)]); }
const files=walk(root).filter(x=>/\.tsx?$/.test(x));
const findings=[];
for (const file of files) {
  const code=fs.readFileSync(file,'utf8');
  for (const m of code.matchAll(/from\s+["'](@\/app\/[^"']+)["']/g)) {
    const base=path.join(path.dirname(root),m[1].slice(2));
    if (!['','.ts','.tsx','.js','.jsx','.css'].some(s=>fs.existsSync(base+s)) && !fs.existsSync(path.join(base,'index.ts')))
      findings.push({severity:'FAIL',type:'MISSING_IMPORT',file:path.relative(root,file),value:m[1]});
  }
  for (const m of code.matchAll(/\/Api\/TahghighV2\/([A-Za-z0-9]+)/g)) {
    if(!fs.existsSync(path.join(root,'Api','TahghighV2',m[1],'route.ts')))
      findings.push({severity:'FAIL',type:'MISSING_ROUTE',file:path.relative(root,file),value:m[1]});
  }
}
const province=fs.readFileSync(path.join(root,'(Dashboard)','(Tahghighat)','v2','ostan','page.tsx'),'utf8');
if(!province.includes('<ProvinceInvestigatorPanel')) findings.push({severity:'FAIL',type:'MISSING_PROVINCE_INVESTIGATOR_PANEL'});
const impl=fs.readFileSync(path.join(root,'(Dashboard)','(Tahghighat)','v2','components','ProvinceInvestigatorPanel.tsx'),'utf8');
if(impl.includes('window.prompt(')) findings.push({severity:'FAIL',type:'LEGACY_PROMPT'});
const attachment=fs.readFileSync(path.join(root,'lib','meratV2','unifiedDocumentAttachment.ts'),'utf8');
if(!attachment.includes('SP_UploadDocumentAttachment')||!attachment.includes('SP_DownloadDocumentAttachment'))
  findings.push({severity:'FAIL',type:'UNIFIED_ATTACHMENT_PROCEDURES_MISSING'});
const auth=fs.readFileSync(path.join(root,'lib','meratV2','authBridge.ts'),'utf8');
if(auth.includes('MERAT_V2_AUTH_BRIDGE_NOT_CONFIGURED'))
  findings.push({severity:'REVIEW',type:'AUTH_MUST_BE_CONNECTED_TO_EXISTING_SERVER_SESSION'});
let ts;
try {ts=require('typescript');} catch {
 try {ts=require('/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript');} catch { /* optional outside development container */ }
}
let transpiled=0;
if (ts) {
 for (const file of files) {
  const out=ts.transpileModule(fs.readFileSync(file,'utf8'),{
   fileName:file,reportDiagnostics:true,
   compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,jsx:ts.JsxEmit.Preserve}
  });
  for(const diag of out.diagnostics||[]) if(diag.category===ts.DiagnosticCategory.Error)
   findings.push({severity:'FAIL',type:'TS_SYNTAX',file:path.relative(root,file),value:ts.flattenDiagnosticMessageText(diag.messageText,' ')});
  transpiled++;
 }
} else findings.push({severity:'REVIEW',type:'TYPESCRIPT_NOT_INSTALLED_SKIPPED_SYNTAX_CHECK'});
console.log(JSON.stringify({files:files.length,transpiled,failures:findings.filter(x=>x.severity==='FAIL').length,
  findings,summary:'Only static source checks. Full Next.js build, live SQL and auth tests are NOT performed.'},null,2));
if(findings.some(x=>x.severity==='FAIL'))process.exitCode=1;
