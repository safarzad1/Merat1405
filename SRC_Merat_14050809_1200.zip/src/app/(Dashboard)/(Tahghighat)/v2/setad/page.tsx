"use client";
import { useCallback, useEffect, useState, type FormEvent } from "react";
import { WorkflowHero, StateChip, EmptyMessage, AppNotice, SectionTitle, workflowStyles as u } from "@/app/(Dashboard)/(Tahghighat)/v2/components/MeratWorkflowUI";
import { meratV2Request, type V2Row } from "@/app/lib/meratV2/client";

const SIZE = 20;
const str = (value: unknown) => value == null ? "—" : String(value);
const num = (value: unknown) => Number(value ?? 0);

export default function SetadPhase1() {
  const [tab, setTab] = useState<"inbox" | "new">("inbox");
  const [fields, setFields] = useState({ codeEntekhabat: "", codeHozeh: "", shomarehParvandeh: "", ostanCityId: "", description: "" });
  const [page, setPage] = useState(1);
  const [rows, setRows] = useState<V2Row[]>([]);
  const [selected, setSelected] = useState<number | null>(null);
  const [detail, setDetail] = useState<V2Row | null>(null);
  const [description, setDescription] = useState("");
  const [confirmed, setConfirmed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    const data = await meratV2Request(`/Api/TahghighV2/SetadInbox?page=${page}&pageSize=${SIZE}`);
    setRows(data);
  }, [page]);

  useEffect(() => {
    if (tab !== "inbox") return;
    let active = true;
    void load().catch(e => { if (active) setError(e instanceof Error ? e.message : "خطای دریافت کارتابل ستاد"); });
    return () => { active = false; };
  }, [load, tab]);

  useEffect(() => {
    if (selected == null) { setDetail(null); return; }
    let active = true;
    setDetail(null); setLoading(true);
    void meratV2Request(`/Api/TahghighV2/SetadReferralDetail?referralId=${selected}`)
      .then(data => { if (active) setDetail(data[0] ?? null); })
      .catch(e => { if (active) setError(e instanceof Error ? e.message : "خطا در جزئیات پرونده"); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [selected]);

  const pending = num(detail?.PendingChildReferrals) > 0 || num(detail?.PendingAssignments) > 0;
  const isReady = !busy && !loading && detail?.StateCode === "SETAD_REVIEW"
    && detail.LastActionCode === "DIRECTOR_APPROVE" && description.trim().length > 0 && confirmed;
  const validOrigin = detail?.ProvinceSubmitAction === "NO_RESEARCH"
    ? typeof detail.NoResearchReason === "string" && detail.NoResearchReason.trim().length > 0
    : detail?.ProvinceSubmitAction === "SUBMIT_DIRECTOR"
      && typeof detail.SummaryText === "string" && detail.SummaryText.trim().length > 0;

  async function perform(actionCode: "SETAD_APPROVE" | "RETURN_PROVINCE") {
    if (!selected || !isReady || (actionCode === "SETAD_APPROVE" && (pending || !validOrigin))) return;
    setBusy(true); setError(""); setNotice("");
    try {
      await meratV2Request("/Api/TahghighV2/SetadAction", { referralId: selected, actionCode, description });
      setSelected(null); setDetail(null); setDescription(""); setConfirmed(false);
      setNotice("اقدام در سرور ثبت شد.");
      await load();
    } catch (e) { setError(e instanceof Error ? e.message : "ثبت اقدام ناموفق بود."); }
    finally { setBusy(false); }
  }

  async function createInitial(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (busy) return;
    setBusy(true); setError(""); setNotice("");
    try {
      const data = await meratV2Request("/Api/TahghighV2/Initial", {
        codeEntekhabat: Number(fields.codeEntekhabat), codeHozeh: Number(fields.codeHozeh),
        shomarehParvandeh: Number(fields.shomarehParvandeh), ostanCityId: Number(fields.ostanCityId),
        description: fields.description
      });
      setNotice(`ارجاع اولیه ثبت شد: ${str(data[0]?.ReferralId)}`);
      setFields({ codeEntekhabat: "", codeHozeh: "", shomarehParvandeh: "", ostanCityId: "", description: "" });
    } catch (e) { setError(e instanceof Error ? e.message : "ثبت ارجاع انجام نشد."); }
    finally { setBusy(false); }
  }

  return <main dir="rtl" className={u.workspace}>
    <WorkflowHero eyebrow="تحقیقات مرآت · فاز اول" title="کارتابل ستاد"
    description="ارسال ارجاع جدید به استان، بررسی نتایج برگشتی و تصمیم نهایی ستاد."
    stats={[{label:"پرونده‌های این صفحه",value:rows.length},{label:"در انتظار اقدام",value:rows.filter(x=>x.StateCode==="SETAD_REVIEW").length},{label:"بخش فعال",value:tab==="inbox"?"بررسی":"ارجاع جدید"}]}/>
    <div style={{ display: "flex", gap: 8, marginBottom: 18 }}>
      <button className={tab === "inbox" ? u.primary : undefined} type="button" aria-pressed={tab === "inbox"} onClick={() => { setTab("inbox"); setError(""); }}>پرونده‌های برگشتی از رئیس دفتر</button>
      <button className={tab === "new" ? u.primary : undefined} type="button" aria-pressed={tab === "new"} onClick={() => { setTab("new"); setError(""); }}>ایجاد ارجاع اولیه</button>
    </div>
    {error && <AppNotice kind="error">{error}</AppNotice>}
    {notice && <AppNotice kind="success">{notice}</AppNotice>}
    {tab === "new" ? <form onSubmit={e => void createInitial(e)} style={{ maxWidth: 700 }}>
      <p>مشخصات پرونده و حوزه باید با اطلاعات واقعی انتخابات مطابقت داشته باشند.</p>
      {([
        ["codeEntekhabat", "کد انتخابات"], ["codeHozeh", "کد حوزه"],
        ["shomarehParvandeh", "شماره پرونده"], ["ostanCityId", "کد استان مقصد"]
      ] as const).map(([key, label]) => <label key={key} style={{ display: "block", marginBottom: 14 }}>
        {label}<input type="number" min="1" required value={fields[key]}
          onChange={e => setFields(old => ({ ...old, [key]: e.target.value }))}
          style={{ display: "block", width: "100%", padding: 8 }}/>
      </label>)}
      <label>شرح ارجاع<textarea required maxLength={6000} rows={4} value={fields.description}
        onChange={e => setFields(old => ({ ...old, description: e.target.value }))}
        style={{ display: "block", width: "100%", padding: 8 }}/></label>
      <button className={u.primary} type="submit" disabled={busy || !fields.description.trim()}>ارسال به استان</button>
    </form> : <>
      <p>پرونده‌های تأییدشده توسط رئیس دفتر که در انتظار تصمیم ستاد هستند.</p>
      <button type="button" onClick={() => void load().catch(e => setError(String(e)))}>بازخوانی</button>
      <span style={{ margin: 12 }}>صفحه {page}</span>
      <button type="button" disabled={page === 1} onClick={() => { setPage(p => p - 1); setSelected(null); }}>قبلی</button>
      <button type="button" disabled={rows.length < SIZE} onClick={() => { setPage(p => p + 1); setSelected(null); }}>بعدی</button>
      <div style={{ overflowX: "auto" }}><table style={{ width: "100%", textAlign: "right", marginTop: 14 }}>
        <thead><tr><th>انتخاب</th><th>شناسه ارجاع</th><th>شماره پرونده</th><th>کد استان</th><th>وضعیت</th></tr></thead>
        <tbody>{rows.map(row => <tr key={str(row.ReferralId)}>
          <td><input type="radio" name="setadReferral" aria-label={`ارجاع ${str(row.ReferralId)}`}
            checked={selected === num(row.ReferralId)}
            onChange={() => { setSelected(num(row.ReferralId)); setDescription(""); setConfirmed(false); setError(""); }}/></td>
          <td>{str(row.ReferralId)}</td><td>{str(row.ShomarehParvandeh)}</td>
          <td>{str(row.OstanCityId)}</td><td>{str(row.StateTitle || row.StateCode)}</td>
        </tr>)}</tbody>
      </table></div>
      {rows.length === 0 && <p>پرونده‌ای در انتظار تصمیم ستاد وجود ندارد.</p>}
      {selected != null && <section style={{ border: "1px solid #aaa", padding: 18, marginTop: 20, borderRadius: 10 }}>
        <h2>بررسی ارجاع {selected}</h2>
        {loading ? <p>در حال دریافت جزئیات...</p> : detail ? <>
          <p>وضعیت: {str(detail.StateTitle)}</p>
          <p>نوع تصمیم استان: {detail.ProvinceSubmitAction === "NO_RESEARCH" ? "عدم نیاز به تحقیق" :
            detail.ProvinceSubmitAction === "SUBMIT_DIRECTOR" ? "ارسال جمع‌بندی" : "نامشخص"}</p>
          {detail.ProvinceSubmitAction === "NO_RESEARCH" ?
            <p><strong>علت عدم نیاز:</strong> {str(detail.NoResearchReason)}</p> :
            <p><strong>جمع‌بندی استان:</strong> {str(detail.SummaryText)}</p>}
          <p>توضیح تأیید رئیس دفتر: {str(detail.LastActionDescription)}</p>
          <p>ارجاعات فرزند باز: {str(detail.PendingChildReferrals)}؛ محققان ناتمام: {str(detail.PendingAssignments)}</p>
          {pending && <p role="alert" style={{ color: "crimson" }}>تا تعیین‌تکلیف ارجاعات باز، تأیید نهایی مجاز نیست.</p>}
          <label style={{ display: "block" }}>شرح تصمیم ستاد (اجباری)
            <textarea rows={4} maxLength={6000} value={description} onChange={e => { setDescription(e.target.value); setConfirmed(false); }}
              style={{ display: "block", width: "100%", padding: 8 }}/>
          </label>
          <label style={{ display: "block", margin: "14px 0" }}>
            <input type="checkbox" checked={confirmed} onChange={e => setConfirmed(e.target.checked)}/>
            اطلاعات پرونده و سوابق تصمیم استان و رئیس دفتر را بررسی کرده‌ام.
          </label>
          <button type="button" disabled={!isReady || pending || !validOrigin} onClick={() => void perform("SETAD_APPROVE")}>تأیید نهایی پرونده</button>
          <button type="button" disabled={!isReady} onClick={() => void perform("RETURN_PROVINCE")} style={{ marginRight: 10 }}>برگشت به استان</button>
        </> : <p>جزئیات پرونده در دسترس نیست.</p>}
      </section>}
    </>}
  </main>;
}
