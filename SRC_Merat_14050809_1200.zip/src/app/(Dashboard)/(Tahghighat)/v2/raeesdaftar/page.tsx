"use client";
import { useCallback, useEffect, useState } from "react";
import { WorkflowHero, StateChip, EmptyMessage, AppNotice, SectionTitle, workflowStyles as u } from "@/app/(Dashboard)/(Tahghighat)/v2/components/MeratWorkflowUI";
import { meratV2Request, type V2Row } from "@/app/lib/meratV2/client";

const PAGE_SIZE = 20;
const textOf = (v: unknown) => v == null ? "—" : String(v);

export default function DirectorV2Inbox() {
  const [rows, setRows] = useState<V2Row[]>([]);
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<number | null>(null);
  const [detail, setDetail] = useState<V2Row | null>(null);
  const [description, setDescription] = useState("");
  const [confirmed, setConfirmed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [detailBusy, setDetailBusy] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const load = useCallback(() => meratV2Request(`/Api/TahghighV2/DirectorInbox?page=${page}&pageSize=${PAGE_SIZE}`)
    .then(result => { setRows(result); return result; }), [page]);

  useEffect(() => {
    let active = true;
    void load().then(() => { if (active) setError(""); })
      .catch(e => { if (active) setError(e instanceof Error ? e.message : "خطای دریافت کارتابل رئیس دفتر"); });
    return () => { active = false; };
  }, [load]);

  useEffect(() => {
    if (selected == null) { setDetail(null); return; }
    let active = true;
    setDetail(null); setDetailBusy(true);
    void meratV2Request(`/Api/TahghighV2/ReferralDetail?referralId=${selected}`)
      .then(data => { if (active) setDetail(data[0] || null); })
      .catch(e => { if (active) setError(e instanceof Error ? e.message : "خطا در جزئیات ارجاع"); })
      .finally(() => { if (active) setDetailBusy(false); });
    return () => { active = false; };
  }, [selected]);

  const hasPending = Number(detail?.PendingChildReferrals || 0) > 0 || Number(detail?.PendingAssignments || 0) > 0;
  const isSubmitted = detail?.LastActionCode === "NO_RESEARCH" || detail?.LastActionCode === "SUBMIT_DIRECTOR";
  const validDecision = detail?.LastActionCode === "NO_RESEARCH"
    ? typeof detail.NoResearchReason === "string" && detail.NoResearchReason.trim().length > 0
    : typeof detail?.SummaryText === "string" && detail.SummaryText.trim().length > 0;
  const ready = !busy && !detailBusy && !!detail && detail.StateCode === "DIRECTOR_REVIEW" && !!description.trim() && confirmed;
  const canApprove = ready && !hasPending && isSubmitted && validDecision;
  const canReturn = ready;

  async function perform(actionCode: "DIRECTOR_APPROVE" | "RETURN_PROVINCE") {
    if (!selected || busy || (actionCode === "DIRECTOR_APPROVE" ? !canApprove : !canReturn)) return;
    setBusy(true); setError(""); setMessage("");
    try {
      await meratV2Request("/Api/TahghighV2/DirectorAction", { referralId: selected, actionCode, description });
      setMessage("اقدام رئیس دفتر توسط سرور ثبت شد.");
      setSelected(null); setDetail(null); setDescription(""); setConfirmed(false);
      await load();
    } catch (e) { setError(e instanceof Error ? e.message : "ثبت اقدام انجام نشد."); }
    finally { setBusy(false); }
  }

  return <main dir="rtl" className={u.workspace}>
    <WorkflowHero eyebrow="تحقیقات مرآت · فاز اول" title="کارتابل رئیس دفتر استان"
      description="بازبینی تصمیم و جمع‌بندی کارشناسان، تأیید یا برگشت پرونده برای اصلاح."
      stats={[{label:"پرونده‌های این صفحه",value:rows.length},{label:"در انتظار تصمیم",value:rows.filter(x=>x.StateCode==="DIRECTOR_REVIEW").length},{label:"انتخاب‌شده",value:selected??"—"}]}/>
    <SectionTitle kicker="صندوق تأیید" title="پرونده‌های در انتظار بررسی"/>
    <button type="button" onClick={() => void load().catch(e => setError(String(e)))}>بازخوانی</button>
    <span style={{ margin: 10 }}>صفحه {page}</span>
    <button type="button" disabled={page === 1} onClick={() => { setPage(p => p - 1); setSelected(null); }}>قبلی</button>
    <button type="button" disabled={rows.length !== PAGE_SIZE} onClick={() => { setPage(p => p + 1); setSelected(null); }}>بعدی</button>
    {error && <AppNotice kind="error">{error}</AppNotice>}
    {message && <AppNotice kind="success">{message}</AppNotice>}
    <div style={{ overflowX: "auto" }}><table style={{ width: "100%", textAlign: "right", marginTop: 16 }}>
      <thead><tr><th>انتخاب</th><th>ارجاع</th><th>پرونده</th><th>کد حوزه</th><th>وضعیت</th></tr></thead>
      <tbody>{rows.map(r => <tr key={textOf(r.ReferralId)}>
        <td><input type="radio" name="selectedReferral" aria-label={`ارجاع ${textOf(r.ReferralId)}`}
          checked={selected === Number(r.ReferralId)} onChange={() => { setSelected(Number(r.ReferralId)); setDescription(""); setConfirmed(false); setError(""); }} /></td>
        <td>{textOf(r.ReferralId)}</td><td>{textOf(r.ShomarehParvandeh)}</td><td>{textOf(r.CodeHozeh)}</td><td><StateChip value={r.StateCode}/></td>
      </tr>)}</tbody>
    </table></div>
    {rows.length === 0 && <EmptyMessage title="پرونده‌ای در انتظار بررسی نیست"/>}
    {selected != null && <section style={{ marginTop: 24, border: "1px solid #bbb", borderRadius: 10, padding: 18 }}>
      <h2>بررسی پرونده — ارجاع {selected}</h2>
      {detailBusy ? <p>در حال دریافت جزئیات...</p> : detail ? <>
        <p>وضعیت: <strong>{textOf(detail.StateTitle)}</strong></p>
        <p>نوع ارسال: <strong>{detail.LastActionCode === "NO_RESEARCH" ? "عدم نیاز به تحقیق" : detail.LastActionCode === "SUBMIT_DIRECTOR" ? "جمع‌بندی تحقیق" : textOf(detail.LastActionCode)}</strong></p>
        <p>ارجاعات فرزند باز: {textOf(detail.PendingChildReferrals)}؛ محققان ناتمام: {textOf(detail.PendingAssignments)}</p>
        {detail.LastActionCode === "NO_RESEARCH" ?
          <p><strong>علت عدم نیاز:</strong> {textOf(detail.NoResearchReason)}</p> :
          <p><strong>جمع‌بندی استان:</strong> {textOf(detail.SummaryText)}</p>}
        {hasPending && <p role="alert" style={{ color: "darkred" }}>تأیید ممنوع است: ارجاع یا محقق ناتمام وجود دارد. برای اصلاح می‌توانید پرونده را برگردانید.</p>}
        <label style={{ display: "block", marginTop: 16, fontWeight: 600 }}>توضیح تصمیم (اجباری)
          <textarea value={description} maxLength={6000} rows={4} onChange={e => { setDescription(e.target.value); setConfirmed(false); }}
            style={{ display: "block", width: "100%", padding: 10, marginTop: 8 }}/>
        </label>
        <label style={{ display: "block", margin: "12px 0" }}>
          <input type="checkbox" checked={confirmed} onChange={e => setConfirmed(e.target.checked)} /> متن پرونده و تصمیم را بررسی کرده‌ام.
        </label>
        <button type="button" disabled={!canApprove} onClick={() => void perform("DIRECTOR_APPROVE")}>تأیید و ارسال به ستاد</button>
        <button type="button" style={{ marginRight: 10 }} disabled={!canReturn} onClick={() => void perform("RETURN_PROVINCE")}>برگشت به کارشناس استان</button>
      </> : <p>جزئیات قابل نمایش نیست.</p>}
    </section>}
  </main>;
}
