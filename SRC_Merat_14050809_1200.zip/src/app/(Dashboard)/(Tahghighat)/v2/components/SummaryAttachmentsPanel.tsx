"use client";
import DocumentAttachmentsPanel from "./DocumentAttachmentsPanel";
type Level = "INVESTIGATOR" | "COUNTY" | "PROVINCE";
const target = {
  INVESTIGATOR: "RESEARCH_ASSIGNMENT",
  COUNTY: "COUNTY_REPLY_EVENT",
  PROVINCE: "PROVINCE_SUMMARY",
} as const;
/** Render only after the summary is persisted. summaryRecordId is AssignmentId / COUNTY_REPLY EventId / ProvinceSummary.SummaryId. */
export default function SummaryAttachmentsPanel({ level, summaryRecordId, readOnly = false }: {
 level: Level; summaryRecordId: number; readOnly?: boolean;
}) {
 return <DocumentAttachmentsPanel targetEntity={target[level]} targetRecordId={summaryRecordId} readOnly={readOnly} />;
}
