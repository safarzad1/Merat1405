import { NextRequest, NextResponse } from "next/server";
import sql from "mssql";

import { getConnection } from "@/lib/db";
import { requireResearchIdentity, researchAccessResponse } from "@/lib/researchSecurity";

export async function POST(req: NextRequest) {
    const token = req.cookies.get("token")?.value;

    if (!token) {
        return NextResponse.json(
            { status: 401, error: "Unauthorized: No token" },
            { status: 401 }
        );
    }

    const body = await req.json();
    const {
        codeentekhabat,
        mahalreciver,
        erjastate, // (فعلاً استفاده نشده)
        page,
        sizepage,
        indexsort,
        ascdesc,
        search,
        idValue, userId
    } = body;

    if (!page) {
        return NextResponse.json({ status: 400, error: "page required" }, { status: 400 });
    }

    try {
        await requireResearchIdentity(token, userId);
    } catch (error) {
        return researchAccessResponse(error);
    }

    try {
        const pool = await getConnection();
        const result = await pool
            .request()
            .input("CodeEntekhabat", sql.Int, codeentekhabat)
            .input("MahalReciver", sql.Int, mahalreciver)
            // .input("ErjaLastState", sql.Int, erjastate)
            .input("Page", sql.Int, page)
            .input("SizePage", sql.Int, sizepage)
            .input("Search", sql.NVarChar(200), search ?? "")
            .input("SortIndex", sql.Int, indexsort ?? 1)
            .input("SECDEC", sql.Int, ascdesc ?? 1)
            .input("ItemValue", sql.Int, idValue ?? 0)
            .input("UserId", sql.BigInt, userId ?? 0)
            .execute("Tahghighat.SP_Get_Erja_MahalReciver_ErjaLastState");

        return NextResponse.json({ status: 200, data: result.recordset }, { status: 200 });
    } catch (err) {
        return researchAccessResponse(err);
    }
}
