import { NextRequest, NextResponse } from "next/server";
import { getAuthenticatedUserId } from "./authBridge";
import { getMeratPool, sql } from "./db";

export class ApiError extends Error {
  constructor(public status: number, public code: string, message: string) {
    super(message);
  }
}

export function requiredInt(value: unknown, name: string): number {
  const num = typeof value === "number" ? value :
    (typeof value === "string" && /^\d+$/.test(value) ? Number(value) : NaN);
  if (!Number.isSafeInteger(num) || num <= 0)
    throw new ApiError(400, "INVALID_INPUT", `${name} نامعتبر است.`);
  return num;
}

export function requiredText(value: unknown, name: string, max = 6000): string {
  if (typeof value !== "string") throw new ApiError(400, "INVALID_INPUT", `${name} الزامی است.`);
  const result = value.trim();
  if (!result || result.length > max)
    throw new ApiError(400, "INVALID_INPUT", `${name} باید بین ۱ تا ${max} نویسه باشد.`);
  return result;
}

export function action(value: unknown, allowed: readonly string[]): string {
  if (typeof value !== "string" || !allowed.includes(value))
    throw new ApiError(400, "INVALID_ACTION", "اقدام انتخاب‌شده مجاز نیست.");
  return value;
}

export async function jsonBody(req: NextRequest): Promise<Record<string, unknown>> {
  if (!(req.headers.get("content-type") || "").toLowerCase().startsWith("application/json"))
    throw new ApiError(415, "CONTENT_TYPE", "نوع درخواست باید JSON باشد.");
  // Content-Length is optional and cannot be trusted as the sole size limit.
  const declared = Number(req.headers.get("content-length") || 0);
  if (declared > 50000) throw new ApiError(413, "TOO_LARGE", "حجم درخواست زیاد است.");
  let raw: string;
  try { raw = await req.text(); }
  catch { throw new ApiError(400, "INVALID_JSON", "بدنه درخواست خوانده نشد."); }
  if (Buffer.byteLength(raw, "utf8") > 50000)
    throw new ApiError(413, "TOO_LARGE", "حجم درخواست زیاد است.");
  let parsed: unknown;
  try { parsed = JSON.parse(raw) as unknown; }
  catch { throw new ApiError(400, "INVALID_JSON", "بدنه درخواست نامعتبر است."); }
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed))
    throw new ApiError(400, "INVALID_JSON", "بدنه درخواست باید یک شیء باشد.");
  return parsed as Record<string, unknown>;
}

export function requireSameOrigin(req: NextRequest): void {
  const expected = process.env.MERAT_V2_PUBLIC_ORIGIN;
  if (!expected) throw new Error("MERAT_V2_PUBLIC_ORIGIN_NOT_CONFIGURED");
  const origin = req.headers.get("origin");
  if (!origin || origin !== new URL(expected).origin)
    throw new ApiError(403, "ORIGIN", "مبدأ درخواست معتبر نیست.");
}

export async function authenticatedUserId(): Promise<number> {
  const userId = await getAuthenticatedUserId();
  if (!Number.isSafeInteger(userId) || userId <= 0)
    throw new ApiError(401, "AUTH_REQUIRED", "ابتدا وارد سامانه شوید.");
  return userId;
}

export async function execute(
  procedure: string,
  bindings: (request: sql.Request) => void,
): Promise<Record<string, unknown>[]> {
  // Procedures must be hardcoded by the route, never taken from a request.
  const pool = await getMeratPool();
  const request = pool.request();
  bindings(request);
  const result = await request.execute(procedure);
  return (result.recordset ?? []) as Record<string, unknown>[];
}

/** Every mutation must return an explicit success signal from its stored procedure. */
export async function executeMutation(
  procedure: string,
  bindings: (request: sql.Request) => void,
): Promise<Record<string, unknown>[]> {
  const rows = await execute(procedure, bindings);
  if (rows.length !== 1 || rows[0]?.IsSuccess !== true && rows[0]?.IsSuccess !== 1)
    throw new ApiError(409, "DB_SAVE_UNCONFIRMED", "ثبت عملیات توسط پایگاه داده تأیید نشد.");
  return rows;
}

export function respond(rows: Record<string, unknown>[]) {
  return NextResponse.json({ ok: true, data: rows }, { headers: { "Cache-Control": "no-store" } });
}

export function fail(error: unknown) {
  if (error instanceof ApiError)
    return NextResponse.json({ ok: false, code: error.code, message: error.message }, { status: error.status, headers: { "Cache-Control": "no-store" } });
  // SQL Server business errors use THROW in the 52xxx–54xxx range; return only these to the user.
  const dbError = error as { number?: unknown; originalError?: { info?: { number?: number } }; message?: unknown };
  const number = typeof dbError?.number === "number" ? dbError.number : dbError?.originalError?.info?.number;
  if (typeof number === "number" && number >= 52000 && number < 55000)
    return NextResponse.json({ ok: false, code: `SQL_${number}`, message: String(dbError.message || "عملیات مجاز نیست.") }, { status: 409, headers: { "Cache-Control": "no-store" } });
  console.error("TahghighV2 API error", error);
  return NextResponse.json({ ok: false, code: "SERVER_ERROR", message: "خطای داخلی سرور؛ عملیات انجام نشد." }, { status: 500, headers: { "Cache-Control": "no-store" } });
}
