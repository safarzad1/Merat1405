import * as sql from "mssql";

let poolPromise: Promise<sql.ConnectionPool> | undefined;

function env(name: string): string {
  const value = process.env[name];
  if (!value) throw new Error(`Missing SQL configuration: ${name}`);
  return value;
}

export async function getMeratPool(): Promise<sql.ConnectionPool> {
  if (!poolPromise) {
    const pool = new sql.ConnectionPool({
      server: env("MERAT_SQL_SERVER"),
      database: "MeratDB",
      user: env("MERAT_SQL_USER"),
      password: env("MERAT_SQL_PASSWORD"),
      options: {
        encrypt: process.env.MERAT_SQL_ENCRYPT !== "false",
        trustServerCertificate: process.env.MERAT_SQL_TRUST_SERVER_CERTIFICATE === "true",
        appName: "Merat-Research-V2-Phase1",
      },
      pool: { max: 10, min: 0, idleTimeoutMillis: 30000 },
      requestTimeout: 30000,
      connectionTimeout: 15000,
    });
    poolPromise = pool.connect().catch((error) => {
      poolPromise = undefined;
      throw error;
    });
  }
  return poolPromise;
}

export { sql };
