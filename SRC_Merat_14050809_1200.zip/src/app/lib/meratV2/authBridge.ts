/**
 * SECURITY BOUNDARY. Wire to the existing Merat SERVER-SIDE authenticated session.
 * Do not read userId from JSON, query strings, a plain cookie or request headers.
 * Default intentionally fails closed until the project's real auth is connected.
 */
export async function getAuthenticatedUserId(): Promise<number> {
  throw new Error("MERAT_V2_AUTH_BRIDGE_NOT_CONFIGURED");
}
