﻿/*
  MeratDB | Tahghighat V2
  Special Province Investigator Identity Mapping Fix (Phase 54)

  The legacy SP_Get_MohagheghInEntekhabat defines province eligibility from
  an active Hamkari.PersonHamkari record (MahalHamkari prefix). Users.Mahal
  is the login's administrative scope and is not a reliable identity key.

  Phase 54 maps a legacy collaborator to an existing active dbo.Users account
  by exact PersonId. It prefers one active account in the province hierarchy;
  if none exists, it accepts a globally unique active account because the
  legacy procedure has already established active collaboration in this
  province. Ambiguous accounts are never auto-linked.

  Registry ProvinceCityId remains the province root. Investigator authorization
  is based on an active, province-scoped InvestigatorRegistry row plus an
  active login; it no longer incorrectly rejects the same person because the
  login's Users.Mahal is another administrative location.

  No account is created, password changed, user activated, or Users.Mahal
  modified. Existing conflicting/inactive registry rows are not overwritten.
*/
USE [MeratDB];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

IF OBJECT_ID(N'dbo.Users', N'U') IS NULL
   OR OBJECT_ID(N'dbo.Citys', N'U') IS NULL
   OR OBJECT_ID(N'TahghighatV2.InvestigatorRegistry', N'U') IS NULL
   OR OBJECT_ID(N'TahghighatV2.ResearchAssignment', N'U') IS NULL
   OR OBJECT_ID(N'TahghighatV2.Referral', N'U') IS NULL
BEGIN
    THROW 55311, N'پیش‌نیازهای اتصال محققان ویژه استان در تحقیقات V2 نصب نشده‌اند.', 1;
END;
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [TahghighatV2].[SP_AssignProvinceInvestigator]
 @ReferralId bigint,@InvestigatorKey bigint,@Instruction nvarchar(max),
 @UserId bigint,@DueDatePersian char(10)=NULL
AS
BEGIN
  SET NOCOUNT ON; SET XACT_ABORT ON;
  IF @ReferralId IS NULL OR @ReferralId<=0 OR @InvestigatorKey IS NULL OR @InvestigatorKey<=0
   OR @UserId IS NULL OR @UserId<=0 OR NULLIF(LTRIM(RTRIM(@Instruction)),N'') IS NULL
   THROW 53710,N'ارجاع، محقق، کاربر و شرح ماموریت الزامی هستند.',1;
  DECLARE @Province int,@PostId int,@InvUser bigint,@ParentId bigint,@RootId bigint,
          @State varchar(40),@Lock int,@AssignmentId bigint,@Before varchar(40);
  SELECT @Province=Mahal,@PostId=PostId FROM dbo.Users WHERE UserId=@UserId AND IsActive=1;
  IF @PostId NOT IN(51,52) OR NOT EXISTS(SELECT 1 FROM dbo.Citys
       WHERE CityId=@Province AND PCityId=1 AND IsActive=1)
     OR NOT EXISTS(SELECT 1 FROM TahghighatV2.PostActionPermission
        WHERE PostId=@PostId AND ActionCode='ASSIGN_INVESTIGATOR' AND IsAllowed=1)
      THROW 53711,N'مجوز کارشناس استان برای ارجاع به محقق معتبر نیست.',1;
  SELECT @InvUser=r.AuthUserId FROM TahghighatV2.InvestigatorRegistry r
  JOIN dbo.Users u ON u.UserId=r.AuthUserId AND u.IsActive=1
  WHERE r.InvestigatorKey=@InvestigatorKey AND r.IsActive=1 AND r.ProvinceCityId=@Province;
  IF @InvUser IS NULL THROW 53712,N'محقق تاییدشده و فعال برای این استان یافت نشد.',1;
  SELECT @ParentId=r.ParentReferralId FROM TahghighatV2.Referral r WHERE r.ReferralId=@ReferralId;
  SET @RootId=COALESCE(@ParentId,@ReferralId);
  BEGIN TRY
    BEGIN TRANSACTION;
    DECLARE @LockName nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(20),@RootId);
    EXEC @Lock=sys.sp_getapplock @Resource=@LockName,@LockMode=N'Exclusive',@LockOwner=N'Transaction',@LockTimeout=10000;
    IF @Lock<0 THROW 53713,N'پرونده در حال پردازش است.',1;
    SELECT @State=r.StateCode,@Before=r.StateCode FROM TahghighatV2.Referral r WITH(UPDLOCK,HOLDLOCK)
    WHERE r.ReferralId=@ReferralId AND r.ToMahal=@Province AND r.ReceiverLevel='OSTAN'
     AND r.IsClosed=0 AND r.IsDeleted=0 AND (r.ParentReferralId IS NULL OR r.ParentReferralId=@RootId);
    IF @State IS NULL OR (@ParentId IS NOT NULL AND NOT EXISTS
       (SELECT 1 FROM TahghighatV2.Referral p WHERE p.ReferralId=@ParentId
        AND p.ParentReferralId IS NULL AND p.IsClosed=0 AND p.IsDeleted=0))
      THROW 53714,N'ارجاع فعال استان یا والد معتبر یافت نشد.',1;
    IF NOT EXISTS(SELECT 1 FROM TahghighatV2.ActionTransition
       WHERE FromStateCode=@State AND ActionCode='ASSIGN_INVESTIGATOR' AND ToStateCode=@State)
       THROW 53715,N'در وضعیت فعلی ارجاع به محقق مجاز نیست.',1;
    IF EXISTS(SELECT 1 FROM TahghighatV2.ResearchAssignment WITH(UPDLOCK,HOLDLOCK)
      WHERE ReferralId=@ReferralId AND InvestigatorId=@InvestigatorKey
        AND StatusCode IN('PENDING','IN_PROGRESS'))
       THROW 53716,N'ارجاع باز به همین محقق وجود دارد.',1;
    INSERT TahghighatV2.ResearchAssignment
     (ReferralId,InvestigatorId,DueDatePersian,Instruction,StatusCode,CreatedByUserId)
    VALUES(@ReferralId,@InvestigatorKey,@DueDatePersian,@Instruction,'PENDING',@UserId);
    SET @AssignmentId=CONVERT(bigint,SCOPE_IDENTITY());
    INSERT TahghighatV2.ResearchAssignmentEvent(AssignmentId,ActionCode,BeforeStatus,AfterStatus,Description,ActorUserId)
    VALUES(@AssignmentId,'ASSIGN_INVESTIGATOR',NULL,'PENDING',@Instruction,@UserId);
    INSERT TahghighatV2.WorkflowEvent(ReferralId,ActionCode,PreviousStateCode,NewStateCode,Description,ActorUserId)
    VALUES(@ReferralId,'ASSIGN_INVESTIGATOR',@State,@State,
      N'ارجاع تحقیق به محقق تاییدشده؛ شماره انتساب '+CONVERT(nvarchar(25),@AssignmentId),@UserId);
    COMMIT TRANSACTION;
    SELECT CONVERT(bit,1) AS IsSuccess,@AssignmentId AS AssignmentId,@ReferralId AS ReferralId;
  END TRY
  BEGIN CATCH
    IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
    THROW;
  END CATCH;
END;

GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [TahghighatV2].[SP_GetInvestigatorInbox]
 @UserId bigint,@Page int=1,@PageSize int=25
AS
BEGIN
  SET NOCOUNT ON;
  IF @UserId IS NULL OR @UserId<=0 OR @Page IS NULL OR @Page<1
    OR @PageSize IS NULL OR @PageSize NOT BETWEEN 1 AND 100
    THROW 53760,N'مشخصات کارتابل محقق نامعتبر است.',1;
  IF NOT EXISTS (SELECT 1 FROM TahghighatV2.InvestigatorRegistry i
       JOIN dbo.Users u ON u.UserId=i.AuthUserId AND u.IsActive=1
       JOIN dbo.Citys c ON c.CityId=i.ProvinceCityId AND c.IsActive=1 AND c.PCityId=1
       WHERE i.AuthUserId=@UserId AND i.IsActive=1)
       THROW 53761,N'محقق فعال و ثبت‌شده یافت نشد.',1;
  SELECT a.AssignmentId,a.ReferralId,a.StatusCode,a.DueDatePersian,a.Instruction,
    a.CreatedAtUtc,c.CaseId,c.CodeEntekhabat,c.CodeHozeh,c.ShomarehParvandeh,
    COUNT_BIG(*) OVER() AS TotalCount
  FROM TahghighatV2.ResearchAssignment a
  JOIN TahghighatV2.InvestigatorRegistry i ON i.InvestigatorKey=a.InvestigatorId
  JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId
  JOIN TahghighatV2.CaseFile c ON c.CaseId=r.CaseId
  JOIN dbo.Users u ON u.UserId=i.AuthUserId AND u.IsActive=1
  WHERE i.AuthUserId=@UserId AND i.IsActive=1 AND r.ToMahal=i.ProvinceCityId
    AND r.IsDeleted=0 AND r.IsClosed=0 AND a.StatusCode IN('PENDING','IN_PROGRESS')
  ORDER BY a.CreatedAtUtc DESC,a.AssignmentId DESC
  OFFSET (CONVERT(bigint,@Page)-1)*@PageSize ROWS FETCH NEXT @PageSize ROWS ONLY;
END;

GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [TahghighatV2].[SP_GetProvinceInvestigatorCandidates]
 @UserId bigint
AS
BEGIN
 SET NOCOUNT ON;
 IF @UserId IS NULL OR @UserId<=0 THROW 54101,N'شناسه کاربر نامعتبر است.',1;
 DECLARE @Province int,@PostId int;
 SELECT @Province=u.Mahal,@PostId=u.PostId FROM dbo.Users u
 WHERE u.UserId=@UserId AND u.IsActive=1;
 IF @PostId NOT IN(51,52)
  OR NOT EXISTS(SELECT 1 FROM dbo.Citys c
      WHERE c.CityId=@Province AND c.PCityId=1 AND c.IsActive=1)
  OR NOT EXISTS(SELECT 1 FROM TahghighatV2.PostActionPermission p
      WHERE p.PostId=@PostId AND p.ActionCode='ASSIGN_INVESTIGATOR' AND p.IsAllowed=1)
  THROW 54102,N'امکان مشاهده محققان استان برای این کاربر وجود ندارد.',1;
 SELECT r.InvestigatorKey,r.AuthUserId,r.ProvinceCityId
 FROM TahghighatV2.InvestigatorRegistry r
 JOIN dbo.Users u ON u.UserId=r.AuthUserId AND u.IsActive=1
 WHERE r.ProvinceCityId=@Province AND r.IsActive=1
 ORDER BY r.InvestigatorKey;
END;

GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [TahghighatV2].[SP_GetAssignmentWorksheets]
 @AssignmentId bigint,@UserId bigint
AS
BEGIN
  SET NOCOUNT ON;
  IF @AssignmentId IS NULL OR @AssignmentId<=0 OR @UserId IS NULL OR @UserId<=0
    THROW 53770,N'شناسه تحقیق یا کاربر معتبر نیست.',1;
  DECLARE @UserMahal bigint,@Province int,@PostId int,@InvestigatorKey bigint,@RefId bigint;
  SELECT @UserMahal=u.Mahal,@PostId=u.PostId FROM dbo.Users u WHERE u.UserId=@UserId AND u.IsActive=1;
  SELECT @InvestigatorKey=a.InvestigatorId,@RefId=r.ReferralId,@Province=CONVERT(int,r.ToMahal)
  FROM TahghighatV2.ResearchAssignment a JOIN TahghighatV2.Referral r
   ON r.ReferralId=a.ReferralId AND r.ReceiverLevel='OSTAN' AND r.IsDeleted=0
  WHERE a.AssignmentId=@AssignmentId;
  IF @RefId IS NULL OR NOT (
       EXISTS(SELECT 1 FROM TahghighatV2.InvestigatorRegistry i
          JOIN dbo.Users u ON u.UserId=i.AuthUserId AND u.IsActive=1
          WHERE i.InvestigatorKey=@InvestigatorKey AND i.AuthUserId=@UserId
            AND i.ProvinceCityId=@Province AND i.IsActive=1)
       OR (@PostId IN(51,52) AND @UserMahal=@Province AND EXISTS
         (SELECT 1 FROM TahghighatV2.PostActionPermission p WHERE p.PostId=@PostId
          AND p.ActionCode='ASSIGN_INVESTIGATOR' AND p.IsAllowed=1)))
     THROW 53771,N'مجوز مشاهده کاربرگ این تحقیق را ندارید.',1;
  SELECT WorksheetId,AssignmentId,ReportText,CreatedByUserId,CreatedAtUtc
  FROM TahghighatV2.ResearchWorksheet
  WHERE AssignmentId=@AssignmentId ORDER BY WorksheetId ASC;
END;

GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [TahghighatV2].[SP_InvestigatorAction]
 @AssignmentId bigint,@ActionCode varchar(40),@UserId bigint,@Summary nvarchar(max)=NULL
AS
BEGIN
  SET NOCOUNT ON; SET XACT_ABORT ON;
  IF @AssignmentId IS NULL OR @AssignmentId<=0 OR @UserId IS NULL OR @UserId<=0
    OR @ActionCode NOT IN('INVESTIGATOR_START','CLOSE_ASSIGNMENT') OR @ActionCode IS NULL
    THROW 53720,N'شناسه انتساب یا اقدام محقق معتبر نیست.',1;
  IF @ActionCode='CLOSE_ASSIGNMENT' AND NULLIF(LTRIM(RTRIM(@Summary)),N'') IS NULL
    THROW 53721,N'برای تکمیل تحقیق، جمع‌بندی محقق اجباری است.',1;
  DECLARE @ReferralId bigint,@RootId bigint,@Province int,@State varchar(20),
          @RefState varchar(40),@InvKey bigint,@Lock int,@Next varchar(20);
  SELECT @ReferralId=a.ReferralId FROM TahghighatV2.ResearchAssignment a WHERE a.AssignmentId=@AssignmentId;
  IF @ReferralId IS NULL THROW 53722,N'انتساب تحقیق یافت نشد.',1;
  SELECT @RootId=COALESCE(r.ParentReferralId,r.ReferralId) FROM TahghighatV2.Referral r
    WHERE r.ReferralId=@ReferralId;
  BEGIN TRY
    BEGIN TRANSACTION;
    DECLARE @LockName nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(20),@RootId);
    EXEC @Lock=sys.sp_getapplock @Resource=@LockName,@LockMode=N'Exclusive',@LockOwner=N'Transaction',@LockTimeout=10000;
    IF @Lock<0 THROW 53723,N'پرونده در حال پردازش است.',1;
    IF NOT EXISTS(SELECT 1 FROM TahghighatV2.Referral root
      WHERE root.ReferralId=@RootId AND root.IsClosed=0 AND root.IsDeleted=0
        AND root.ParentReferralId IS NULL)
      THROW 53729,N'ارجاع اصلی پرونده بسته یا نامعتبر است.',1;
    SELECT @InvKey=a.InvestigatorId,@State=a.StatusCode,@Province=r.ToMahal,@RefState=r.StateCode
    FROM TahghighatV2.ResearchAssignment a WITH(UPDLOCK,HOLDLOCK)
    JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId AND r.IsClosed=0 AND r.IsDeleted=0
    WHERE a.AssignmentId=@AssignmentId AND a.ReferralId=@ReferralId AND r.ReceiverLevel='OSTAN';
    IF @State IS NULL THROW 53724,N'انتساب یا ارجاع فعال یافت نشد.',1;
    IF NOT EXISTS(SELECT 1 FROM TahghighatV2.InvestigatorRegistry i
      JOIN dbo.Users u ON u.UserId=i.AuthUserId AND u.IsActive=1
      WHERE i.InvestigatorKey=@InvKey AND i.AuthUserId=@UserId AND i.ProvinceCityId=@Province AND i.IsActive=1)
      THROW 53725,N'فقط محقق فعال ثبت‌شده می‌تواند روی انتساب خودش اقدام کند.',1;
    IF @RefState NOT IN('PROVINCE_WORKING','PENDING_CHILD_RESULTS','PROVINCE_RETURNED','CHILD_WORKING')
       THROW 53726,N'پرونده در وضعیت مجاز برای تحقیق نیست.',1;
    SET @Next=CASE WHEN @ActionCode='INVESTIGATOR_START' THEN 'IN_PROGRESS' ELSE 'DONE' END;
    IF (@ActionCode='INVESTIGATOR_START' AND @State<>'PENDING')
      OR (@ActionCode='CLOSE_ASSIGNMENT' AND @State<>'IN_PROGRESS')
      THROW 53727,N'تغییر وضعیت انتساب مجاز نیست.',1;
    IF @ActionCode='CLOSE_ASSIGNMENT' AND NOT EXISTS(
      SELECT 1 FROM TahghighatV2.ResearchWorksheet w WHERE w.AssignmentId=@AssignmentId
         AND NULLIF(LTRIM(RTRIM(w.ReportText)),N'') IS NOT NULL)
      THROW 53728,N'ابتدا حداقل یک کاربرگ معتبر ثبت کنید.',1;
    UPDATE TahghighatV2.ResearchAssignment
      SET StatusCode=@Next,Summary=CASE WHEN @Next='DONE' THEN @Summary ELSE Summary END,
          FinishedAtUtc=CASE WHEN @Next='DONE' THEN SYSUTCDATETIME() ELSE NULL END
      WHERE AssignmentId=@AssignmentId;
    INSERT TahghighatV2.ResearchAssignmentEvent
      (AssignmentId,ActionCode,BeforeStatus,AfterStatus,Description,ActorUserId)
    VALUES(@AssignmentId,@ActionCode,@State,@Next,
      CASE WHEN @ActionCode='CLOSE_ASSIGNMENT' THEN N'ثبت پایان تحقیق و جمع‌بندی' ELSE N'شروع تحقیق' END,@UserId);
    INSERT TahghighatV2.WorkflowEvent(ReferralId,ActionCode,PreviousStateCode,NewStateCode,Description,ActorUserId)
    VALUES(@ReferralId,@ActionCode,@RefState,@RefState,
      N'اقدام محقق؛ شناسه انتساب '+CONVERT(nvarchar(25),@AssignmentId),@UserId);
    COMMIT TRANSACTION;
    SELECT CONVERT(bit,1) AS IsSuccess,@AssignmentId AS AssignmentId,@Next AS AssignmentStatus;
  END TRY
  BEGIN CATCH
    IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
    THROW;
  END CATCH;
END;

GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [TahghighatV2].[SP_SaveResearchWorksheet]
 @AssignmentId bigint,@ReportText nvarchar(max),@UserId bigint
AS
BEGIN
  SET NOCOUNT ON; SET XACT_ABORT ON;
  IF @AssignmentId IS NULL OR @AssignmentId<=0 OR @UserId IS NULL OR @UserId<=0
     OR NULLIF(LTRIM(RTRIM(@ReportText)),N'') IS NULL
    THROW 53730,N'شناسه انتساب، کاربر و متن کاربرگ الزامی است.',1;
  DECLARE @ReferralId bigint,@RootId bigint,@InvKey bigint,@Province int,@RefState varchar(40),
          @Status varchar(20),@Lock int,@WorksheetId bigint;
  SELECT @ReferralId=ReferralId FROM TahghighatV2.ResearchAssignment WHERE AssignmentId=@AssignmentId;
  IF @ReferralId IS NULL THROW 53731,N'انتساب یافت نشد.',1;
  SELECT @RootId=COALESCE(ParentReferralId,ReferralId) FROM TahghighatV2.Referral WHERE ReferralId=@ReferralId;
  BEGIN TRY
    BEGIN TRANSACTION;
    DECLARE @LockName nvarchar(255)=N'MRV2:REF:'+CONVERT(nvarchar(20),@RootId);
    EXEC @Lock=sys.sp_getapplock @Resource=@LockName,@LockMode=N'Exclusive',@LockOwner=N'Transaction',@LockTimeout=10000;
    IF @Lock<0 THROW 53732,N'پرونده در حال پردازش است.',1;
    IF NOT EXISTS(SELECT 1 FROM TahghighatV2.Referral root
      WHERE root.ReferralId=@RootId AND root.IsClosed=0 AND root.IsDeleted=0
        AND root.ParentReferralId IS NULL)
      THROW 53737,N'ارجاع اصلی پرونده بسته یا نامعتبر است.',1;
    SELECT @InvKey=a.InvestigatorId,@Status=a.StatusCode,@Province=r.ToMahal,@RefState=r.StateCode
    FROM TahghighatV2.ResearchAssignment a WITH(UPDLOCK,HOLDLOCK)
    JOIN TahghighatV2.Referral r ON r.ReferralId=a.ReferralId
      AND r.IsClosed=0 AND r.IsDeleted=0 AND r.ReceiverLevel='OSTAN'
    WHERE a.AssignmentId=@AssignmentId;
    IF @Status<>'IN_PROGRESS' OR @Status IS NULL
       THROW 53733,N'ثبت کاربرگ تنها در زمان انجام تحقیق فعال مجاز است.',1;
    IF @RefState NOT IN('PROVINCE_WORKING','PENDING_CHILD_RESULTS','PROVINCE_RETURNED','CHILD_WORKING')
       THROW 53734,N'ارجاع در وضعیت مجاز نیست.',1;
    IF NOT EXISTS(SELECT 1 FROM TahghighatV2.InvestigatorRegistry i
      JOIN dbo.Users u ON u.UserId=i.AuthUserId AND u.IsActive=1
      WHERE i.InvestigatorKey=@InvKey AND i.AuthUserId=@UserId AND i.ProvinceCityId=@Province AND i.IsActive=1)
       THROW 53735,N'امکان ثبت کاربرگ محقق دیگر وجود ندارد.',1;
    INSERT TahghighatV2.ResearchWorksheet(AssignmentId,ReportText,CreatedByUserId)
      VALUES(@AssignmentId,@ReportText,@UserId);
    SET @WorksheetId=CONVERT(bigint,SCOPE_IDENTITY());
    INSERT TahghighatV2.ResearchAssignmentEvent
      (AssignmentId,ActionCode,BeforeStatus,AfterStatus,Description,ActorUserId)
    VALUES(@AssignmentId,'SAVE_RESEARCH_WORKSHEET',@Status,@Status,
      N'ثبت کاربرگ '+CONVERT(nvarchar(25),@WorksheetId),@UserId);
    INSERT TahghighatV2.WorkflowEvent
      (ReferralId,ActionCode,PreviousStateCode,NewStateCode,Description,ActorUserId)
    VALUES(@ReferralId,'SAVE_RESEARCH_WORKSHEET',@RefState,@RefState,
      N'ثبت کاربرگ محقق؛ شماره انتساب '+CONVERT(nvarchar(25),@AssignmentId),@UserId);
    COMMIT TRANSACTION;
    SELECT CONVERT(bit,1) AS IsSuccess,@WorksheetId AS WorksheetId;
  END TRY
  BEGIN CATCH
    IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
    THROW;
  END CATCH;
END;
GO
PRINT N'اصلاح تطبیق هویت محققان ویژه استان و مجوز کارتابل V2 با موفقیت نصب شد.';
GO
