import { NextRequest } from "next/server";
import { authenticatedUserId, executeMutation, fail, jsonBody, requireSameOrigin, requiredInt, requiredText, action, respond } from "@/app/lib/meratV2/api";
import { sql } from "@/app/lib/meratV2/db";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export async function POST(req: NextRequest) {
  try {
    requireSameOrigin(req);
    const userId = await authenticatedUserId();
    const body = await jsonBody(req);
    const rows = await executeMutation("TahghighatV2.SP_SetadAction", q => q
      .input("ReferralId", sql.BigInt, requiredInt(body.referralId, "ارجاع"))
      .input("ActionCode", sql.VarChar(40), action(body.actionCode, ["SETAD_APPROVE", "RETURN_PROVINCE"]))
      .input("Description", sql.NVarChar(sql.MAX), requiredText(body.description, "توضیحات", 6000))
      .input("UserId", sql.BigInt, userId));
    return respond(rows);
  } catch (e) { return fail(e); }
}
