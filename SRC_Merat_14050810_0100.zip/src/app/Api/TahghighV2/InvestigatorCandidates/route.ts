import { NextRequest } from "next/server";
import { ApiError, authenticatedUserId, fail, respond, requiredInt } from "@/app/lib/meratV2/api";
import { getMeratPool, sql } from "@/app/lib/meratV2/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Returns the legacy special-province collaborators and links each one to an
 * existing active login by the immutable PersonId. The legacy procedure has
 * already restricted candidates by active PersonHamkari in this province
 * (MahalHamkari prefix); Users.Mahal is only the login's administrative scope
 * and is not a reliable identity key for a person who collaborates in more
 * than one place.
 */
export async function GET(req: NextRequest) {
  try {
    const userId = await authenticatedUserId();
    const referralId = requiredInt(
      req.nextUrl.searchParams.get("referralId"),
      "شناسه ارجاع"
    );

    const pool = await getMeratPool();

    // Resolve the province and election code from the authenticated user's
    // own referral. Never accept CodeEntekhabat or Mahal from the client.
    const scopeResult = await pool.request()
      .input("UserId", sql.BigInt, userId)
      .input("ReferralId", sql.BigInt, referralId)
      .query(`
        SELECT TOP (1)
          CONVERT(int, u.Mahal) AS ProvinceCityId,
          cf.CodeEntekhabat
        FROM dbo.Users u
        JOIN TahghighatV2.Referral r
          ON r.ReferralId = @ReferralId
         AND r.ToMahal = u.Mahal
         AND r.ReceiverLevel = 'OSTAN'
         AND r.IsDeleted = 0
        JOIN TahghighatV2.CaseFile cf ON cf.CaseId = r.CaseId
        JOIN dbo.Citys c
          ON c.CityId = u.Mahal
         AND c.PCityId = 1
         AND c.IsActive = 1
        WHERE u.UserId = @UserId
          AND u.IsActive = 1
          AND u.PostId IN (51, 52);
      `);

    const scope = scopeResult.recordset?.[0];
    if (!scope) {
      throw new ApiError(
        403,
        "PROVINCE_SCOPE_DENIED",
        "دسترسی مشاهده محققان ویژه برای این پرونده و استان وجود ندارد."
      );
    }

    // This is the same authoritative procedure used by the legacy UI.
    const legacyResult = await pool.request()
      .input("CodeEntekhabat", sql.Int, Number(scope.CodeEntekhabat))
      .input("Mahal", sql.Int, Number(scope.ProvinceCityId))
      .input("NoeHamkari", sql.Int, 2)
      .input("Vije", sql.Int, 1)
      .execute("Tahghighat.SP_Get_MohagheghInEntekhabat");

    const legacyRows = (legacyResult.recordset || [])
      .map((row: Record<string, unknown>) => ({
        legacyCode: String(row.ShomarehParvandeh ?? ""),
        personId: String(row.PersonId ?? ""),
        fullName: String(
          row.FullName ??
          [row.FirstName, row.LastName].filter(Boolean).join(" ")
        ).trim(),
      }))
      .filter((row: { legacyCode: string; personId: string; fullName: string }) =>
        /^\d+$/.test(row.legacyCode) &&
        /^\d+$/.test(row.personId) &&
        row.fullName.length > 0
      );

    if (legacyRows.length === 0) return respond([]);

    const mappingResult = await pool.request()
      .input("ProvinceCityId", sql.Int, Number(scope.ProvinceCityId))
      .input("CandidatesJson", sql.NVarChar(sql.MAX), JSON.stringify(legacyRows))
      .query(`
        SET NOCOUNT ON;
        SET XACT_ABORT ON;

        DECLARE @Candidates TABLE
        (
          LegacyCodeMohaghegh bigint NOT NULL PRIMARY KEY,
          PersonId bigint NOT NULL,
          FullName nvarchar(500) NOT NULL
        );

        ;WITH Parsed AS
        (
          SELECT LegacyCodeMohaghegh, PersonId, FullName,
                 ROW_NUMBER() OVER
                   (PARTITION BY LegacyCodeMohaghegh ORDER BY PersonId) AS rn
          FROM OPENJSON(@CandidatesJson)
          WITH
          (
            LegacyCodeMohaghegh bigint '$.legacyCode',
            PersonId bigint '$.personId',
            FullName nvarchar(500) '$.fullName'
          )
          WHERE LegacyCodeMohaghegh IS NOT NULL
            AND PersonId IS NOT NULL
        )
        INSERT INTO @Candidates(LegacyCodeMohaghegh, PersonId, FullName)
        SELECT LegacyCodeMohaghegh, PersonId, FullName
        FROM Parsed WHERE rn = 1;

        DECLARE @CandidateStats TABLE
        (
          PersonId bigint NOT NULL PRIMARY KEY,
          CandidateCodeCount bigint NOT NULL
        );
        INSERT INTO @CandidateStats(PersonId, CandidateCodeCount)
        SELECT PersonId, COUNT_BIG(*)
        FROM @Candidates
        GROUP BY PersonId;

        /*
          Prefer the one active login located in the province hierarchy.
          If there is no such login, accept a globally unique active login
          for the same PersonId. This fallback is safe because the legacy
          procedure above has already verified active collaboration in this
          province using PersonHamkari.MahalHamkari.
          Multiple active accounts remain deliberately ambiguous.
        */
        DECLARE @ActiveUsers TABLE
        (
          PersonId bigint NOT NULL,
          UserId bigint NOT NULL,
          IsInProvince bit NOT NULL,
          PRIMARY KEY(PersonId, UserId)
        );

        INSERT INTO @ActiveUsers(PersonId, UserId, IsInProvince)
        SELECT DISTINCT c.PersonId, u.UserId,
          CONVERT(bit, CASE
            WHEN u.Mahal = @ProvinceCityId THEN 1
            WHEN EXISTS
            (
              SELECT 1 FROM dbo.Citys userCity
              WHERE userCity.CityId = u.Mahal
                AND userCity.PCityId = @ProvinceCityId
                AND userCity.IsActive = 1
            ) THEN 1
            ELSE 0
          END)
        FROM @Candidates c
        JOIN dbo.Users u
          ON u.PersonId = c.PersonId
         AND u.IsActive = 1;

        DECLARE @AccountStats TABLE
        (
          PersonId bigint NOT NULL PRIMARY KEY,
          ActiveCount bigint NOT NULL,
          ProvinceActiveCount bigint NOT NULL
        );
        INSERT INTO @AccountStats(PersonId, ActiveCount, ProvinceActiveCount)
        SELECT PersonId, COUNT_BIG(*),
               SUM(CONVERT(bigint, IsInProvince))
        FROM @ActiveUsers
        GROUP BY PersonId;

        DECLARE @UniqueMatches TABLE
        (
          LegacyCodeMohaghegh bigint NOT NULL PRIMARY KEY,
          PersonId bigint NOT NULL,
          UserId bigint NOT NULL UNIQUE
        );

        ;WITH PreferredAccounts AS
        (
          SELECT a.PersonId, a.UserId,
                 ROW_NUMBER() OVER
                 (
                   PARTITION BY a.PersonId
                   ORDER BY CASE WHEN a.IsInProvince = 1 THEN 0 ELSE 1 END,
                            a.UserId
                 ) AS rn
          FROM @ActiveUsers a
          JOIN @AccountStats s ON s.PersonId = a.PersonId
          WHERE
            (s.ProvinceActiveCount = 1 AND a.IsInProvince = 1)
            OR (s.ProvinceActiveCount = 0 AND s.ActiveCount = 1)
        ),
        Resolved AS
        (
          SELECT c.LegacyCodeMohaghegh, c.PersonId, p.UserId,
                 COUNT_BIG(*) OVER(PARTITION BY p.UserId) AS UserIdentityCount
          FROM @Candidates c
          JOIN @CandidateStats cs
            ON cs.PersonId = c.PersonId AND cs.CandidateCodeCount = 1
          JOIN PreferredAccounts p
            ON p.PersonId = c.PersonId AND p.rn = 1
        )
        INSERT INTO @UniqueMatches(LegacyCodeMohaghegh, PersonId, UserId)
        SELECT LegacyCodeMohaghegh, PersonId, UserId
        FROM Resolved
        WHERE UserIdentityCount = 1;

        BEGIN TRY
          BEGIN TRANSACTION;
          DECLARE @LockResult int;
          DECLARE @LockResource nvarchar(255) =
            N'MRV2:INVREG:' + CONVERT(nvarchar(20), @ProvinceCityId);
          EXEC @LockResult = sys.sp_getapplock
            @Resource = @LockResource,
            @LockMode = 'Exclusive',
            @LockOwner = 'Transaction',
            @LockTimeout = 10000;
          IF @LockResult < 0
            THROW 55321, N'قفل اتصال محققان استان دریافت نشد؛ دوباره تلاش کنید.', 1;

          /* Fill an existing active registry row for the same user/province. */
          UPDATE ir
             SET ir.LegacyCodeMohaghegh = um.LegacyCodeMohaghegh
          FROM TahghighatV2.InvestigatorRegistry ir WITH (UPDLOCK, HOLDLOCK)
          JOIN @UniqueMatches um
            ON um.UserId = ir.AuthUserId
           AND ir.ProvinceCityId = @ProvinceCityId
          WHERE ir.IsActive = 1
            AND (ir.LegacyCodeMohaghegh IS NULL
                 OR ir.LegacyCodeMohaghegh = um.LegacyCodeMohaghegh);

          /* Create only missing links; never overwrite another identity. */
          INSERT INTO TahghighatV2.InvestigatorRegistry
            (AuthUserId, LegacyCodeMohaghegh, ProvinceCityId, IsActive,
             RegisteredBySqlLogin, RegisteredAtUtc)
          SELECT um.UserId, um.LegacyCodeMohaghegh, @ProvinceCityId, 1,
                 COALESCE(ORIGINAL_LOGIN(), SUSER_SNAME()), SYSUTCDATETIME()
          FROM @UniqueMatches um
          WHERE NOT EXISTS
            (SELECT 1 FROM TahghighatV2.InvestigatorRegistry existing WITH (UPDLOCK, HOLDLOCK)
             WHERE existing.AuthUserId = um.UserId
               AND existing.ProvinceCityId = @ProvinceCityId)
            AND NOT EXISTS
            (SELECT 1 FROM TahghighatV2.InvestigatorRegistry existing WITH (UPDLOCK, HOLDLOCK)
             WHERE existing.LegacyCodeMohaghegh = um.LegacyCodeMohaghegh
               AND existing.ProvinceCityId = @ProvinceCityId);

          COMMIT TRANSACTION;
        END TRY
        BEGIN CATCH
          IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
          THROW;
        END CATCH;

        SELECT
          ir.InvestigatorKey,
          ir.AuthUserId,
          c.LegacyCodeMohaghegh,
          c.PersonId,
          c.FullName,
          CONVERT(bit, CASE WHEN ir.InvestigatorKey IS NOT NULL THEN 1 ELSE 0 END) AS IsAssignable,
          CASE
            WHEN ir.InvestigatorKey IS NOT NULL THEN N''
            WHEN ISNULL(cs.CandidateCodeCount, 0) > 1
              THEN N'برای این شناسه فرد چند کد محقق ثبت شده است؛ اتصال باید بررسی شود.'
            WHEN ISNULL(ast.ProvinceActiveCount, 0) > 1
              THEN N'برای این همکار چند حساب فعال در محدوده استان وجود دارد؛ اتصال باید بررسی شود.'
            WHEN ISNULL(ast.ActiveCount, 0) > 1 AND ISNULL(ast.ProvinceActiveCount, 0) = 0
              THEN N'برای این همکار چند حساب فعال وجود دارد؛ اتصال باید بررسی شود.'
            WHEN ISNULL(ast.ActiveCount, 0) = 0
              THEN N'برای این همکار حساب کاربری فعال وجود ندارد.'
            WHEN EXISTS
              (SELECT 1 FROM @UniqueMatches um
               JOIN TahghighatV2.InvestigatorRegistry existing
                 ON existing.AuthUserId = um.UserId
                AND existing.ProvinceCityId = @ProvinceCityId
                AND existing.IsActive = 0
               WHERE um.LegacyCodeMohaghegh = c.LegacyCodeMohaghegh)
              THEN N'اتصال V2 این محقق غیرفعال است؛ فعال‌سازی باید توسط مدیر انجام شود.'
            WHEN EXISTS
              (SELECT 1 FROM @UniqueMatches um
               JOIN TahghighatV2.InvestigatorRegistry existing
                 ON existing.AuthUserId = um.UserId
                AND existing.ProvinceCityId = @ProvinceCityId
               WHERE um.LegacyCodeMohaghegh = c.LegacyCodeMohaghegh
                 AND existing.LegacyCodeMohaghegh IS NOT NULL
                 AND existing.LegacyCodeMohaghegh <> um.LegacyCodeMohaghegh)
              THEN N'این حساب به کد محقق دیگری متصل است؛ اتصال هویتی باید بررسی شود.'
            WHEN EXISTS
              (SELECT 1 FROM TahghighatV2.InvestigatorRegistry existing
               WHERE existing.LegacyCodeMohaghegh = c.LegacyCodeMohaghegh
                 AND existing.ProvinceCityId = @ProvinceCityId)
              THEN N'کد محقق به حساب دیگری متصل است؛ اتصال هویتی باید بررسی شود.'
            ELSE N'اتصال حساب این محقق در V2 کامل نشد؛ اطلاعات کاربر و ثبت اتصال بررسی شود.'
          END AS MappingMessage
        FROM @Candidates c
        LEFT JOIN @CandidateStats cs ON cs.PersonId = c.PersonId
        LEFT JOIN @AccountStats ast ON ast.PersonId = c.PersonId
        OUTER APPLY
        (
          SELECT TOP (1) r.InvestigatorKey, r.AuthUserId
          FROM @UniqueMatches um
          JOIN TahghighatV2.InvestigatorRegistry r
            ON r.AuthUserId = um.UserId
           AND r.LegacyCodeMohaghegh = um.LegacyCodeMohaghegh
           AND r.ProvinceCityId = @ProvinceCityId
           AND r.IsActive = 1
          JOIN dbo.Users u ON u.UserId = r.AuthUserId AND u.IsActive = 1
          WHERE um.LegacyCodeMohaghegh = c.LegacyCodeMohaghegh
          ORDER BY r.InvestigatorKey
        ) ir
        ORDER BY c.FullName, c.LegacyCodeMohaghegh;
      `);

    return respond((mappingResult.recordset || []) as Record<string, unknown>[]);
  } catch (error) {
    return fail(error);
  }
}
