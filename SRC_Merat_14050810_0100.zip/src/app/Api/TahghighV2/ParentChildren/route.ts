import { NextRequest } from "next/server";
import { authenticatedUserId, execute, fail, requiredInt, respond } from "@/app/lib/meratV2/api";
import { sql } from "@/app/lib/meratV2/db";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export async function GET(req: NextRequest) {
  try {
    const userId = await authenticatedUserId();
    const parent = requiredInt(req.nextUrl.searchParams.get("parentReferralId"), "ارجاع اصلی");
    const rows = await execute("TahghighatV2.SP_GetParentChildren", query => query
      .input("ParentReferralId", sql.BigInt, parent)
      .input("UserId", sql.BigInt, userId));
    return respond(rows);
  } catch (error) { return fail(error); }
}
