"use client";

import { meratConfirm } from "@/component/MeratFeedback/feedback";
import { showToast } from "@/component/CustomToast";

import { useCallback, useEffect, useRef, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { useMeratUser } from "@/lib/useMeratUser";
import { meratV2Request, type V2Row } from "@/app/lib/meratV2/client";
import InputPersianDate, { getTodayJalali } from "@/component/Objects/InputPersianDatePicker";
import SummaryAttachmentsPanel from "@/app/(Dashboard)/(Tahghighat)/v2/components/SummaryAttachmentsPanel";
import styles from "./ProvinceCase.module.css";

type ReferralForm = "HOZE" | "OSTAN" | "INVESTIGATOR" | null;
type Level = "HOZE" | "OSTAN";
const stateNames: Record<string, string> = {
  PROVINCE_INBOX: "پیشخوان استان", PROVINCE_WORKING: "در حال بررسی استان",
  PROVINCE_RETURNED: "برگشت به کارشناس استان",
  DIRECTOR_REVIEW: "در انتظار رئیس دفتر", SETAD_REVIEW: "در انتظار ستاد",
  PENDING_CHILD_RESULTS: "در انتظار پاسخ ارجاعات", APPROVED: "تأیید نهایی",
  CHILD_INBOX: "پیشخوان مقصد", CHILD_WORKING: "در حال بررسی مقصد", CHILD_REPLIED: "پاسخ ارسال‌شده"
};
const readable = (v: unknown) => v == null || v === "" ? "—" : String(v);
const asNum = (v: unknown) => Number(v ?? 0);
const activeProvinceStates = ["PROVINCE_INBOX", "PROVINCE_WORKING", "PROVINCE_RETURNED"];
const editableStates = ["PROVINCE_WORKING", "PROVINCE_RETURNED"];

export default function ProvinceCaseDetails() {
  const router = useRouter();
  const params = useParams();
  const user = useMeratUser();
  const referralId = Number(params?.referralId);
  const validId = Number.isSafeInteger(referralId) && referralId > 0;
  const authorizedRole = [51, 52].includes(Number(user.PostId));
  const [detail, setDetail] = useState<V2Row | null>(null);
  const [identity, setIdentity] = useState<V2Row | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState<ReferralForm>(null);
  const [openPanels, setOpenPanels] = useState<Record<string, boolean>>({});
  const [description, setDescription] = useState("");
  const [summary, setSummary] = useState("");
  const [destinationType, setDestinationType] = useState<Level>("HOZE");
  const [destinations, setDestinations] = useState<V2Row[]>([]);
  const [destination, setDestination] = useState("");
  const [delegateReason, setDelegateReason] = useState("");
  const [children, setChildren] = useState<V2Row[]>([]);
  const [candidates, setCandidates] = useState<V2Row[]>([]);
  const [assignments, setAssignments] = useState<V2Row[]>([]);
  const [investigatorKey, setInvestigatorKey] = useState("");
  const [investigatorReason, setInvestigatorReason] = useState("");
  const [dueDate, setDueDate] = useState(() => getTodayJalali());
  const [cancelAssignmentId, setCancelAssignmentId] = useState<number | null>(null);
  const [cancelReason, setCancelReason] = useState("");
  const [summaryId, setSummaryId] = useState<number | null>(null);
  const [summaryReadOnly, setSummaryReadOnly] = useState(true);
  // Destination and investigator lists are only requested when their picker is opened.
  const [pickerOpen, setPickerOpen] = useState(false);
  const [pickerLoading, setPickerLoading] = useState(false);
  const [pickerError, setPickerError] = useState("");
  const [pickerSearch, setPickerSearch] = useState("");
  const pickerRequestId = useRef(0);
  const [trackingError, setTrackingError] = useState("");
  const [assignmentError, setAssignmentError] = useState("");
  const [summaryTargetError, setSummaryTargetError] = useState("");

  const refreshDetail = useCallback(async () => {
    if (!validId) throw new Error("شناسه ارجاع معتبر نیست.");
    const [item] = await meratV2Request(`/Api/TahghighV2/ReferralDetail?referralId=${referralId}`);
    if (!item) throw new Error("جزئیات پرونده در محدوده دسترسی شما یافت نشد.");
    setDetail(item);
    setSummary(String(item.SummaryText ?? ""));
  }, [validId, referralId]);

  const refreshTracking = useCallback(async () => {
    if (!validId) return;
    const result = await meratV2Request(`/Api/TahghighV2/ParentChildren?parentReferralId=${referralId}`);
    setChildren(result);
  }, [validId, referralId]);

  const refreshAssignments = useCallback(async () => {
    if (!validId) return;
    const result = await meratV2Request(`/Api/TahghighV2/ProvinceAssignments?referralId=${referralId}`);
    setAssignments(result);
  }, [validId, referralId]);

  const refreshSummaryTarget = useCallback(async () => {
    if (!validId) return;
    const [item] = await meratV2Request(`/Api/TahghighV2/ProvinceSummaryAttachmentTarget?referralId=${referralId}`);
    const id = asNum(item?.SummaryId);
    setSummaryId(Number.isSafeInteger(id) && id > 0 ? id : null);
    setSummaryReadOnly(!Boolean(item?.CanWrite));
  }, [validId, referralId]);

  useEffect(() => {
    if (!validId) { setLoading(false); setError("شناسه ارجاع نامعتبر است."); return; }
    if (!user.UserId || !user.PostId) return;
    if (!authorizedRole) { setLoading(false); setError("صفحه اقدامات استان فقط برای کارشناسان مجاز استان است."); return; }
    let live = true;
    setLoading(true); setError("");
    // Core case details are independent of optional destination/identity lookups.
    // A secondary endpoint failure must never hide the case or block valid actions.
    void meratV2Request(`/Api/TahghighV2/ReferralDetail?referralId=${referralId}`)
      .then(items => {
        if (!live) return;
        if (!items[0]) throw new Error("ارجاع مجاز برای این کاربر یافت نشد.");
        setDetail(items[0]); setSummary(String(items[0].SummaryText ?? ""));
      }).catch(e => { if (live) setError(e instanceof Error ? e.message : String(e)); })
      .finally(() => { if (live) setLoading(false); });
    void meratV2Request(`/Api/TahghighV2/ReferralIdentity?referralId=${referralId}`)
      .then(items => { if (live) setIdentity(items[0] || null); })
      .catch(() => { if (live) setIdentity(null); });
    return () => { live = false; };
  }, [validId, referralId, user.UserId, user.PostId, authorizedRole]);

  useEffect(() => {
    if (!validId || !authorizedRole || !detail) return;
    let active = true;
    // These read-only sections must not block the case or display a global error.
    // InvestigatorCandidates and ReferralDestinations are intentionally NOT loaded here.
    void Promise.allSettled([
      refreshTracking(), refreshAssignments(), refreshSummaryTarget()
    ]).then(results => {
      if (!active) return;
      const reason = (result: PromiseSettledResult<void>) =>
        result.status === "rejected" ? (result.reason instanceof Error ? result.reason.message : String(result.reason)) : "";
      setTrackingError(reason(results[0]));
      setAssignmentError(reason(results[1]));
      setSummaryTargetError(reason(results[2]));
    });
    return () => { active = false; };
  }, [validId, authorizedRole, Boolean(detail), referralId, refreshAssignments, refreshTracking, refreshSummaryTarget]);

  async function mutate(path: string, data: Record<string, unknown>, message: string) {
    if (busy) return;
    setBusy(true); setError("");
    try {
      await meratV2Request(path, data);
      showToast.success(message, "تحقیقات استان");
      await refreshDetail();
      await Promise.allSettled([refreshTracking(), refreshAssignments(), refreshSummaryTarget()]);
      return true;
    } catch(e) {
      setError(e instanceof Error ? e.message : "ثبت عملیات ناموفق بود.");
      return false;
    } finally { setBusy(false); }
  }

  const state = String(detail?.StateCode ?? "");
  const canWork = !busy && !loading && Boolean(detail) && activeProvinceStates.includes(state) && !Boolean(detail?.IsClosed);
  const canStart = canWork && state === "PROVINCE_INBOX";
  // While child referrals are waiting for replies, the province may still add
  // more Hoze/province referrals and assign more special investigators.
  // Final decisions remain separately guarded by canWork/canNoResearch.
  const canDelegate = !busy && !loading && Boolean(detail) && !Boolean(detail?.IsClosed)
    && (editableStates.includes(state) || state === "PENDING_CHILD_RESULTS");
  const canSummary = canDelegate;
  const hasPending = asNum(detail?.PendingChildReferrals) > 0 || asNum(detail?.PendingAssignments) > 0;
  const isDirectorSendReady = canDelegate && !hasPending && String(detail?.SummaryText ?? "").trim().length > 0;
  const canNoResearch = canWork && !hasPending;
  const canAssign = canDelegate;

  async function provinceAction(actionCode: "START_PROVINCE" | "NO_RESEARCH" | "SUBMIT_DIRECTOR") {
    if (!canWork) return;
    if (actionCode !== "START_PROVINCE" && !description.trim()) { setError("توضیحات تصمیم را وارد کنید."); return; }
    if (actionCode === "NO_RESEARCH" && (!canNoResearch || !await meratConfirm("عدم نیاز به تحقیق ثبت و پرونده برای رئیس دفتر ارسال شود؟"))) return;
    if (actionCode === "SUBMIT_DIRECTOR" && (!isDirectorSendReady || !await meratConfirm("جمع‌بندی برای رئیس دفتر ارسال شود؟"))) return;
    const ok = await mutate("/Api/TahghighV2/ProvinceAction", {
      referralId, actionCode, description: description.trim()
    }, actionCode === "START_PROVINCE" ? "بررسی استان آغاز شد." : "تصمیم ثبت و به رئیس دفتر ارسال شد.");
    if (ok) setDescription("");
  }

  async function delegate() {
    if (!canDelegate || !destination || !delegateReason.trim()) return;
    const selectedCity = destinations.find(r => r.TargetLevel === destinationType && String(r.DestinationCityId) === destination);
    // The referral modal's own submit button is the user's confirmation.
    // Do not show a second confirmation dialog for this modal action.
    if (!selectedCity || !Boolean(selectedCity.CanRefer)) return;
    const ok = await mutate("/Api/TahghighV2/DelegateChild", {
      parentReferralId: referralId, destinationCityId: Number(destination),
      targetLevel: destinationType, description: delegateReason.trim(),
    }, "ارجاع زیرمجموعه با موفقیت ثبت شد.");
    if (ok) { setDestination(""); setDelegateReason(""); closeForm(); setOpenPanels(prev => ({...prev, [destinationType]: true})); }
  }

  async function saveSummary() {
    if (!canSummary || !summary.trim()) return;
    await mutate("/Api/TahghighV2/ProvinceSummary", {referralId, summaryText: summary.trim()}, "جمع‌بندی استان ذخیره شد.");
  }

  async function assign() {
    if (!canAssign || !investigatorKey || !investigatorReason.trim()) return;
    const ok = await mutate("/Api/TahghighV2/ProvinceAssignInvestigator", {
      referralId, investigatorKey: Number(investigatorKey), instruction: investigatorReason.trim(),
      dueDatePersian: dueDate || null,
    }, "ارجاع به محقق استان ثبت شد.");
    if (ok) { setInvestigatorKey(""); setInvestigatorReason(""); setDueDate(getTodayJalali()); closeForm(); setOpenPanels(prev => ({...prev, INVESTIGATOR: true})); }
  }

  async function cancelAssignment() {
    if (cancelAssignmentId === null || !cancelReason.trim()) return;
    const ok = await mutate("/Api/TahghighV2/ProvinceCancelAssignment", {
      assignmentId: cancelAssignmentId, reason: cancelReason.trim()
    }, "انتساب با ثبت دلیل لغو شد.");
    if (ok) { setCancelAssignmentId(null); setCancelReason(""); }
  }

  const personName = [identity?.FirstName, identity?.LastName].filter(Boolean).join(" ") || `پرونده ${readable(detail?.ShomarehParvandeh)}`;
  const hozeName = String(identity?.NameHozeh || "").trim();
  const provinceName = String(identity?.NameOstan || "").trim();
  const activeFormType: Level = form === "OSTAN" ? "OSTAN" : "HOZE";
  // در هر دو نوع ارجاع، فقط مقصدهایی نمایش داده می‌شوند که گیرنده فعال و مجاز دارند.
  // این فیلتر مکمل فیلتر سمت API است و جایگزین کنترل مجوز در SQL هنگام ثبت ارجاع نیست.
  const modalDestinations = destinations.filter(item =>
    item.TargetLevel === activeFormType && Boolean(item.CanRefer)
  );
  const searchKey = pickerSearch.trim().toLocaleLowerCase("fa");
  const choiceRows = form === "INVESTIGATOR" ? candidates : modalDestinations;
  const visibleChoices = choiceRows.filter(item =>
    String(form === "INVESTIGATOR" ? item.FullName ?? "" : item.DestinationName ?? "")
      .toLocaleLowerCase("fa").includes(searchKey)
  );
  // Keep the inline selector compact. Additional rows are revealed by search,
  // while the modal body remains the only scroll container.
  const displayedChoices = visibleChoices.slice(0, searchKey ? 12 : 6);
  const countFor = (kind: "HOZE" | "OSTAN") => children.filter(r => r.ReceiverLevel === kind);
  const doneFor = (kind: "HOZE" | "OSTAN") => countFor(kind).filter(r => Boolean(r.IsClosed)).length;
  const togglePanel = (key: string) => setOpenPanels(prev => ({...prev, [key]: !prev[key]}));
  const closeForm = () => {
    pickerRequestId.current += 1; // Ignore a response from a previously closed picker.
    setPickerOpen(false); setPickerLoading(false); setPickerError("");
    setForm(null);
  };
  const openForm = (type: Exclude<ReferralForm, null>) => {
    pickerRequestId.current += 1;
    setPickerOpen(false); setPickerLoading(false); setPickerError(""); setPickerSearch("");
    setError("");
    if (type !== "INVESTIGATOR") {
      setDestinationType(type); setDestination(""); setDelegateReason("");
    } else { setInvestigatorReason(""); setDueDate(getTodayJalali()); }
    setForm(type);
  };
  // Clicking the actual dropdown is the only trigger for these three lookup APIs.
  const togglePicker = async () => {
    if (pickerOpen) {
      pickerRequestId.current += 1;
      setPickerOpen(false); setPickerLoading(false);
      return;
    }
    if (!form) return;
    const requestId = ++pickerRequestId.current;
    const currentForm = form;
    setPickerOpen(true);
    setPickerLoading(true);
    setPickerError("");
    setPickerSearch("");
    try {
      const url = currentForm === "INVESTIGATOR"
        ? `/Api/TahghighV2/InvestigatorCandidates?referralId=${encodeURIComponent(referralId)}`
        : "/Api/TahghighV2/ReferralDestinations";
      const rows = await meratV2Request(url);
      if (requestId !== pickerRequestId.current) return;
      if (currentForm === "INVESTIGATOR") setCandidates(rows);
      else setDestinations(rows);
    } catch (e) {
      if (requestId === pickerRequestId.current) {
        setPickerError(e instanceof Error ? e.message : "دریافت فهرست امکان‌پذیر نیست.");
      }
    } finally {
      if (requestId === pickerRequestId.current) setPickerLoading(false);
    }
  };
  const choosePickerItem = (row: V2Row) => {
    if (form === "INVESTIGATOR") {
      if (!row.InvestigatorKey || !Boolean(row.IsAssignable)) return;
      setInvestigatorKey(String(row.InvestigatorKey));
    } else {
      setDestination(String(row.DestinationCityId ?? ""));
    }
    setPickerOpen(false);
    pickerRequestId.current += 1;
  };
  const formatDate = (value: unknown) => {
    if (!value) return "—";
    const d = new Date(String(value));
    return Number.isNaN(d.getTime()) ? String(value).slice(0, 10) : new Intl.DateTimeFormat("fa-IR-u-ca-persian", { year: "numeric", month: "2-digit", day: "2-digit" }).format(d);
  };
  const delegateItems = (kind: "HOZE" | "OSTAN") => countFor(kind);
  const renderDelegations = (kind: "HOZE" | "OSTAN") => {
    const title = kind === "HOZE" ? "ارجاع به حوزه انتخابیه" : "ارجاع به استان دیگر";
    const items = delegateItems(kind);
    return <section className={`${styles.referralPanel} ${kind === "HOZE" ? styles.hozePanel : styles.provincePanel}`} key={kind}>
      <div className={styles.panelHeading}>
        <button type="button" className={styles.panelTitle} onClick={() => togglePanel(kind)} aria-expanded={Boolean(openPanels[kind])}>
          <span className={styles.chevron}>{openPanels[kind] ? "▾" : "▸"}</span>
          <strong>{title}</strong>
          <span className={styles.countGray} title="تعداد کل ارجاعات">{items.length.toLocaleString("fa-IR")}</span>
          <span className={styles.countGreen} title="تعداد پاسخ‌ها">{doneFor(kind).toLocaleString("fa-IR")}</span>
          <span className={styles.groupHint}>{kind === "HOZE" ? "زیرمجموعه‌های داخل استان" : "زیرمجموعه‌های بین‌استانی"}</span>
        </button>
        <button className={styles.addButton} type="button" disabled={!canDelegate} onClick={() => openForm(kind)}>⊕ {title}</button>
      </div>
      {openPanels[kind] && <div className={styles.panelBody}>
        {trackingError && <p role="alert" className={styles.error}>خطا در دریافت ارجاعات: {trackingError}</p>}
        {items.length === 0 ? <p className={styles.hint}>برای این بخش هنوز ارجاعی ثبت نشده است.</p> :
          <div className={styles.childList}>
            {items.map((row,i) => {
              const received = Boolean(row.IsClosed);
              const destinationName = destinations.find(d =>
                Number(d.DestinationCityId) === Number(row.ToMahal) && d.TargetLevel === kind
              )?.DestinationName || row.ToMahal;
              return <article className={`${styles.childCard} ${received ? styles.childReceived : styles.childWaiting}`} key={readable(row.ReferralId)}>
                <span className={styles.childIndex}>{(i+1).toLocaleString("fa-IR")}</span>
                <div className={styles.childContent}>
                  <div className={styles.childTitleRow}>
                    <strong>{readable(destinationName)}</strong>
                    <span className={`${styles.childStatus} ${received ? styles.statusReceived : styles.statusWaiting}`}>
                      {received ? "پاسخ دریافت شد" : "در انتظار پاسخ"}
                    </span>
                  </div>
                  <div className={styles.childMeta}>
                    <span>شناسه ارجاع: {readable(row.ReferralId)}</span>
                    <span>{stateNames[String(row.StateCode)] || readable(row.StateCode)}</span>
                  </div>
                </div>
              </article>;
            })}
          </div>}
      </div>}
    </section>;
  };

  return <main className={styles.page} dir="rtl">
    <div className={styles.breadcrumb}>
      <button type="button" onClick={() => router.push("/Dashboard")}>داشبورد</button><span>/</span>
      <button type="button" onClick={() => router.push("/TahghighatManage")}>مدیریت تحقیقات</button><span>/</span>
      <span className={styles.crumbPerson}>{detail ? `پرونده ${personName}${provinceName ? `، ${provinceName}` : ""}${hozeName ? ` - ${hozeName}` : ""}` : "پرونده استان"}</span>
      <button className={styles.backLink} type="button" onClick={() => router.push("/TahghighatManage")}>بازگشت به پیشخوان</button>
    </div>
    {error && <div role="alert" className={styles.error}>{error}</div>}
    {loading && <div className={styles.empty}>در حال دریافت پرونده…</div>}
    {!loading && !detail && <div className={styles.empty}>جزئیات پرونده قابل نمایش نیست. دسترسی و شناسه ارجاع را بررسی کنید.</div>}
    {detail && <>
      <div className={`${styles.metaBar} ${styles.mainCaseBar}`}>
        <span className={styles.mainCaseBadge}>پرونده اصلی</span>
        <span><b>فرستنده:</b> {readable(identity?.NameSender || "ستاد")}</span>
        <span><b>تاریخ ارجاع:</b> {formatDate(detail.CreatedAtUtc)}</span>
        <span className={styles.metaDescription}><b>توضیحات:</b> {readable(detail.ReferralDescription)}</span>
        <span className={styles.metaState}>{readable(detail.StateTitle) === "—" ? (stateNames[state] || state) : readable(detail.StateTitle)}</span>
        <button type="button" className={styles.outlineButton} onClick={() => togglePanel("tracking")}>پیگیری ارجاعات</button>
        {canStart && <button type="button" className={styles.addButton} onClick={() => void provinceAction("START_PROVINCE")} disabled={busy}>شروع بررسی استان</button>}
        <button type="button" className={styles.yellowButton} onClick={() => {togglePanel("decision");}} disabled={!canWork}>عدم نیاز به تحقیق</button>
        <button type="button" className={styles.greenButton} onClick={() => {setOpenPanels(prev => ({...prev, summary:true}));}}>جمع‌بندی پرونده</button>
      </div>
      {openPanels.decision && <section className={styles.compactBox}>
        <strong>تصمیم کارشناسی استان</strong>
        {hasPending && <div className={styles.warning}>قبل از تصمیم نهایی باید همه ارجاعات و تحقیقات باز تعیین‌تکلیف شوند.</div>}
        <textarea className={styles.field} rows={3} maxLength={6000} disabled={!canWork} value={description}
          onChange={e => setDescription(e.target.value)} placeholder="توضیحات یا علت عدم نیاز به تحقیق را وارد کنید…"/>
        <div className={styles.actions}>
          <button className={styles.yellowButton} type="button" disabled={!canNoResearch || !description.trim()} onClick={() => void provinceAction("NO_RESEARCH")}>ثبت عدم نیاز و ارسال به رئیس دفتر</button>
          <button className={styles.greenButton} type="button" disabled={!isDirectorSendReady || !description.trim()} onClick={() => void provinceAction("SUBMIT_DIRECTOR")}>ارسال جمع‌بندی به رئیس دفتر</button>
          <button className={styles.outlineButton} type="button" onClick={() => togglePanel("decision")}>بستن</button>
        </div>
      </section>}
      {renderDelegations("HOZE")}
      {renderDelegations("OSTAN")}
      <section className={`${styles.referralPanel} ${styles.investigatorPanel}`}>
        <div className={styles.panelHeading}>
          <button type="button" className={styles.panelTitle} onClick={() => togglePanel("INVESTIGATOR")} aria-expanded={Boolean(openPanels.INVESTIGATOR)}>
            <span className={styles.chevron}>{openPanels.INVESTIGATOR ? "▾" : "▸"}</span>
            <strong>ارجاع به محقق ویژه استان</strong>
            <span className={styles.countGray} title="تعداد محققان ارجاع‌شده">{assignments.length.toLocaleString("fa-IR")}</span>
            <span className={styles.countGreen} title="تحقیقات انجام‌شده">{assignments.filter(r => r.StatusCode === "DONE").length.toLocaleString("fa-IR")}</span>
          </button>
          <button className={styles.addButton} type="button" disabled={!canAssign} onClick={() => openForm("INVESTIGATOR")}>⊕ ارجاع به محقق ویژه استان</button>
        </div>
        {openPanels.INVESTIGATOR && <div className={styles.panelBody}>
          {assignmentError && <p role="alert" className={styles.error}>خطا در پیگیری محققان پرونده: {assignmentError}</p>}
          {assignments.length === 0 ? <p className={styles.hint}>محققی به این پرونده ارجاع نشده است.</p> : <div className={`${styles.childList} ${styles.investigatorList}`}>
            {assignments.map((row,i) => <article className={`${styles.childCard} ${styles.investigatorCard}`} key={readable(row.AssignmentId)}>
              <span className={styles.childIndex}>{(i+1).toLocaleString("fa-IR")}</span>
              <div className={styles.childContent}>
                <div className={styles.childTitleRow}>
                  <strong>{readable(candidates.find(c => Number(c.InvestigatorKey) === Number(row.InvestigatorKey))?.FullName || row.AuthUserId || row.InvestigatorKey)}</strong>
                  <span className={`${styles.childStatus} ${row.StatusCode === "DONE" ? styles.statusReceived : styles.statusWaiting}`}>{readable(row.StatusCode)}</span>
                </div>
                <div className={styles.childMeta}>
                  <span>کاربرگ‌ها: {readable(row.WorksheetCount)}</span>
                  <span>شناسه انتساب: {readable(row.AssignmentId)}</span>
                  {["PENDING","IN_PROGRESS"].includes(String(row.StatusCode)) && canAssign ?
                    <button type="button" className={styles.linkButton} onClick={() => { setCancelAssignmentId(asNum(row.AssignmentId));setCancelReason(""); }}>لغو انتساب</button> : null}
                </div>
              </div>
            </article>)}
          </div>}
          {cancelAssignmentId !== null && <div className={styles.cancelBox}>
            <strong>لغو انتساب محقق</strong>
            <textarea className={styles.field} rows={2} maxLength={2000} disabled={busy} value={cancelReason} placeholder="دلیل لغو را وارد کنید" onChange={e => setCancelReason(e.target.value)}/>
            <div className={styles.actions}><button className={styles.primary} disabled={busy || !cancelReason.trim()} type="button" onClick={() => void cancelAssignment()}>تأیید لغو</button>
              <button type="button" className={styles.outlineButton} onClick={() => setCancelAssignmentId(null)}>انصراف</button></div>
          </div>}
        </div>}
      </section>
      <section className={styles.referralPanel}>
        <div className={styles.panelHeading}>
          <button className={styles.panelTitle} type="button" onClick={() => togglePanel("summary")} aria-expanded={Boolean(openPanels.summary)}>
            <span className={styles.chevron}>{openPanels.summary ? "▾" : "▸"}</span><strong>جمع‌بندی استان و اسناد پیوست</strong>
          </button>
          <button className={styles.greenButton} type="button" onClick={() => setOpenPanels(prev => ({...prev, summary:true}))}>نمایش جمع‌بندی</button>
        </div>
        {openPanels.summary && <div className={styles.panelBody}>
          {summaryTargetError && <p role="alert" className={styles.error}>خطا در دریافت اطلاعات پیوست‌ها: {summaryTargetError}</p>}
          <textarea className={styles.field} rows={6} maxLength={6000} value={summary} disabled={!canSummary} onChange={e => setSummary(e.target.value)} placeholder="شرح جمع‌بندی استان…" />
          <div className={styles.actions}><button className={styles.greenButton} type="button" disabled={!canSummary || !summary.trim()} onClick={() => void saveSummary()}>ذخیره جمع‌بندی</button>
            <button type="button" className={styles.primary} disabled={!isDirectorSendReady} onClick={() => {setOpenPanels(prev => ({...prev,decision:true}));setDescription("ارسال جمع‌بندی استان برای بررسی رئیس دفتر");}}>آماده ارسال به رئیس دفتر</button></div>
          {summaryId !== null && <div className={styles.attachments}><strong>پیوست‌های جمع‌بندی</strong><SummaryAttachmentsPanel level="PROVINCE" summaryRecordId={summaryId} readOnly={summaryReadOnly || busy}/></div>}
        </div>}
      </section>
      {openPanels.tracking && <section className={styles.compactBox}>
        <div className={styles.rowHeading}><strong>پیگیری کل ارجاعات</strong><button type="button" className={styles.outlineButton} onClick={() => void refreshTracking().catch(e => setError(String(e)))}>بازخوانی</button></div>
        <p className={styles.hint}>ارجاعات باز: {readable(detail.PendingChildReferrals)} | تحقیقات ناتمام: {readable(detail.PendingAssignments)} | آخرین اقدام: {readable(detail.LastActionCode)}</p>
        <div className={styles.actions}><button type="button" className={styles.outlineButton} onClick={() => togglePanel("tracking")}>بستن</button></div>
      </section>}
      {form && <div className={styles.modalOverlay} role="presentation" onMouseDown={e => {if(e.target === e.currentTarget && !busy) closeForm();}}>
        <div className={styles.modal} role="dialog" aria-modal="true" aria-label="افزودن ارجاع جدید">
          <header className={styles.modalHeader}><h2>افزودن ارجاع جدید</h2><button aria-label="بستن" type="button" onClick={closeForm} disabled={busy}>×</button></header>
          {error && <div role="alert" className={styles.error}>{error}</div>}
          {form !== "INVESTIGATOR" ? <>
            <div className={styles.modalBody}>
              <label htmlFor="target-choice" className={styles.label}>{form === "HOZE" ? "شهرستان حوزه اصلی" : "استان"}</label>
              <div className={styles.picker}>
                <button id="target-choice" type="button" className={styles.pickerTrigger}
                  aria-haspopup="listbox" aria-expanded={pickerOpen} disabled={!canDelegate} onClick={() => void togglePicker()}>
                  <span>{destination ? readable(modalDestinations.find(row => String(row.DestinationCityId) === destination)?.DestinationName || destination) : "انتخاب…"}</span>
                  <span aria-hidden="true">⌄</span>
                </button>
                {pickerOpen && <div className={styles.pickerMenu}>
                  {pickerLoading ? <p className={styles.pickerStatus}>در حال دریافت فهرست {form === "HOZE" ? "حوزه‌های انتخابیه" : "استان‌ها"}…</p>
                  : pickerError ? <div className={styles.pickerError}><span>{pickerError}</span><button type="button" onClick={() => setPickerOpen(false)}>بستن و تلاش مجدد</button></div>
                  : <>
                    {choiceRows.length > 6 && <input className={styles.pickerSearch} value={pickerSearch} onChange={e => setPickerSearch(e.target.value)} placeholder="جستجوی نام مقصد…" aria-label="جستجوی مقصد" autoFocus />}
                    <div role="listbox" aria-label={form === "HOZE" ? "حوزه‌های انتخابیه" : "استان‌ها"} className={styles.pickerChoices}>
                      {visibleChoices.length === 0 && <p className={styles.pickerStatus}>{form === "HOZE" ? "حوزه انتخابیه مجاز و دارای مسئول فعال برای ارجاع یافت نشد." : "استان مجاز و دارای مسئول فعال برای دریافت ارجاع یافت نشد."}</p>}
                      {displayedChoices.map(row => <button type="button" role="option" aria-selected={String(row.DestinationCityId) === destination}
                        className={styles.pickerOption} key={`${row.TargetLevel}-${row.DestinationCityId}`}
                        onClick={() => choosePickerItem(row)}>
                        {readable(row.DestinationName)}
                      </button>)}
                      {visibleChoices.length > displayedChoices.length && <p className={styles.pickerStatus}>{searchKey ? "نتایج بیشتری وجود دارد؛ عبارت جستجو را دقیق‌تر کنید." : "برای یافتن مقصدهای دیگر، نام آن‌ها را جستجو کنید."}</p>}
                    </div>
                  </>}
                </div>}
              </div>
              <label htmlFor="delegate-reason" className={styles.label}>توضیحات ارجاع پرونده</label>
              <textarea id="delegate-reason" className={styles.field} rows={4} maxLength={6000} value={delegateReason} onChange={e => setDelegateReason(e.target.value)} placeholder="درخواست تحقیق و دلیل ارجاع…" disabled={!canDelegate}/>
            </div>
            <div className={styles.modalActions}><button className={styles.primary} type="button" disabled={!canDelegate || !destination || !delegateReason.trim() || busy} onClick={() => void delegate()}>تأیید</button>
              <button type="button" className={styles.cancelButton} disabled={busy} onClick={closeForm}>انصراف</button></div>
          </> : <>
            <div className={styles.modalBody}>
              <label className={styles.label} htmlFor="investigator-choice">محقق</label>
              <div className={styles.picker}>
                <button id="investigator-choice" type="button" className={styles.pickerTrigger}
                  aria-haspopup="listbox" aria-expanded={pickerOpen} disabled={!canAssign} onClick={() => void togglePicker()}>
                  <span>{investigatorKey ? readable(candidates.find(row => String(row.InvestigatorKey) === investigatorKey)?.FullName || investigatorKey) : "انتخاب…"}</span>
                  <span aria-hidden="true">⌄</span>
                </button>
                {pickerOpen && <div className={styles.pickerMenu}>
                  {pickerLoading ? <p className={styles.pickerStatus}>در حال دریافت فهرست محققان ویژه استان…</p>
                  : pickerError ? <div className={styles.pickerError}><span>{pickerError}</span><button type="button" onClick={() => setPickerOpen(false)}>بستن و تلاش مجدد</button></div>
                  : <>
                    {choiceRows.length > 6 && <input className={styles.pickerSearch} value={pickerSearch} onChange={e => setPickerSearch(e.target.value)} placeholder="جستجوی نام محقق…" aria-label="جستجوی محقق" autoFocus />}
                    <div role="listbox" aria-label="محققان ویژه استان" className={styles.pickerChoices}>
                      {visibleChoices.length === 0 && <p className={styles.pickerStatus}>برای انتخابات این پرونده، محقق ویژه واجد شرایطی در استان یافت نشد.</p>}
                      {displayedChoices.map(row => <button type="button" role="option"
                        aria-selected={Boolean(row.InvestigatorKey) && String(row.InvestigatorKey) === investigatorKey}
                        aria-disabled={!row.InvestigatorKey || !Boolean(row.IsAssignable)}
                        disabled={!row.InvestigatorKey || !Boolean(row.IsAssignable)}
                        className={styles.pickerOption}
                        key={readable(row.LegacyCodeMohaghegh || row.InvestigatorKey)}
                        title={!Boolean(row.IsAssignable) ? readable(row.MappingMessage || "حساب کاربری فعال V2 برای این همکار وجود ندارد.") : readable(row.FullName)}
                        onClick={() => choosePickerItem(row)}>
                        <span className={styles.pickerOptionName}>{readable(row.FullName || `محقق ${readable(row.LegacyCodeMohaghegh)}`)}</span>
                        {!Boolean(row.IsAssignable) && <span className={styles.pickerUnavailable}>حساب V2 متصل نیست</span>}
                      </button>)}
                      {visibleChoices.length > displayedChoices.length && <p className={styles.pickerStatus}>{searchKey ? "نتایج بیشتری وجود دارد؛ عبارت جستجو را دقیق‌تر کنید." : "برای یافتن محققان دیگر، نام آن‌ها را جستجو کنید."}</p>}
                    </div>
                  </>}
                </div>}
              </div>
              <label className={styles.label}>مهلت انجام (شمسی)</label>
              <div className={styles.dateBox}><InputPersianDate value={dueDate || null} onChange={v => setDueDate(v || "")} allowPastDates={false}/></div>
              <label className={styles.label} htmlFor="investigator-instruction">توضیحات ارجاع پرونده</label>
              <textarea id="investigator-instruction" className={`${styles.field} ${styles.modalTextarea}`} rows={3} maxLength={6000} value={investigatorReason} onChange={e => setInvestigatorReason(e.target.value)} disabled={!canAssign}/>
            </div>
            <div className={styles.modalActions}><button className={styles.primary} type="button" disabled={!canAssign || !investigatorKey || !investigatorReason.trim() || busy} onClick={() => void assign()}>تأیید</button>
              <button className={styles.cancelButton} type="button" disabled={busy} onClick={closeForm}>انصراف</button></div>
          </>}
        </div>
      </div>}
    </>}
  </main>;
}
