"use client";
import { useEffect, useState } from "react";
import { meratV2Request, type V2Row } from "@/app/lib/meratV2/client";
import s from "./Consolidation.module.css";
import SummaryAttachmentsPanel from "./SummaryAttachmentsPanel";
const toText = (value: unknown) => value == null ? "—" : String(value);
/** Only stored summaries authorize reply; unsaved edits disable reply. */
export default function CountySummaryEditor({ referralId, working, onReadyChange }: {
  referralId: number; working: boolean; onReadyChange: (ready: boolean) => void;
}) {
 const [rows,setRows]=useState<V2Row[]>([]);
 const [text,setText]=useState("");
 const [saved,setSaved]=useState("");
 const [summaryId,setSummaryId]=useState<number|null>(null);
 const [loading,setLoading]=useState(true);
 const [saving,setSaving]=useState(false);
 const [error,setError]=useState("");
 const [notice,setNotice]=useState("");
 useEffect(()=>{
  let live=true;
  onReadyChange(false);setLoading(true);setRows([]);setText("");setSaved("");setSummaryId(null);setError("");setNotice("");
  void meratV2Request(`/Api/TahghighV2/CountyConsolidation?countyReferralId=${referralId}`)
   .then(items=>{if(!live)return;const value=typeof items[0]?.CountySummaryText==="string" ? String(items[0].CountySummaryText):"";
    setRows(items);setText(value);setSaved(value);const id=Number(items[0]?.SummaryId??0);setSummaryId(Number.isSafeInteger(id)&&id>0?id:null);onReadyChange(value.trim().length>=20);
   }).catch(e=>{if(live)setError(e instanceof Error?e.message:String(e));})
   .finally(()=>{if(live)setLoading(false);});
  return ()=>{live=false;};
 },[referralId,onReadyChange]);
 async function save(){setSaving(true);setError("");setNotice("");onReadyChange(false);
  try {const result=await meratV2Request("/Api/TahghighV2/SaveCountySummary",{countyReferralId:referralId,summaryText:text.trim()});
   const id=Number(result[0]?.SummaryId??0);if(Number.isSafeInteger(id)&&id>0)setSummaryId(id);
   setSaved(text.trim());setText(text.trim());onReadyChange(true);setNotice("جمع‌بندی شهرستان ذخیره شد.");
  }catch(e){setError(e instanceof Error?e.message:String(e));}finally{setSaving(false);}
 }
 const clean=text.trim();const cleanSaved=saved.trim();const unchanged=clean===cleanSaved;
 return <section className={s.panel} aria-label="جمع‌بندی شهرستان">
  <h3 className={s.heading}>جمع‌بندی نهایی شهرستان</h3>
  <p className={s.help}>نتیجه محققان را بررسی کنید و متن نهایی را ذخیره کنید. پس از ذخیره و تعیین‌تکلیف محققان، پاسخ شهرستان قابل ارسال است.</p>
  {loading?<p role="status">در حال دریافت نتایج محققان…</p>:<>
   <div className={s.tableWrap}><table className={s.table}><thead><tr><th>انتساب</th><th>وضعیت</th><th>کاربرگ‌ها</th><th>جمع‌بندی محقق</th></tr></thead><tbody>
   {rows.filter(r=>r.AssignmentId!=null).map(r=><tr key={toText(r.AssignmentId)}><td>{toText(r.AssignmentId)}</td>
    <td>{toText(r.AssignmentStatus)}</td><td>{toText(r.WorksheetCount)}</td><td><p className={s.pre}>{toText(r.InvestigatorSummary)}</p></td></tr>)}
   {rows.every(r=>r.AssignmentId==null)&&<tr><td colSpan={4}>هنوز تحقیقی برای این شهرستان ثبت نشده است.</td></tr>}
   </tbody></table></div>
   <label htmlFor={`county-summary-${referralId}`} className={s.label}>متن جمع‌بندی شهرستان</label>
   <textarea id={`county-summary-${referralId}`} className={s.textarea} maxLength={10000} value={text}
    readOnly={!working||saving} onChange={e=>{setText(e.target.value);onReadyChange(false);setNotice("");}}
    placeholder="نتایج محققان، ارزیابی مدارک و نتیجه نهایی شهرستان را بنویسید…"/>
   <div className={s.actions}><span className={s.meta}>{clean.length.toLocaleString("fa-IR")} / ۱۰٬۰۰۰ نویسه</span>
   <button type="button" className={s.button} disabled={!working||saving||clean.length<20||unchanged} onClick={()=>void save()}>{saving?"در حال ذخیره…":"ذخیره جمع‌بندی شهرستان"}</button></div>
   {working&&cleanSaved.length>=20&&unchanged&&<p className={s.success} role="status">جمع‌بندی ذخیره شده و از نظر ثبت متن آماده ارسال است.</p>}
   {working&&!unchanged&&<p className={s.warning}>متن تغییر کرده است؛ برای فعال‌شدن ارسال پاسخ، آن را ذخیره کنید.</p>}
  </>}
  {summaryId!==null&&<SummaryAttachmentsPanel level="COUNTY" summaryRecordId={summaryId} readOnly={!working||saving}/>}
  {notice&&<p className={s.success} role="status">{notice}</p>}
  {error&&<p className={s.warning} role="alert">{error}</p>}
 </section>;
}
