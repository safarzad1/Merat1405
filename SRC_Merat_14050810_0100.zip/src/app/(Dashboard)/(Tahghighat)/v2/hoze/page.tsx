"use client";
import {useEffect,useState} from "react";
import { WorkflowHero, StateChip, EmptyMessage, AppNotice, SectionTitle, workflowStyles as u } from "@/app/(Dashboard)/(Tahghighat)/v2/components/MeratWorkflowUI";

import HozeSummaryEditor from "@/app/(Dashboard)/(Tahghighat)/v2/components/HozeSummaryEditor";
import {meratV2Request,type V2Row} from "@/app/lib/meratV2/client";
const number=(x:unknown)=>Number(x||0),text=(x:unknown)=>x==null?"—":String(x);
export default function HozeCountyPage(){
 const [inbox,setInbox]=useState<V2Row[]>([]),[cities,setCities]=useState<V2Row[]>([]),[children,setChildren]=useState<V2Row[]>([]);
 const [ref,setRef]=useState<number|null>(null),[city,setCity]=useState(""),[note,setNote]=useState(""),[actionNote,setActionNote]=useState("");
 const [summaryReady,setSummaryReady]=useState(false);
 const [busy,setBusy]=useState(false),[error,setError]=useState(""),[notice,setNotice]=useState("");
 async function reload(){setInbox(await meratV2Request("/Api/TahghighV2/ChildInbox?page=1&pageSize=100"));}
 async function detail(id:number){const [a,b]=await Promise.all([
  meratV2Request(`/Api/TahghighV2/HozeCountyChoices?hozeReferralId=${id}`),
  meratV2Request(`/Api/TahghighV2/HozeCountyReferrals?hozeReferralId=${id}`)]);setCities(a);setChildren(b);}
 useEffect(()=>{void reload().catch(e=>setError(String(e)));},[]);
 useEffect(()=>{setCities([]);setChildren([]);if(ref!==null)void detail(ref).catch(e=>setError(String(e)));},[ref]);
 const chosen=inbox.find(x=>number(x.ReferralId)===ref),working=chosen?.StateCode==="CHILD_WORKING";
 const open=children.some(x=>!Boolean(x.IsClosed));
 async function act(url:string,body:Record<string,unknown>,msg:string){setBusy(true);setError("");setNotice("");try{
  await meratV2Request(url,body);setNotice(msg);await reload();if(ref!==null)await detail(ref);
 }catch(e){setError(e instanceof Error?e.message:String(e));}finally{setBusy(false);}}
 return <main dir="rtl" className={u.workspace}>
 <WorkflowHero eyebrow="تحقیقات مرآت · فاز ۲C" title="حوزه اصلی و شهرستان‌های تابع"
 description="ارجاع به شهرستان‌های مجاز حوزه، رصد پاسخ‌ها و ارسال نتیجه تجمیع‌شده به استان."
 stats={[{label:"ارجاعات حوزه",value:inbox.filter(x=>x.ReceiverLevel==="HOZE").length},{label:"شهرستان‌های ارجاعی",value:children.length},{label:"پاسخ‌های باز",value:children.filter(x=>!Boolean(x.IsClosed)).length}]}/>
 <SectionTitle kicker="صندوق حوزه" title="پرونده‌های دریافتی" description="انتخاب شهرستان براساس ساختار واقعی حوزه انتخابیه انجام می‌شود."/>
 {error&&<AppNotice kind="error">{error}</AppNotice>}{notice&&<AppNotice kind="success">{notice}</AppNotice>}
 <button type="button" onClick={()=>void reload().catch(e=>setError(String(e)))}>بازخوانی کارتابل</button>
 <ul>{inbox.filter(x=>x.ReceiverLevel==="HOZE").map(x=><li key={text(x.ReferralId)}>
  <button type="button" onClick={()=>{setSummaryReady(false);setRef(number(x.ReferralId));}}>ارجاع {text(x.ReferralId)} — پرونده {text(x.ShomarehParvandeh)} — {text(x.StateCode)}</button></li>)}</ul>{inbox.filter(x=>x.ReceiverLevel==="HOZE").length===0&&<EmptyMessage title="ارجاعی برای حوزه ثبت نشده"/>}
 {ref!==null&&chosen&&<section className={u.selectionPanel}>
 <SectionTitle kicker="پرونده انتخابی" title={`ارجاع حوزه ${ref}`}/><label>توضیح اقدام<textarea rows={3} maxLength={6000} style={{display:"block",width:"100%"}} value={actionNote} onChange={e=>setActionNote(e.target.value)}/></label>
 {chosen.StateCode==="CHILD_INBOX"&&<button type="button" disabled={busy||!actionNote.trim()} onClick={()=>void act("/Api/TahghighV2/ChildAction",{childReferralId:ref,actionCode:"CHILD_START",description:actionNote.trim()},"بررسی حوزه شروع شد.")}>شروع بررسی حوزه</button>}
 <SectionTitle kicker="توزیع ارجاع" title="ارجاع به شهرستان تابع"/><label>شهرستان<select value={city} onChange={e=>setCity(e.target.value)} disabled={!working||busy}>
 <option value="">انتخاب</option>{cities.filter(x=>number(x.ActiveRepresentatives)>0).map(x=><option key={text(x.CountyCityId)} value={text(x.CountyCityId)}>{text(x.CountyCityId)}</option>)}</select></label>
 <label>شرح مأموریت<textarea rows={3} maxLength={6000} value={note} style={{display:"block",width:"100%"}} onChange={e=>setNote(e.target.value)}/></label>
 <button type="button" className={u.primary} disabled={!working||busy||!city||!note.trim()} onClick={()=>void act("/Api/TahghighV2/HozeReferCounty",{hozeReferralId:ref,countyCityId:Number(city),description:note.trim()},"ارجاع شهرستان ثبت شد.")}>ارجاع شهرستان</button>
 <SectionTitle kicker="پیگیری" title="وضعیت پاسخ شهرستان‌ها"/><div className={u.tableScroll}><table style={{width:"100%",textAlign:"right"}}><thead><tr><th>شهرستان</th><th>ارجاع</th><th>وضعیت</th><th>تحقیقات باز</th></tr></thead><tbody>{children.map(x=><tr key={text(x.CountyReferralId)}><td>{text(x.CountyCityId)}</td><td>{text(x.CountyReferralId)}</td><td><StateChip value={x.StateCode}/></td><td>{text(x.OpenAssignments)}</td></tr>)}</tbody></table></div>
 <HozeSummaryEditor key={ref} referralId={ref} working={working} onReadyChange={setSummaryReady}/>
 {working&&<button type="button" className={u.primary} disabled={busy||open||!summaryReady||!actionNote.trim()} onClick={()=>void act("/Api/TahghighV2/ChildAction",{childReferralId:ref,actionCode:"CHILD_REPLY",description:actionNote.trim()},"پاسخ حوزه به استان ثبت شد.")}>ارسال پاسخ حوزه به استان</button>}
 {open&&<AppNotice kind="info">ارجاع شهرستان باز وجود دارد؛ ارسال پاسخ حوزه ممکن نیست.</AppNotice>}
 </section>}</main>;
}
